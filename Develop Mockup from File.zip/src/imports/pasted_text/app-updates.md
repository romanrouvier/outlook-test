Make the following changes across the entire app. Apply all of them together.

─────────────────────────────────────────
APP.TSX — NAVIGATION
─────────────────────────────────────────
Add 2 new nav items after "Availability":
- path="/sprint-review", label="Sprint Review", icon=ClipboardList (lucide-react)
- path="/daily", label="Daily", icon=Timer (lucide-react)
Add the corresponding <Route> elements pointing to new <SprintReview /> and <Daily /> components.

─────────────────────────────────────────
DASHBOARD.TSX — CHANGES
─────────────────────────────────────────
1. REMOVE from the "Planned vs Consumed Capacity" card the entire sparkline section (the div containing the "Velocity (MD/day)" label and the bar chart below the two ring gauges).

2. REMOVE completely the "Team Load: Summary View" card (the col-span-2 card at the bottom of the grid).

3. ADD a full-width alert banner between the page header div and the main p-8 div. The banner has bg-blue-50, px-8 py-3, border-b border-blue-100. Inside it a flex row items-center justify-between:
   - Left: AlertCircle icon (w-5 h-5 text-[#2649B2] flex-shrink-0) followed by text-sm text-gray-800: "Sprint is 80% complete — only 65% of stories delivered so far. 6 stories are at risk of missing the sprint deadline." where "80%", "65%" and "6 stories" are wrapped in <span className="font-semibold text-[#2649B2]">
   - Right: a Button with bg-[#2649B2] text-white, Bell icon (w-4 h-4 mr-2), label "Notify Sprint Team"

─────────────────────────────────────────
CAPACITYPLANNER.TSX — CHANGES
─────────────────────────────────────────
1. REMOVE the Tabs system (Current / Past / Future tabs) entirely. Replace it with a sprint selector bar: a white rounded-lg border card (p-4 mb-6) containing a flex row with: left side shows Calendar icon + text "Sprint #24 — 15/04 → 29/04" (text-sm text-gray-700); right side shows a Select component with options "Sprint 22 — 18/03 → 01/04", "Sprint 23 — 01/04 → 14/04", "Sprint 24 — 15/04 → 29/04" (default), "Sprint 25 — 30/04 → 13/05". Always render Sprint 24 data below (selector is visual only).

2. RENAME the "Sprint Content & Assignment" card title to "Sprint Content".

3. In the stories table inside that card:
   - PRIORITY column: replace the static Badge with an inline Select component. Options: "1 - Critical", "2 - High", "3 - Moderate", "4 - Low". Default = the story's current priority.
   - ASSIGNED TO column: replace avatar+name with a Select component. Options: "Marie Dupont", "Jean Martin", "Sophie Bernard", "Pierre Leroy", "Lucas Petit", "Emma Rousseau", "Thomas Dubois", "Léa Moreau". Default = the story's current assignee.
   - STATUS column: replace the Badge with a Select component. Options and their badge colors when selected: Draft (gray), Ready (blue outline #2649B2), Work in progress (blue filled #2649B2), Ready for testing (purple outline), Testing (purple filled), Complete (green filled), Cancelled (gray filled with line-through label). The Select trigger shows a small colored dot or badge matching the selected status.

Keep "Individual Team Capacity" and "Capacity Distribution by Project" cards unchanged.

─────────────────────────────────────────
AVAILABILITY.TSX — CHANGES
─────────────────────────────────────────
1. ADD a filter bar between the page header and the main calendar Card. A white rounded-lg border card (p-4 mb-6) with a flex row of controls:
   - "Members" label + a Select showing "All members (8)" by default, with all 8 developer names as options (Marie Dupont, Jean Martin, Sophie Bernard, Pierre Leroy, Lucas Petit, Emma Rousseau, Thomas Dubois, Léa Moreau). Visual only — calendar always shows all rows.
   - "Sprint" label + a Select with options "Sprint 23 — 01/04 → 14/04", "Sprint 24 — 15/04 → 29/04" (default), "Sprint 25 — 30/04 → 13/05".
   - A ghost Button with RotateCcw icon (lucide-react) and label "Reset filters" (text-xs text-gray-500).

2. ADD a new Card below the existing calendar card titled "Sprint Stories Overview" with a count badge "8 stories" in the header. Inside, a table (use ScrollArea max-h-[300px]) with columns: Story ID | Title | Assigned to | Status | Est. (MD) | Sprint days. Populate with:
   STRY0744438 | [TECH] Tree SQL & Python optimization | Pierre Leroy | Work in progress | 13 | 8
   STRY0744431 | [TECH] Increase cache expiring time for BQ caller | Marie Dupont | Work in progress | 8 | 5
   STRY0740619 | [TECH] Delete P&L lines automation | Sophie Bernard | Complete | 13 | 5
   STRY0740621 | [TECH] Add missing P&L line in PLP | Jean Martin | Work in progress | 8 | 6
   STRY0744463 | [TECH] BQ decommissioning step 1 | Léa Moreau | Ready | 5 | 2
   STRY0744446 | [TECH] BQ decommissioning step 2 | Emma Rousseau | Complete | 5 | 3
   STRY0758160 | [FRONT] Fix SGA dashboard colors | Lucas Petit | Testing | 3 | 4
   STRY0735868 | [FRONT] Dedicated URL for iClosing | Thomas Dubois | In Review | 8 | 5
   Status badges: Draft=gray, Ready=blue outline (#2649B2), Work in progress=blue filled (#2649B2), Complete=green filled, Testing=purple filled, In Review=purple outline.

─────────────────────────────────────────
NEW FILE: SprintReview.tsx
─────────────────────────────────────────
Create src/app/components/SprintReview.tsx.

Page header: "Sprint Review" (same style as other pages — bg-white border-b px-8 py-6, h1 text-2xl font-semibold text-gray-900).

Below header in the main p-8 area, a 2-column grid (grid-cols-2 gap-6 max-w-[1600px]):

LEFT COLUMN — Sprint Recap Card:
Card titled "Sprint Recap". At the top of CardContent, a flex row with label "Sprint" and a Select component with options:
  "Sprint 22 — 18/03 → 01/04"
  "Sprint 23 — 01/04 → 14/04" (default selected)
  "Sprint 24 — 15/04 → 29/04"

Below the selector, a flex row of 3 small KPI chips (inline boxes with border rounded-lg px-3 py-2):
  "14 Planned" (gray), "9 Completed" (green text), "3 Deferred" (orange text)

Then 3 stacked sections:

Section 1 — header row: green Badge "✓ Completed (9)". Below it a ScrollArea max-h-[180px] with these story rows (each row: story ID monospace text-xs text-gray-500, title text-sm, assignee avatar initials + name, green "Complete" badge):
  STRY0723145 | [TECH] Database migration phase 1 | Marie Dupont
  STRY0723146 | [FRONT] New dashboard layout | Jean Martin
  STRY0723147 | [TECH] API performance improvements | Sophie Bernard
  STRY0723148 | [FRONT] User profile enhancements | Pierre Leroy
  STRY0723149 | [TECH] Cache optimization | Lucas Petit

Section 2 — header row: orange Badge "⏭ Pushed to Next Sprint (3)". ScrollArea max-h-[140px] with rows (story ID, title, reason tag, orange "Deferred" badge):
  STRY0723150 | [TECH] Data warehouse migration phase 2 | Reason: Blocked
  STRY0723151 | [FRONT] Advanced filtering UI | Reason: Scope change
  STRY0723152 | [TECH] Real-time notifications | Reason: Dependency missing

Section 3 — header row: gray Badge "✕ Cancelled (2)". Rows with line-through title style and gray "Cancelled" badge:
  STRY0723153 | [FRONT] Legacy IE11 compatibility fixes
  STRY0723154 | [TECH] Manual CSV export endpoint

RIGHT COLUMN — Release Notes Card:
Card titled "Release Notes". At the top of CardContent, a flex row with label "Release" and a Select:
  "Release 2.3.5 — 14/04 (Prod)"
  "Release 2.4.0 — 29/04 (Prod)" (default)
  "Release 2.4.1 — 06/05 (Staging)"

Below, a summary row: Badge bg-[#2649B2] text-white "v2.4.0", text "29 April 2026", Badge outline "Production".

Section titled "Developments Included" (text-xs font-medium text-gray-600 uppercase mb-2). ScrollArea max-h-[260px] with rows. Each row (flex, items-center, gap-2, py-2, border-b border-gray-100): story ID monospace text-xs text-gray-500 | type badge ([FRONT] in blue-100 text-blue-700 or [TECH] in gray-100 text-gray-700, text-xs) | title text-sm text-gray-900 | avatar initials + developer name text-xs:
  STRY0723145 | [TECH] | Database migration phase 1 | Marie Dupont
  STRY0723146 | [FRONT] | New dashboard layout | Jean Martin
  STRY0723147 | [TECH] | API performance improvements | Sophie Bernard
  STRY0723148 | [FRONT] | User profile enhancements | Pierre Leroy
  STRY0723149 | [TECH] | Cache optimization | Lucas Petit
  STRY0735868 | [FRONT] | Dedicated URL for iClosing | Thomas Dubois
  STRY0758160 | [FRONT] | Fix SGA dashboard colors | Lucas Petit

Section titled "Benefits" (text-xs font-medium text-gray-600 uppercase mb-2 mt-4). A ul with 4 items, each prefixed with a CheckCircle icon (w-4 h-4 text-[#2649B2] inline flex-shrink-0):
  - Resolved SSO authentication failures affecting 200+ daily users
  - Reduced BigQuery query time by 40% through cache layer optimization
  - New dedicated URL structure for all iClosing analytics products
  - Automated P&L line management, saving ~3h/week of manual operations

At the bottom of the card, a Button variant="outline" with Download icon (lucide-react) and label "Export Release Note".

─────────────────────────────────────────
NEW FILE: Daily.tsx
─────────────────────────────────────────
Create src/app/components/Daily.tsx.

Page header: "Daily Standup" as h1, subtitle "06/05/2026 · Sprint #24 — 15/04 → 29/04" as p text-sm text-gray-600 mt-1. Same header style as other pages (bg-white border-b px-8 py-6).

Inside main div (p-8, bg-gray-50):

SECTION 1 — Timer Card (full width, mb-6):
Card with CardHeader title "Standup Timer — 15 minutes". CardContent centered (text-center):
  Large display: <p className="text-6xl font-bold text-[#2649B2] tracking-widest my-4">15:00</p>
  Below it a flex justify-center gap-3 with 3 buttons:
    Button bg-[#2649B2] text-white: Play icon + "Start"
    Button variant="outline": Pause icon + "Pause"
    Button variant="ghost": RotateCcw icon + "Reset"
  Below the buttons a Progress component value={0} className="h-2 mt-4 max-w-md mx-auto"
  Below that text-xs text-gray-500: "Timer will alert the team when 15 minutes have elapsed"

SECTION 2 — Story Board:
A flex row between section title and a status legend:
  Left: <h2 className="text-lg font-semibold text-gray-900 mb-4">Team Stories — Current Sprint</h2>
  Right: a flex flex-wrap gap-2 of small legend badges showing all statuses with their colors:
    "Draft" gray, "Ready" blue outline, "Work in progress" blue filled, "Ready for testing" purple outline, "Testing" purple filled, "Complete" green filled, "Cancelled" gray filled

Below that, a grid grid-cols-2 gap-4 of developer cards. Use this exact data:

Developer cards (one Card per developer, bg-white shadow-sm):
CardHeader: flex items-center gap-3. Avatar (initials bg-[#2649B2] text-white). Developer name font-medium. Badge variant="outline" showing story count.
CardContent: a list of story rows separated by border-b border-gray-100.

Each story row is a div with: py-2 space-y-1. If the story is DELAYED (elapsed > estimated) the row has bg-red-50 rounded px-2.
Row line 1: flex items-center justify-between gap-2
  Left: story ID (text-xs font-mono text-gray-400) + title (text-sm text-gray-900, truncate max-w-[200px])
  Right: status Badge + if DELAYED add Badge "Delayed" bg-red-100 text-red-700 text-xs + Button variant="ghost" size="icon" className="h-6 w-6" with MessageSquare icon (w-3 h-3 text-red-500) and title="Notify developer or Data Product Owner"
Row line 2: text-xs text-gray-500 "Est: X days · Elapsed: Y days"

Use this exact mock data:

Marie Dupont (MD) — 2 stories:
  STRY0744431 | [TECH] Increase cache expiring time for BQ caller | Status: Work in progress | Est: 3 days | Elapsed: 2 days | NOT delayed
  STRY0740621 | [TECH] Add missing P&L line in PLP | Status: Ready for testing | Est: 4 days | Elapsed: 6 days | DELAYED

Jean Martin (JM) — 1 story:
  STRY0740619 | [TECH] Delete P&L lines automation | Status: Complete | Est: 5 days | Elapsed: 5 days | NOT delayed

Sophie Bernard (SB) — 1 story:
  STRY0744463 | [TECH] BQ decommissioning step 1 | Status: Work in progress | Est: 3 days | Elapsed: 5 days | DELAYED

Pierre Leroy (PL) — 1 story:
  STRY0744438 | [TECH] Tree SQL & Python optimization | Status: Ready | Est: 8 days | Elapsed: 2 days | NOT delayed

Lucas Petit (LP) — 1 story:
  STRY0758160 | [FRONT] Fix SGA dashboard colors | Status: Testing | Est: 2 days | Elapsed: 3 days | DELAYED

Emma Rousseau (ER) — 1 story:
  STRY0744446 | [TECH] BQ decommissioning step 2 | Status: Complete | Est: 3 days | Elapsed: 3 days | NOT delayed

Thomas Dubois (TD) — 1 story:
  STRY0735868 | [FRONT] Dedicated URL for iClosing | Status: Work in progress | Est: 5 days | Elapsed: 4 days | NOT delayed

Léa Moreau (LM) — 1 story:
  STRY0765001 | [FRONT] Employee dashboard redesign | Status: Draft | Est: 6 days | Elapsed: 1 day | NOT delayed

─────────────────────────────────────────
DESIGN SYSTEM (apply throughout)
─────────────────────────────────────────
- White dominant backgrounds, bg-gray-50 page background
- Primary accent: #2649B2 (L'Oréal blue)
- Secondary text: Payne gray (#4A5568 / text-gray-600)
- Cards: bg-white shadow-sm border border-gray-200 rounded-lg
- All new components use shadcn/ui: Card, Badge, Button, Select, ScrollArea, Progress, Avatar, Tabs
- Icons from lucide-react only
- No new external dependencies