Prompt Figma : WebApp de Pilotage pour Product Lead Opérationnel
Contexte Général du Produit :

Nom du Produit : WebApp “Product lead” de pilotage
Cible : Product Lead Opérationnel
Objectif Principal : Abstraire la complexité de ServiceNow pour la rendre visuelle, actionnable et compréhensible en quelques secondes, facilitant le pilotage opérationnel du produit et des sprints.
Contraintes Techniques :
❌ Pas de backend (données mockées, mais structurées comme de vrais objets ServiceNow).
✅ React + Tailwind / UI uniquement (pas d'implémentation technique à représenter).
Design System & Principes UX :
Style : Enterprise Premium (sobre, moderne, professionnel).
Palette de Couleurs :
Blanc dominant (fond, cartes, espaces).
Gris de Payne (textes secondaires, éléments discrets, bordures, ombres légères).
Bleu #2649B2 (couleur d'accentuation pour signaux positifs, actions principales, éléments interactifs, indicateurs clés).
Principes UX :
Minimalisme : Peu d’éléments à l'écran.
Aération : Beaucoup d’espaces blancs.
Lisibilité Rapide : Lecture et compréhension en 5–10 secondes maximum.
Clarté : Aucun jargon technique inutile pour le Product Lead.
Hiérarchie Visuelle : Les informations les plus importantes doivent sauter aux yeux.
Structure Générale des Pages :

Toutes les pages incluent une barre latérale gauche persistante pour l'AI Assistant.
Page 1 : Portail Product Lead (Dashboard Opérationnel)
Titre de la Page : "Portail Product Lead" (en haut à gauche, clair et visible)

Barre Latérale Gauche :

Titre : "AI Assistant"
Contenu : Simuler une interface de chat avec un champ de saisie en bas et un historique de conversation au-dessus. Icône représentative de l'IA.
Widgets Principaux (disposition flexible, mais privilégiant la lecture de haut en bas et de gauche à droite) :

Widget : Capacité Planifiée vs Consommée

Titre : "Capacité Planifiée vs Consommée"
Contenu :
Double jauge visuelle (anneaux ou barres de progression) :
Une jauge pour la "Capacité Consommée" (ex: 80% des points d'effort).
Une autre pour la "Progression du Temps" du sprint (ex: 60% du temps écoulé).
Indicateurs numériques clairs : "X/Y points d'effort consommés" et "Z jours restants sur le sprint".
Signal d'alerte visuel (couleur bleue) : Si la consommation est trop lente par rapport au temps écoulé (risque de non-atteinte) ou trop rapide (risque de surcharge).
Optionnel : Un mini-graphique de tendance (type sparkline) montrant la vélocité (points consommés par jour) sur les derniers jours.
Widget : Incidents & Défauts

Titre : "Incidents & Défauts"
Contenu :
Chiffres clés agrégés : "X Incidents ouverts (Y Critiques)" et "Z Défauts ouverts (W Bloquants)". Les nombres "Y" et "W" (critiques/bloquants) doivent être mis en évidence avec la couleur bleue.
Liste concise des 3-5 éléments les plus critiques/récents : Afficher sous forme de lignes.
Format : [Priorité] [Type] - [Titre court] - [Assigné à L3] - [Statut].
Ex: P1 INC - Problème de connexion SSO - Equipe Authent - Ouvert
Ex: Bloquant DEF - Bug panier d'achat - Equipe E-commerce - En cours
Tendance : Une petite flèche (haut/bas) ou icône indiquant si le nombre d'incidents/défauts critiques a augmenté ou diminué sur les dernières 24h.
Widget : Timeline du Sprint Actuel

Titre : "Timeline du Sprint Actuel"
Contenu :
Fil d'activités filtré : Afficher les changements de statut majeurs pour les stories actives du sprint.
Format concis : "Il y a X min/h : Story #ID - 'Titre de la Story' passée en [Statut] par [Nom de l'acteur]".
Mise en évidence : Utiliser le bleu pour les statuts "Terminée" ou "En Production". Une icône spécifique pour le statut "Bloquée".
Filtres rapides (en haut du widget) : Ex: "Tout", "Bloquée", "Terminée".
Widget : Priorités du Sprint

Titre : "Priorités du Sprint" ou "Stories Prioritaires"
Contenu :
Liste des 5-7 stories les plus prioritaires du sprint :
Pour chaque story : Titre de la story, Priorité qualitative (High/Medium/Low avec un badge couleur discret), Statut actuel, Assigné à (Équipe ou personne), et un petit icône d'alerte si un risque est associé.
Vue d'ensemble rapide : Un compteur en haut du widget : "X stories prioritaires sur Y au total", "Z bloquées".
Widget : Charge Équipe : Vue Synthétique

Titre : "Charge Équipe : Vue Synthétique"
Contenu :
Indicateur global de "santé" de la charge : Ex: "Équipe équilibrée", "Risque de surcharge (X personnes)", "Sous-charge (Y personnes)".
Graphique simple (ex: histogramme) : Montrant la répartition de la charge par équipe ou par groupe d'assignation L3, avec un code couleur pour signaler les surcharges (ex: bleu pour optimal, gris de Payne pour sous-charge, une teinte orange/rouge discrète pour surcharge).
Page 2 : Capacity Planner
Titre de la Page : "Capacity Planner" ou "Gestion de la Capacité du Sprint" (en haut à gauche, clair et visible)

Barre Latérale Gauche :

Titre : "AI Assistant" (identique à la page 1, persistante)
Contenu : Interface de chat.
Éléments d'En-tête (au-dessus des widgets) :

Informations Sprint : "Sprint Actuel : #[Numéro du Sprint]" (ex: #24) ou "Sprint : [Nom du Sprint]" (ex: Q3-2024 - Feature X).
Afficher également les dates du sprint : "Du JJ/MM au JJ/MM".
Boutons d'Action : Deux boutons clairs et distincts.
"Démarrer un nouveau Sprint" (couleur bleue pour l'action principale).
"Clôturer le Sprint" (gris de Payne ou couleur neutre).
Widgets Principaux (disposition flexible, mais logique pour la gestion) :

Widget : Capacité Individuelle de l'Équipe

Titre : "Capacité Individuelle de l'Équipe"
Contenu :
Tableau ou liste interactive (avec scrollbar) :
Colonne 1 : Nom du Membre d'Équipe (avec avatar/initiales).
Colonne 2 : Capacité Totale (ex: 80 points d'effort ou 5 jours-hommes).
Colonne 3 : Capacité Allouée (ex: 70 points alloués).
Colonne 4 : Capacité Restante/Disponible (ex: 10 points disponibles).
Colonne 5 : Ajustement Manuel : Un champ éditable ou un curseur simple pour modifier la capacité disponible (simuler l'interaction).
Barre de progression visuelle pour chaque membre : Montrant la capacité allouée vs. totale.
Bleu : Allouée < Totale (disponible).
Gris de Payne : Allouée = Totale (optimale).
Rouge/Orange discret : Allouée > Totale (surcharge).
Agrégation : Un total de la capacité disponible/allouée pour toute l'équipe en haut du widget.
Widget : Répartition de la Capacité par Projet/Initiative

Titre : "Répartition de la Capacité par Projet/Initiative"
Contenu :
Graphique visuel : Un graphique en barres empilées ou en anneau montrant la proportion de la capacité totale de l'équipe allouée à chaque projet.
Tableau récapitulatif (avec scrollbar) :
Colonne 1 : Nom du Projet/Initiative.
Colonne 2 : Capacité Allouée (en points d'effort ou jours-hommes).
Colonne 3 : Pourcentage de la Capacité Totale de l'Équipe allouée à ce projet.
Widget : Contenu du Sprint & Attribution

Titre : "Contenu du Sprint & Attribution"
Contenu :
Tableau interactif et filtrable (avec scrollbar) :
Colonne 1 : ID de la Story (ex: STR-123).
Colonne 2 : Titre de la Story.
Colonne 3 : Priorité (High/Medium/Low, avec badge couleur).
Colonne 4 : Points d'Effort (si utilisé).
Colonne 5 : Statut (ex: À faire, En cours, En revue, Terminé, Bloqué).
Colonne 6 : Assigné à (Nom du Membre d'Équipe ou de l'Équipe, avec avatar/initiales).
Colonne 7 (optionnel) : Projet/Initiative (si la story est liée à un projet spécifique).
Filtres/Tri (en haut du tableau) : Par priorité, par statut, par assigné, par projet.
Indicateurs visuels : Mettre en évidence les stories bloquées ou à haute priorité (couleur, icône).
Simuler une interaction (glisser-déposer) : Indiquer visuellement qu'il est possible de réordonner ou de réassigner des stories (même si c'est juste une indication visuelle pour le mockup).
Ce prompt fournit une base très solide pour tes mockups Figma. N'hésite pas si tu as des questions ou si tu souhaites affiner des détails !

