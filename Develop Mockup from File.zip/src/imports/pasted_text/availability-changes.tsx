Apply all of the following changes precisely. Multiple files are affected.

─────────────────────────────────────────
AVAILABILITY.TSX — Unify calendar + update assignment groups
─────────────────────────────────────────

CHANGE 1 — Remove all group header rows from the calendar table:
Delete the group divider <tr> rows entirely (the blue bg-[#EEF2FF] rows showing "DATA - Finance - BTDP L3", "Supply" etc.). The calendar tbody must only contain developer rows, one per person, in a flat unified list with no group separators.

CHANGE 2 — Update Assignment Group dropdown options:
Replace the current Select options in the filter bar "Assignment Group" selector with:
  <SelectItem value="all">All Groups</SelectItem>
  <SelectItem value="data-finance">DATA - Finance L3 BTDP</SelectItem>
  <SelectItem value="data-sourcing">DATA - Sourcing L3 BTDP</SelectItem>
  <SelectItem value="supply">Supply</SelectItem>
  <SelectItem value="sourcing">Sourcing</SelectItem>
  <SelectItem value="product">Product</SelectItem>
  <SelectItem value="marketing">Marketing</SelectItem>

─────────────────────────────────────────
DASHBOARD.TSX — Multiple changes
─────────────────────────────────────────

CHANGE 3 — Update Assignment Group dropdown in Product Lead Portal filter bar:
Replace the current Select options for "All Assignment Groups" with the same list as above:
  <SelectItem value="all">All Assignment Groups</SelectItem>
  <SelectItem value="data-finance">DATA - Finance L3 BTDP</SelectItem>
  <SelectItem value="data-sourcing">DATA - Sourcing L3 BTDP</SelectItem>
  <SelectItem value="supply">Supply</SelectItem>
  <SelectItem value="sourcing">Sourcing</SelectItem>
  <SelectItem value="product">Product</SelectItem>
  <SelectItem value="marketing">Marketing</SelectItem>

CHANGE 4 — Move "Notify Sprint Team" button into the Planned vs Consumed Capacity card header:
Remove the Notify Sprint Team Button from inside the blue alert box (the bg-blue-50 div).
Add it to the CardHeader of "Planned vs Consumed Capacity" — make the CardHeader a flex row items-center justify-between:
  <CardHeader className="flex-shrink-0 border-b border-gray-100 flex flex-row items-center justify-between py-3">
    <CardTitle className="text-base">Planned vs Consumed Capacity</CardTitle>
    <Button
      size="sm"
      className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white h-7 text-xs"
      onClick={() => setNotifyOpen(true)}
    >
      <Bell className="w-3 h-3 mr-1" />
      Notify Sprint Team
    </Button>
  </CardHeader>

The blue alert box inside the card now only contains: the AlertCircle icon + the sprint risk text + the "Velocity slightly ahead" line below. No button inside it anymore.

CHANGE 5 — Center "Actions" button and add placeholder popup on click:
Add state: const [actionsOpen, setActionsOpen] = useState(false); const [actionsIncident, setActionsIncident] = useState("");

In each incident row, change the Actions Button:
  - Remove ml-auto from the button (so it is naturally centered in its flex row — make the second line of each incident row use justify-between with the status text on the left and the button centered using mx-auto)
  - Actually: change the second line of each incident row to:
      <div className="flex items-center justify-between text-xs text-gray-600 mt-1">
        <span>{assignment group text}</span>
        <div className="flex-1 flex justify-center">
          <Button
            variant="outline"
            size="sm"
            className="text-xs h-7 px-3 border-gray-300 text-gray-600 hover:border-[#2649B2] hover:text-[#2649B2]"
            onClick={() => { setActionsIncident(incidentId); setActionsOpen(true); }}
          >
            Actions
          </Button>
        </div>
        <span className="text-orange-600 font-medium">{status}</span>
      </div>

Add this Dialog at the end of the Dashboard JSX:
  <Dialog open={actionsOpen} onOpenChange={setActionsOpen}>
    <DialogContent className="sm:max-w-[400px]">
      <DialogHeader>
        <DialogTitle className="text-base font-semibold">Actions — {actionsIncident}</DialogTitle>
      </DialogHeader>
      <div className="space-y-2 py-2">
        {[
          { label: "Assign to team", icon: Users, description: "Select an assignment group to own this incident" },
          { label: "Escalate to P0", icon: AlertTriangle, description: "Escalate priority — notify management" },
          { label: "Link to story", icon: ClipboardList, description: "Associate this incident with a sprint story" },
          { label: "Mark as resolved", icon: CheckCircle, description: "Close this incident and log resolution notes" },
          { label: "Request update", icon: MessageSquare, description: "Send a status update request to the assignee" },
        ].map((action, idx) => (
          <button
            key={idx}
            className="w-full flex items-start gap-3 p-3 rounded-lg border border-gray-200 hover:border-[#2649B2] hover:bg-blue-50 transition-colors text-left group"
            onClick={() => setActionsOpen(false)}
          >
            <action.icon className="w-4 h-4 text-gray-400 group-hover:text-[#2649B2] mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-gray-900 group-hover:text-[#2649B2]">{action.label}</p>
              <p className="text-xs text-gray-500">{action.description}</p>
            </div>
          </button>
        ))}
      </div>
    </DialogContent>
  </Dialog>

Import Users, AlertTriangle, ClipboardList, CheckCircle, MessageSquare from lucide-react if not already imported.

─────────────────────────────────────────
SPRINTREVIEW.TSX — Add Assignment Group selector to Sprint Recap
─────────────────────────────────────────

CHANGE 6 — Add Assignment Group Select in the Sprint Recap card selector row:
In the selector row at the top of Sprint Recap CardContent (the px-4 pt-4 pb-3 border-b row), add a second Select after the Sprint selector:

  <div className="px-4 pt-4 pb-3 border-b border-gray-100 flex flex-wrap items-center gap-3 flex-shrink-0">
    <div className="flex items-center gap-2">
      <span className="text-sm text-gray-700">Sprint</span>
      [existing Sprint Select unchanged]
    </div>
    <div className="flex items-center gap-2">
      <span className="text-sm text-gray-700">Group</span>
      <Select defaultValue="all">
        <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Groups</SelectItem>
          <SelectItem value="data-finance">DATA - Finance L3 BTDP</SelectItem>
          <SelectItem value="data-sourcing">DATA - Sourcing L3 BTDP</SelectItem>
          <SelectItem value="supply">Supply</SelectItem>
          <SelectItem value="sourcing">Sourcing</SelectItem>
          <SelectItem value="product">Product</SelectItem>
          <SelectItem value="marketing">Marketing</SelectItem>
        </SelectContent>
      </Select>
    </div>
  </div>

─────────────────────────────────────────
CAPACITYPLANNER.TSX — Multiple changes
─────────────────────────────────────────

CHANGE 7 — Replace Add Developer dropdown with a multi-select panel trigger:
Add state: const [devPickerOpen, setDevPickerOpen] = useState(false); const [selectedDevs, setSelectedDevs] = useState<string[]>([]);

Replace the Add Developer Select with:
  <Button
    className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white h-9 text-sm"
    onClick={() => setDevPickerOpen(true)}
  >
    <Plus className="w-4 h-4 mr-2" />
    Add Developer
  </Button>

Add this Dialog for the developer picker:
  <Dialog open={devPickerOpen} onOpenChange={setDevPickerOpen}>
    <DialogContent className="sm:max-w-[420px]">
      <DialogHeader>
        <DialogTitle className="text-base font-semibold">Select Developers to Add</DialogTitle>
      </DialogHeader>
      <div className="space-y-2 py-2">
        <p className="text-xs text-gray-500 mb-3">Select one or more developers to include in this sprint.</p>
        <div className="grid grid-cols-2 gap-2">
          {[
            { name: "Alexandre Martin", avatar: "AM", type: "Backend" },
            { name: "Claire Fontaine", avatar: "CF", type: "Frontend" },
            { name: "David Renard", avatar: "DR", type: "Data Eng." },
            { name: "Isabelle Caron", avatar: "IC", type: "QA" },
            { name: "Nicolas Lefebvre", avatar: "NL", type: "Backend" },
            { name: "Pauline Mercier", avatar: "PM", type: "Frontend" },
          ].map((dev) => {
            const isSelected = selectedDevs.includes(dev.name);
            return (
              <button
                key={dev.name}
                className={`flex items-center gap-2 p-3 rounded-lg border transition-colors text-left ${isSelected ? "border-[#2649B2] bg-blue-50" : "border-gray-200 hover:border-gray-300 bg-white"}`}
                onClick={() => setSelectedDevs(prev => isSelected ? prev.filter(d => d !== dev.name) : [...prev, dev.name])}
              >
                <div className="w-7 h-7 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-[10px] font-medium">{dev.avatar}</span>
                </div>
                <div>
                  <p className="text-xs font-medium text-gray-900 leading-tight">{dev.name}</p>
                  <p className="text-[10px] text-gray-400">{dev.type}</p>
                </div>
                {isSelected && <CheckCircle className="w-4 h-4 text-[#2649B2] ml-auto flex-shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>
      <div className="flex justify-end gap-2 border-t border-gray-100 pt-3">
        <Button variant="outline" onClick={() => setDevPickerOpen(false)}>Cancel</Button>
        <Button className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white" onClick={() => setDevPickerOpen(false)}>
          Add {selectedDevs.length > 0 ? `(${selectedDevs.length})` : ""} to Sprint
        </Button>
      </div>
    </DialogContent>
  </Dialog>

Import CheckCircle from lucide-react. Add useState for devPickerOpen and selectedDevs.

CHANGE 8 — Update Send confirmation popup text:
Change the confirmation message in the Send Dialog to:
  "Are you sure you want to send all the stories to ServiceNow? This will push <span className="font-semibold text-[#2649B2]">8 stories</span> from <span className="font-semibold text-[#2649B2]">Sprint #24</span> to ServiceNow and update their status, assignees, and priorities accordingly."

─────────────────────────────────────────
DAILY.TSX — Interactive timer + dual Notify popup
─────────────────────────────────────────

CHANGE 9 — Make timer fully interactive:
Add these imports at the top: import { useState, useRef, useEffect } from "react";

Add this state and logic inside the Daily component (before the return):
  const [timeLeft, setTimeLeft] = useState(15 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startTimer = () => {
    if (isRunning || timeLeft === 0) return;
    setIsRunning(true);
    intervalRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(intervalRef.current!);
          setIsRunning(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const pauseTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setIsRunning(false);
  };

  const resetTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setIsRunning(false);
    setTimeLeft(15 * 60);
  };

  useEffect(() => {
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  const formatTime = (s: number) => `${Math.floor(s/60).toString().padStart(2,'0')}:${(s%60).toString().padStart(2,'0')}`;

Replace the timer display "15:00" with: {formatTime(timeLeft)}
Add a dynamic color: if timeLeft <= 60 → text-red-600, if timeLeft <= 3*60 → text-orange-500, else text-[#2649B2]

Update the Progress bar: value={(( 15*60 - timeLeft) / (15*60)) * 100}

Wire up buttons:
  Start Button onClick={() => startTimer()} — disabled when isRunning or timeLeft === 0
  Pause Button onClick={() => pauseTimer()} — disabled when !isRunning
  Reset Button onClick={() => resetTimer()}

Keep all dimensions exactly as they are (h-8 buttons, text-2xl countdown, compact banner layout).

CHANGE 10 — Dual Notify popup (Dev + DPO):
Update the notifyModal state to also track open state:
  const [notifyModal, setNotifyModal] = useState<{ open: boolean; devName: string; storyTitle: string; estimated: number; elapsed: number }>({ open: false, devName: "", storyTitle: "", estimated: 0, elapsed: 0 });

Replace the current single-frame Dialog with a two-frame layout inside the DialogContent:

  <DialogContent className="sm:max-w-[600px]">
    <DialogHeader>
      <DialogTitle className="text-base font-semibold">Send notification — {notifyModal.storyTitle}</DialogTitle>
    </DialogHeader>
    <div className="grid grid-cols-2 gap-4 mt-2">

      {/* Frame 1 — Developer */}
      <div className="space-y-2">
        <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-[#2649B2] inline-block"></span>
          Developer — {notifyModal.devName}
        </p>
        <div className="bg-gray-50 rounded-xl p-3 border border-gray-200">
          <div className="flex items-start gap-2">
            <div className="w-7 h-7 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
              <Bot className="w-3.5 h-3.5 text-white" />
            </div>
            <div className="bg-white rounded-lg p-2.5 shadow-sm border border-gray-100 flex-1">
              <Textarea
                className="border-0 p-0 text-xs text-gray-700 resize-none focus-visible:ring-0 min-h-[90px] bg-transparent"
                defaultValue={`Hi ${notifyModal.devName},\n\nYour story "${notifyModal.storyTitle}" is delayed — estimated at ${notifyModal.estimated} days but ${notifyModal.elapsed} days have elapsed.\n\nCould you share a quick update and flag any blockers? Thanks!`}
              />
            </div>
          </div>
        </div>
        <Button size="sm" className="w-full bg-[#2649B2] hover:bg-[#1d3a8f] text-white h-7 text-xs" onClick={() => setNotifyModal(prev => ({ ...prev, open: false }))}>
          <Send className="w-3 h-3 mr-1" /> Send to Developer
        </Button>
      </div>

      {/* Frame 2 — DPO */}
      <div className="space-y-2">
        <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-orange-500 inline-block"></span>
          Data Product Owner (DPO)
        </p>
        <div className="bg-gray-50 rounded-xl p-3 border border-gray-200">
          <div className="flex items-start gap-2">
            <div className="w-7 h-7 rounded-full bg-orange-500 flex items-center justify-center flex-shrink-0">
              <Bot className="w-3.5 h-3.5 text-white" />
            </div>
            <div className="bg-white rounded-lg p-2.5 shadow-sm border border-gray-100 flex-1">
              <Textarea
                className="border-0 p-0 text-xs text-gray-700 resize-none focus-visible:ring-0 min-h-[90px] bg-transparent"
                defaultValue={`Hi DPO,\n\nThis is an alert regarding "${notifyModal.storyTitle}" assigned to ${notifyModal.devName}. The story is delayed — estimated at ${notifyModal.estimated} days but ${notifyModal.elapsed} days have elapsed.\n\nYour attention may be required. Please review and advise. Thanks!`}
              />
            </div>
          </div>
        </div>
        <Button size="sm" variant="outline" className="w-full border-orange-300 text-orange-600 hover:bg-orange-50 h-7 text-xs" onClick={() => setNotifyModal(prev => ({ ...prev, open: false }))}>
          <Send className="w-3 h-3 mr-1" /> Send to DPO
        </Button>
      </div>

    </div>
  </DialogContent>

Do not change any other logic, mock data, colors, or layout outside what is specified above.