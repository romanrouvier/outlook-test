Apply all of the following changes across App.tsx, SprintReview.tsx, Daily.tsx, CapacityPlanner.tsx, and Availability.tsx.

─────────────────────────────────────────
APP.TSX — Reorder navigation tabs
─────────────────────────────────────────
Change the navItems array order to:
  1. { path: "/", label: "Product Lead Portal", icon: LayoutDashboard }
  2. { path: "/daily", label: "Daily", icon: Timer }
  3. { path: "/sprint-review", label: "Sprint Review", icon: ClipboardList }
  4. { path: "/capacity-planner", label: "Capacity Planner", icon: Calendar }
  5. { path: "/availability", label: "Availability", icon: CalendarClock }

─────────────────────────────────────────
SPRINTREVIEW.TSX — Fix Release Notes + Add analysis to both popups
─────────────────────────────────────────

CHANGE 1 — Fix Developments Included overflow in Release Notes card:
The items are being cut off. Replace the Developments Included section with:
  <div className="flex-1 min-h-0 flex flex-col">
    <div className="px-4 py-2 bg-gray-50 border-b border-gray-100 border-t border-t-gray-100 flex-shrink-0">
      <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide">Developments Included</h3>
    </div>
    <ScrollArea className="flex-1">
      <div className="divide-y divide-gray-100 px-4">
        {all 7 story rows unchanged}
      </div>
    </ScrollArea>
  </div>

The CardContent of Release Notes must be className="p-0 flex flex-col h-full overflow-hidden" with flex-shrink-0 on all fixed-height blocks (selector row, summary strip) and flex-1 min-h-0 on the scrollable section. The Generate button div at the bottom must be flex-shrink-0 border-t border-gray-100 px-4 py-3.

CHANGE 2 — Add analysis section to Generate Sprint Recap popup:
Inside the recapOpen Dialog, after the Deferred and Cancelled sections, add:

  <div className="border-t border-gray-100 pt-3">
    <p className="font-semibold text-gray-800 mb-3">📊 Sprint Analysis</p>
    <div className="space-y-3">
      <div className="bg-green-50 border border-green-100 rounded-lg p-3">
        <p className="text-xs font-semibold text-green-700 uppercase tracking-wide mb-1.5">✅ What went well</p>
        <ul className="space-y-1 text-sm text-gray-700">
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />9 stories delivered on time with no regression in production</li>
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />API performance improvements exceeded targets — 40% response time reduction</li>
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />Zero P1 incidents opened during the sprint cycle</li>
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />Team collaboration improved — daily standup attendance at 100%</li>
        </ul>
      </div>
      <div className="bg-orange-50 border border-orange-100 rounded-lg p-3">
        <p className="text-xs font-semibold text-orange-700 uppercase tracking-wide mb-1.5">⚠️ What needs improvement</p>
        <ul className="space-y-1 text-sm text-gray-700">
          <li className="flex items-start gap-2"><ChevronRight className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />3 stories deferred — external blockers not flagged early enough in the sprint</li>
          <li className="flex items-start gap-2"><ChevronRight className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />Story estimation accuracy below target: 2 stories consumed over 150% of estimated time</li>
          <li className="flex items-start gap-2"><ChevronRight className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />Frontend capacity under-utilized in week 1 due to late design validation</li>
        </ul>
      </div>
      <div className="bg-blue-50 border border-blue-100 rounded-lg p-3">
        <p className="text-xs font-semibold text-[#2649B2] uppercase tracking-wide mb-1.5">💡 Recommendations</p>
        <ul className="space-y-1 text-sm text-gray-700">
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Run a pre-sprint dependency check with external teams before sprint start</li>
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Flag blockers within 24h of detection — escalate to Product Lead immediately</li>
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Calibrate estimation using velocity data from the last 3 sprints</li>
        </ul>
      </div>
    </div>
  </div>

CHANGE 3 — Add analysis section to Generate Release Note popup:
Inside the releaseOpen Dialog, after the Developments Included list, add:

  <div className="border-t border-gray-100 pt-3">
    <p className="font-semibold text-gray-800 mb-3">📊 Release Analysis</p>
    <div className="space-y-3">
      <div className="bg-green-50 border border-green-100 rounded-lg p-3">
        <p className="text-xs font-semibold text-green-700 uppercase tracking-wide mb-1.5">✅ What went well</p>
        <ul className="space-y-1 text-sm text-gray-700">
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />Release deployed to production with zero rollback — full stability</li>
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />All 7 developments validated in staging before go-live</li>
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />SSO fix resolved a recurring issue affecting 200+ daily active users</li>
        </ul>
      </div>
      <div className="bg-orange-50 border border-orange-100 rounded-lg p-3">
        <p className="text-xs font-semibold text-orange-700 uppercase tracking-wide mb-1.5">⚠️ Points of attention</p>
        <ul className="space-y-1 text-sm text-gray-700">
          <li className="flex items-start gap-2"><ChevronRight className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />BQ cache changes require monitoring for the next 48h — watch query latency</li>
          <li className="flex items-start gap-2"><ChevronRight className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />iClosing URL migration may require user communication to update bookmarks</li>
        </ul>
      </div>
      <div className="bg-blue-50 border border-blue-100 rounded-lg p-3">
        <p className="text-xs font-semibold text-[#2649B2] uppercase tracking-wide mb-1.5">💡 Next steps</p>
        <ul className="space-y-1 text-sm text-gray-700">
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Monitor production dashboards for 72h post-release</li>
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Send user communication for iClosing URL change to all impacted teams</li>
          <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Schedule Release 2.4.1 patch window if BQ anomalies are detected</li>
        </ul>
      </div>
    </div>
  </div>

─────────────────────────────────────────
DAILY.TSX — Story rows: uniform card frame for all stories
─────────────────────────────────────────

CHANGE 4 — Give all story rows a bordered card frame:
Currently only delayed stories have a colored background block. Apply a card frame to ALL story rows regardless of delay status:

Normal (not delayed) story block:
  className="border border-gray-200 rounded-lg p-2 bg-white space-y-1 mb-2"

Delayed story block:
  className="border border-red-300 rounded-lg p-2 bg-red-50 space-y-1 mb-2"

Remove the old -mx-2 px-2 approach entirely. Every story block is now a self-contained rounded bordered card sitting inside the CardContent space-y-0 list (remove space-y-2 from the parent, the mb-2 on each card provides spacing).

─────────────────────────────────────────
CAPACITYPLANNER.TSX — Multiple changes
─────────────────────────────────────────

CHANGE 5 — Add Developer button: replace with a Select picklist:
Replace the current plain "Add developer" Button in the Individual Team Capacity CardHeader with a Select component that looks like a button:

  <Select>
    <SelectTrigger className="w-auto h-9 bg-[#2649B2] text-white border-[#2649B2] hover:bg-[#1d3a8f] px-3 rounded-md text-sm font-medium">
      <Plus className="w-4 h-4 mr-2" />
      <SelectValue placeholder="Add developer" />
    </SelectTrigger>
    <SelectContent>
      <SelectItem value="alex">Alexandre Martin</SelectItem>
      <SelectItem value="claire">Claire Fontaine</SelectItem>
      <SelectItem value="david">David Renard</SelectItem>
      <SelectItem value="isabelle">Isabelle Caron</SelectItem>
      <SelectItem value="nicolas">Nicolas Lefebvre</SelectItem>
      <SelectItem value="pauline">Pauline Mercier</SelectItem>
    </SelectContent>
  </Select>

CHANGE 6 — Filter button in Sprint Content: add a dropdown:
Replace the plain Filter Button with a Select that looks like an outlined button:

  <Select>
    <SelectTrigger className="w-auto h-8 border-gray-300 text-gray-700 text-sm px-3">
      <Filter className="w-4 h-4 mr-2" />
      <SelectValue placeholder="Filter" />
    </SelectTrigger>
    <SelectContent>
      <SelectItem value="all">All stories</SelectItem>
      <SelectItem value="critical">Priority: Critical</SelectItem>
      <SelectItem value="blocked">Status: Blocked</SelectItem>
      <SelectItem value="marie">Assigned: Marie Dupont</SelectItem>
      <SelectItem value="jean">Assigned: Jean Martin</SelectItem>
      <SelectItem value="sophie">Assigned: Sophie Bernard</SelectItem>
      <SelectItem value="pierre">Assigned: Pierre Leroy</SelectItem>
    </SelectContent>
  </Select>

CHANGE 7 — Send button confirmation popup:
Add state: const [sendConfirmOpen, setSendConfirmOpen] = useState(false);

Change the Send Button onClick to: onClick={() => setSendConfirmOpen(true)}

Add this Dialog before the component's closing </div>:
  <Dialog open={sendConfirmOpen} onOpenChange={setSendConfirmOpen}>
    <DialogContent className="sm:max-w-[400px]">
      <DialogHeader>
        <DialogTitle className="text-base font-semibold">Confirm Send</DialogTitle>
      </DialogHeader>
      <div className="py-3 space-y-3">
        <div className="flex items-start gap-3 bg-blue-50 border border-blue-100 rounded-lg p-3">
          <AlertCircle className="w-5 h-5 text-[#2649B2] flex-shrink-0 mt-0.5" />
          <p className="text-sm text-gray-700">Are you sure you want to send the current sprint content to all team members? This will notify <span className="font-semibold text-[#2649B2]">8 developers</span> with the latest story assignments and priorities for <span className="font-semibold text-[#2649B2]">Sprint #24</span>.</p>
        </div>
      </div>
      <div className="flex justify-end gap-2 border-t border-gray-100 pt-3">
        <Button variant="outline" onClick={() => setSendConfirmOpen(false)}>Cancel</Button>
        <Button className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white" onClick={() => setSendConfirmOpen(false)}>
          <Send className="w-4 h-4 mr-2" />
          Yes, send
        </Button>
      </div>
    </DialogContent>
  </Dialog>

Import Dialog, DialogContent, DialogHeader, DialogTitle from "./ui/dialog" and AlertCircle from lucide-react if not already imported. Add useState import.

CHANGE 8 — Individual Team Capacity: restructure each member row layout:
Each member row currently has avatar+name on the LEFT and stats+progress+minus on the RIGHT.
Restructure so the layout from left to right is:
  [Minus button] [Progress bar + Total + Alloc stats] [Avatar + Name on the right]

New row structure:
  <div className="flex items-center gap-3 py-2 border-b border-gray-100">
    {/* Far left: minus button */}
    <Button variant="outline" size="icon" className="h-6 w-6 border-red-300 text-red-600 hover:bg-red-50 hover:border-red-500 flex-shrink-0 rounded-md">
      <Minus className="w-3 h-3" />
    </Button>

    {/* Left-center: progress + stats */}
    <div className="flex items-center gap-3 flex-shrink-0">
      <Progress value={allocPercentage} className={`w-20 h-1.5 ${allocPercentage > 100 ? 'bg-red-200' : ''}`} />
      <span className="text-xs text-gray-500 whitespace-nowrap">Total: {member.capacity} MD</span>
      <span className="text-xs text-gray-600 font-medium whitespace-nowrap">Alloc: {member.allocated} MD</span>
    </div>

    {/* Right: avatar + name pushed to the right */}
    <div className="flex items-center gap-2 ml-auto">
      <span className="text-sm text-gray-800">{member.name}</span>
      <Avatar className="w-6 h-6">
        <AvatarFallback className="bg-[#2649B2] text-white text-[11px]">{member.avatar}</AvatarFallback>
      </Avatar>
    </div>
  </div>

─────────────────────────────────────────
AVAILABILITY.TSX — Multiple changes
─────────────────────────────────────────

CHANGE 9 — Rename "Developer" to "Person" in the calendar header:
Change the sticky left header th text from "Developer" to "Person" (text-xs font-medium text-gray-600 uppercase).

CHANGE 10 — Add "Type" column as the second sticky column:
After the sticky "Person" name td, add a new sticky column "Type":

In the header row (Day Numbers Row), add a second sticky th after the Person th:
  <th className="sticky left-[200px] z-30 bg-white border-r border-gray-200 p-2 text-left min-w-[80px]">
    <span className="text-xs font-medium text-gray-600 uppercase">Type</span>
  </th>

In each developer tbody row, add a second sticky td after the Person name td:
  <td className="sticky left-[200px] z-10 bg-white border-r border-gray-200 p-2">
    <Badge variant="outline" className="text-[10px] whitespace-nowrap">
      {dev.type}
    </Badge>
  </td>

Update the Sprint Row and Month Row headers to also have colSpan accounting for the extra column — add an extra empty <th> after the Person header in those rows too.

Update the developers array to include type and assignment group fields:
  const developers = [
    { name: "Marie Dupont", avatar: "MD", type: "Data Eng.", group: "DATA - Finance - BTDP L3" },
    { name: "Jean Martin", avatar: "JM", type: "Data Eng.", group: "DATA - Finance - BTDP L3" },
    { name: "Sophie Bernard", avatar: "SB", type: "Backend", group: "DATA - Finance - BTDP L3" },
    { name: "Pierre Leroy", avatar: "PL", type: "Backend", group: "Supply" },
    { name: "Lucas Petit", avatar: "LP", type: "Frontend", group: "Supply" },
    { name: "Emma Rousseau", avatar: "ER", type: "Frontend", group: "Sourcing" },
    { name: "Thomas Dubois", avatar: "TD", type: "QA", group: "Sourcing" },
    { name: "Léa Moreau", avatar: "LM", type: "Product", group: "Product" },
  ];

CHANGE 11 — Add assignment group header rows in the calendar:
Group developers by their group field and render a group header row before each group's developers:

Before each group of developer rows, insert a <tr> acting as a group divider:
  <tr className="bg-[#EEF2FF] border-b border-[#C7D2FE]">
    <td className="sticky left-0 z-10 bg-[#EEF2FF] border-r border-[#C7D2FE] px-3 py-1.5" colSpan={2}>
      <span className="text-xs font-semibold text-[#2649B2] uppercase tracking-wide">{groupName}</span>
    </td>
    {calendar.map((_, idx) => (
      <td key={idx} className="border-r border-[#C7D2FE] bg-[#EEF2FF]" />
    ))}
  </tr>

Groups in order: "DATA - Finance - BTDP L3", "Supply", "Sourcing", "Product"

CHANGE 12 — Make sprints 3 weeks long:
Update generateCalendar to cover 3-week sprints. Change the calendar range to April 15 → May 6 for Sprint 24 (21 days), and May 7 → May 27 for Sprint 25. Update the sprint assignment logic accordingly:
  sprint: day in 15 Apr – 05 May → "Sprint 24"
  sprint: day in 06 May – 26 May → "Sprint 25"

Adjust the loop ranges in generateCalendar to produce the correct date ranges covering these 3-week windows.

Do not change any other file or logic outside what is specified above.