Apply all of the following changes across App.tsx, Dashboard.tsx, and SprintReview.tsx.

─────────────────────────────────────────
APP.TSX — Profile icon in navigation
─────────────────────────────────────────

CHANGE 1 — Add profile dropdown in the nav bar top right:
Add these imports: import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "./components/ui/dropdown-menu" and import { User, Settings, LogOut, HelpCircle, Bell, Shield } from "lucide-react".

In the Navigation component, change the nav div to flex items-center justify-between. Keep the existing navItems flex row on the left. Add this profile dropdown on the right:

  <DropdownMenu>
    <DropdownMenuTrigger asChild>
      <button className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-gray-100 transition-colors outline-none">
        <div className="w-8 h-8 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
          <span className="text-white text-xs font-semibold">AL</span>
        </div>
        <div className="text-left hidden lg:block">
          <p className="text-xs font-semibold text-gray-900 leading-tight">Alex Laurent</p>
          <p className="text-[10px] text-gray-500 leading-tight">Product Lead</p>
        </div>
        <ChevronDown className="w-3 h-3 text-gray-400 hidden lg:block" />
      </button>
    </DropdownMenuTrigger>
    <DropdownMenuContent align="end" className="w-56">
      <DropdownMenuLabel>
        <div className="flex items-center gap-3 py-1">
          <div className="w-10 h-10 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
            <span className="text-white text-sm font-semibold">AL</span>
          </div>
          <div>
            <p className="text-sm font-semibold text-gray-900">Alex Laurent</p>
            <p className="text-xs text-gray-500">alex.laurent@loreal.com</p>
            <p className="text-[10px] text-[#2649B2] font-medium">Product Lead · BTDP</p>
          </div>
        </div>
      </DropdownMenuLabel>
      <DropdownMenuSeparator />
      <DropdownMenuItem className="gap-2 cursor-pointer">
        <User className="w-4 h-4 text-gray-500" />
        <span>My Profile</span>
      </DropdownMenuItem>
      <DropdownMenuItem className="gap-2 cursor-pointer">
        <Settings className="w-4 h-4 text-gray-500" />
        <span>Settings</span>
      </DropdownMenuItem>
      <DropdownMenuItem className="gap-2 cursor-pointer">
        <Bell className="w-4 h-4 text-gray-500" />
        <span>Notifications</span>
        <span className="ml-auto bg-[#2649B2] text-white text-[10px] rounded-full px-1.5 py-0.5">3</span>
      </DropdownMenuItem>
      <DropdownMenuItem className="gap-2 cursor-pointer">
        <Shield className="w-4 h-4 text-gray-500" />
        <span>Permissions</span>
      </DropdownMenuItem>
      <DropdownMenuItem className="gap-2 cursor-pointer">
        <HelpCircle className="w-4 h-4 text-gray-500" />
        <span>Help & Support</span>
      </DropdownMenuItem>
      <DropdownMenuSeparator />
      <DropdownMenuItem className="gap-2 cursor-pointer text-red-600 focus:text-red-600 focus:bg-red-50">
        <LogOut className="w-4 h-4" />
        <span>Disconnect</span>
      </DropdownMenuItem>
    </DropdownMenuContent>
  </DropdownMenu>

Import ChevronDown from lucide-react if not already imported.

─────────────────────────────────────────
DASHBOARD.TSX — Burndown chart below all widgets
─────────────────────────────────────────

CHANGE 2 — Add Sprint Burndown chart as a full-width card below the 4-widget grid:
Add these imports at the top of Dashboard.tsx:
  import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from "recharts";

After the closing </div> of the 4-widget grid (grid-cols-1 lg:grid-cols-2), add:

  <Card className="bg-white shadow-md border border-gray-100 mt-4">
    <CardHeader className="flex-shrink-0 border-b border-gray-100 flex flex-row items-center justify-between py-3">
      <div>
        <CardTitle className="text-base">Sprint Burndown — Sprint #24</CardTitle>
        <p className="text-xs text-gray-500 mt-0.5">15/04 → 05/05 · Remaining story points over time</p>
      </div>
      <div className="flex items-center gap-4 text-xs">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-0.5 bg-gray-300 rounded" style={{borderTop: '2px dashed #9ca3af'}}></div>
          <span className="text-gray-500">Ideal</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-0.5 bg-[#2649B2] rounded"></div>
          <span className="text-gray-500">Actual</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-0.5 bg-orange-400 rounded" style={{borderTop: '2px dashed #fb923c'}}></div>
          <span className="text-gray-500">Forecast</span>
        </div>
      </div>
    </CardHeader>
    <CardContent className="p-3 pt-4">
      <ResponsiveContainer width="100%" height={220}>
        <LineChart
          data={[
            { day: "D1", ideal: 141, actual: 141 },
            { day: "D2", ideal: 134, actual: 138 },
            { day: "D3", ideal: 127, actual: 132 },
            { day: "D4", ideal: 120, actual: 126 },
            { day: "D5", ideal: 113, actual: 118 },
            { day: "D6", ideal: 106, actual: 118 },
            { day: "D7", ideal: 99, actual: 118 },
            { day: "D8", ideal: 92, actual: 110 },
            { day: "D9", ideal: 85, actual: 102 },
            { day: "D10", ideal: 78, actual: 96 },
            { day: "D11", ideal: 71, actual: 88 },
            { day: "D12", ideal: 64, actual: 82 },
            { day: "D13", ideal: 57, actual: 57, forecast: 57 },
            { day: "D14", ideal: 50, forecast: 50 },
            { day: "D15", ideal: 43, forecast: 43 },
            { day: "D16", ideal: 36, forecast: 36 },
            { day: "D17", ideal: 29, forecast: 29 },
            { day: "D18", ideal: 22, forecast: 22 },
            { day: "D19", ideal: 15, forecast: 15 },
            { day: "D20", ideal: 8, forecast: 8 },
            { day: "D21", ideal: 0, forecast: 0 },
          ]}
          margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis dataKey="day" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} width={35} unit=" pts" />
          <Tooltip
            contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e5e7eb', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
            formatter={(value: number, name: string) => [
              `${value} pts remaining`,
              name === 'ideal' ? 'Ideal' : name === 'actual' ? 'Actual' : 'Forecast'
            ]}
          />
          <ReferenceLine x="D13" stroke="#e5e7eb" strokeDasharray="4 4" label={{ value: 'Today', fontSize: 10, fill: '#9ca3af' }} />
          <Line type="monotone" dataKey="ideal" stroke="#d1d5db" strokeDasharray="5 5" strokeWidth={1.5} dot={false} name="ideal" />
          <Line type="monotone" dataKey="actual" stroke="#2649B2" strokeWidth={2} dot={{ r: 3, fill: '#2649B2' }} connectNulls={false} name="actual" />
          <Line type="monotone" dataKey="forecast" stroke="#fb923c" strokeDasharray="4 4" strokeWidth={1.5} dot={false} connectNulls={false} name="forecast" />
        </LineChart>
      </ResponsiveContainer>
      <div className="flex items-center justify-between px-2 mt-1">
        <div className="flex items-center gap-4 text-xs text-gray-500">
          <span>Start: <span className="font-semibold text-gray-700">141 pts</span></span>
          <span>Remaining: <span className="font-semibold text-[#2649B2]">57 pts</span></span>
          <span>Delivered: <span className="font-semibold text-green-600">84 pts</span></span>
        </div>
        <span className="text-xs text-orange-500 font-medium">⚠ Forecast shows 8 pts at risk</span>
      </div>
    </CardContent>
  </Card>

─────────────────────────────────────────
SPRINTREVIEW.TSX — Group selection first in both panels
─────────────────────────────────────────

CHANGE 3 — Sprint Recap: put Group selector BEFORE Sprint selector:
Replace the current selector row in Sprint Recap CardContent with:

  <div className="px-4 pt-4 pb-3 border-b border-gray-100 flex flex-wrap items-center gap-3 flex-shrink-0">

    {/* Group first */}
    <div className="flex items-center gap-2">
      <span className="text-sm text-gray-700">Group</span>
      <Select defaultValue="all">
        <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Groups</SelectItem>
          <SelectItem value="data-finance">DATA - Finance L3 BTDP</SelectItem>
          <SelectItem value="data-sourcing">DATA - Sourcing L3 BTDP</SelectItem>
          <SelectItem value="supply">Supply</SelectItem>
          <SelectItem value="sourcing">Sourcing</SelectItem>
          <SelectItem value="product">Product</SelectItem>
          <SelectItem value="marketing">Marketing</SelectItem>
        </SelectContent>
      </Select>
    </div>

    {/* Sprint second */}
    <div className="flex items-center gap-2">
      <span className="text-sm text-gray-700">Sprint</span>
      <Select defaultValue="sprint23">
        <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="sprint22">Sprint 22 — 18/03 → 01/04</SelectItem>
          <SelectItem value="sprint23">Sprint 23 — 01/04 → 14/04</SelectItem>
          <SelectItem value="sprint24">Sprint 24 — 15/04 → 05/05</SelectItem>
        </SelectContent>
      </Select>
    </div>

  </div>

CHANGE 4 — Release Notes: add Group selector BEFORE Release selector:
Replace the current Release Notes selector row (px-4 pt-4 pb-3 border-b row) with:

  <div className="px-4 pt-4 pb-3 border-b border-gray-100 flex flex-wrap items-center gap-3 flex-shrink-0">

    {/* Group first */}
    <div className="flex items-center gap-2">
      <span className="text-sm text-gray-700">Group</span>
      <Select defaultValue="all">
        <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Groups</SelectItem>
          <SelectItem value="data-finance">DATA - Finance L3 BTDP</SelectItem>
          <SelectItem value="data-sourcing">DATA - Sourcing L3 BTDP</SelectItem>
          <SelectItem value="supply">Supply</SelectItem>
          <SelectItem value="sourcing">Sourcing</SelectItem>
          <SelectItem value="product">Product</SelectItem>
          <SelectItem value="marketing">Marketing</SelectItem>
        </SelectContent>
      </Select>
    </div>

    {/* Release second */}
    <div className="flex items-center gap-2">
      <span className="text-sm text-gray-700">Release</span>
      <Select defaultValue="release240">
        <SelectTrigger className="w-[220px]"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="release235">Release 2.3.5 — 14/04 (Prod)</SelectItem>
          <SelectItem value="release240">Release 2.4.0 — 29/04 (Prod)</SelectItem>
          <SelectItem value="release241">Release 2.4.1 — 06/05 (Staging)</SelectItem>
        </SelectContent>
      </Select>
    </div>

  </div>

Do not change any mock data, chart logic, colors, or other components outside what is explicitly described above.