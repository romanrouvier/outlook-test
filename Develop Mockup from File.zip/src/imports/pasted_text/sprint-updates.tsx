Apply all of the following changes across SprintReview.tsx, Daily.tsx, Availability.tsx, and a global shadow pass. Do not change any mock data unless explicitly stated.

─────────────────────────────────────────
SPRINTREVIEW.TSX — ALL CHANGES
─────────────────────────────────────────

CHANGE 1 — Remove the entire Sprint Note card:
Delete the full <Card> block for "Sprint Note" (the card below the 2-column grid including its CardHeader, CardContent, sprint selector, summary strip, and two-column text sections). Remove ChevronRight and X from imports if they are only used there.

CHANGE 2 — Remove Reason badges from Deferred stories:
In the Deferred to Next Sprint section, remove the <Badge> showing "Reason: {story.reason}" from every deferred story row. Each deferred row should now show only: story ID (monospace) | title | "Deferred" orange badge. No reason text at all.

CHANGE 3 — Add one "Generate" button at the bottom of Sprint Recap card:
After the 3 story sections (Completed, Deferred, Cancelled) and inside the CardContent, add a bottom action bar:
  <div className="border-t border-gray-100 px-4 py-3 flex-shrink-0">
    <Button className="w-full bg-[#2649B2] hover:bg-[#1d3a8f] text-white">
      <Sparkles className="w-4 h-4 mr-2" />
      Generate Sprint Recap
    </Button>
  </div>
Import Sparkles from lucide-react.

CHANGE 4 — Fix Release Notes Benefits overlap + add one Generate button:
The Benefits section is overlapping the Developments list. Rebuild the Release Notes CardContent as a proper flex-col layout:

<CardContent className="p-0 flex flex-col overflow-hidden" style={{ height: 'calc(100% - 60px)' }}>

  {/* Selector row */}
  <div className="px-4 pt-4 pb-3 border-b border-gray-100 flex items-center gap-3 flex-shrink-0">
    [Release Select unchanged]
  </div>

  {/* Summary strip */}
  <div className="px-4 py-3 flex items-center gap-3 bg-gray-50 border-b border-gray-100 flex-shrink-0">
    [v2.4.0 badge + date + Production badge unchanged]
  </div>

  {/* Developments Included — fixed height scrollable */}
  <div className="flex-shrink-0">
    <div className="px-4 py-2 border-b border-gray-100 bg-gray-50">
      <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide">Developments Included</h3>
    </div>
    <ScrollArea className="h-[220px]">
      <div className="divide-y divide-gray-100 px-4">
        [all story rows unchanged — story ID, type badge, title, avatar+name]
      </div>
    </ScrollArea>
  </div>

  {/* Benefits — fixed height scrollable, never overlaps */}
  <div className="flex-shrink-0 border-t border-gray-100">
    <div className="px-4 py-2 bg-gray-50 border-b border-gray-100">
      <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide">Benefits</h3>
    </div>
    <ScrollArea className="h-[120px]">
      <ul className="space-y-2 px-4 py-3">
        [all benefit list items with CheckCircle icons unchanged]
      </ul>
    </ScrollArea>
  </div>

  {/* Single action button at the bottom */}
  <div className="border-t border-gray-100 px-4 py-3 mt-auto flex-shrink-0">
    <Button className="w-full bg-[#2649B2] hover:bg-[#1d3a8f] text-white">
      <Sparkles className="w-4 h-4 mr-2" />
      Generate Release Note
    </Button>
  </div>

</CardContent>

Remove the old Export Release Note Button that was previously at the bottom. The single "Generate Release Note" button replaces it.

─────────────────────────────────────────
DAILY.TSX — ALL CHANGES
─────────────────────────────────────────

CHANGE 5 — Single Notify button with modal popup on delayed stories:
Add this import at the top of the file:
  import { useState } from "react";
  import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
  import { Textarea } from "./ui/textarea";

Add state inside the Daily component:
  const [notifyModal, setNotifyModal] = useState<{ open: boolean; devName: string; storyTitle: string; estimated: number; elapsed: number }>({
    open: false, devName: "", storyTitle: "", estimated: 0, elapsed: 0
  });

Replace the two Notify + Notify DPO buttons on delayed stories with a single button:
  <Button
    variant="outline"
    size="sm"
    className="h-7 px-3 text-[11px] border-red-300 text-red-600 hover:bg-red-50 hover:border-red-500 mt-1"
    onClick={() => setNotifyModal({ open: true, devName: dev.name, storyTitle: story.title, estimated: story.estimated, elapsed: story.elapsed })}
  >
    <MessageSquare className="w-3 h-3 mr-1" />
    Notify
  </Button>

Add the Dialog component at the very end of the returned JSX, just before the closing </div> of the main container:

<Dialog open={notifyModal.open} onOpenChange={(open) => setNotifyModal(prev => ({ ...prev, open }))}>
  <DialogContent className="sm:max-w-[480px]">
    <DialogHeader>
      <DialogTitle className="text-base font-semibold text-gray-900">Send notification</DialogTitle>
    </DialogHeader>
    <div className="space-y-4 mt-2">
      {/* Message bubble preview */}
      <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
            <Bot className="w-4 h-4 text-white" />
          </div>
          <div className="bg-white rounded-lg p-3 shadow-sm border border-gray-100 flex-1">
            <Textarea
              className="border-0 p-0 text-sm text-gray-700 resize-none focus-visible:ring-0 min-h-[100px] bg-transparent"
              defaultValue={`Hi ${notifyModal.devName},\n\nYour story "${notifyModal.storyTitle}" appears to be delayed — estimated at ${notifyModal.estimated} days but ${notifyModal.elapsed} days have elapsed.\n\nCould you share a quick update on your progress and any blockers? Thanks!`}
            />
          </div>
        </div>
      </div>
      {/* Send button */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => setNotifyModal(prev => ({ ...prev, open: false }))}>
          Cancel
        </Button>
        <Button className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white" onClick={() => setNotifyModal(prev => ({ ...prev, open: false }))}>
          <Send className="w-4 h-4 mr-2" />
          Send
        </Button>
      </div>
    </div>
  </DialogContent>
</Dialog>

Add to imports: Bot, Send from lucide-react. Import Dialog, DialogContent, DialogHeader, DialogTitle from "./ui/dialog". Import Textarea from "./ui/textarea".

─────────────────────────────────────────
AVAILABILITY.TSX — Redesign the calendar
─────────────────────────────────────────

CHANGE 6 — Make the availability calendar visually richer:

Replace the current plain table cells with this improved design:

Header row for day numbers: add the day-of-week initial below each date number:
  <div className="flex flex-col items-center gap-0.5">
    <span className="text-xs font-semibold text-gray-700">{day.date}</span>
    <span className="text-[9px] text-gray-400 uppercase">
      {new Date(day.fullDate).toLocaleDateString('en-US', { weekday: 'short' }).slice(0,1)}
    </span>
  </div>
Weekend header cells: bg-gray-50

Availability cells — replace the plain number text with visual blocks:

Full day (value === 1, not weekend):
  <td className="p-1 border-r border-gray-100">
    <div className="flex flex-col items-center justify-center rounded-lg bg-[#EEF2FF] border border-[#C7D2FE] h-9 w-full">
      <span className="text-[11px] font-semibold text-[#2649B2]">1</span>
    </div>
  </td>

Half day (value === 0.5):
  <td className="p-1 border-r border-gray-100">
    <div className="flex flex-col items-center justify-center rounded-lg bg-amber-50 border border-amber-200 h-9 w-full">
      <span className="text-[11px] font-semibold text-amber-600">½</span>
    </div>
  </td>

Unavailable (value === 0, not weekend):
  <td className="p-1 border-r border-gray-100">
    <div className="flex flex-col items-center justify-center rounded-lg bg-red-50 border border-red-100 h-9 w-full">
      <span className="text-[11px] text-red-300">—</span>
    </div>
  </td>

Weekend:
  <td className="p-1 border-r border-gray-100 bg-gray-50">
    <div className="flex flex-col items-center justify-center rounded-lg bg-gray-100 h-9 w-full">
      <span className="text-[11px] text-gray-300">·</span>
    </div>
  </td>

Total row cells: replace plain text with:
  Non-weekend total cell:
    <td className="p-1 border-r border-gray-100 bg-[#EEF2FF]">
      <div className="flex items-center justify-center h-9">
        <span className="text-sm font-bold text-[#2649B2]">{total}</span>
      </div>
    </td>
  Weekend total cell:
    <td className="p-1 border-r border-gray-100 bg-gray-50">
      <div className="flex items-center justify-center h-9">
        <span className="text-xs text-gray-300">—</span>
      </div>
    </td>

Developer name column: give each row a subtle left border colored by availability level:
  Row where all days are 1: border-l-2 border-l-green-300
  Row with at least one 0.5: border-l-2 border-l-amber-300
  Row with at least one 0 (non-weekend): border-l-2 border-l-red-300
  (compute this from the developer's availability values)

Sprint group headers: replace plain Badge with:
  <div className="bg-[#2649B2] text-white text-xs font-medium px-3 py-1 rounded-full inline-block">{group.sprint}</div>

Update the legend in the CardHeader to match the new cell styles (show the rounded-lg colored blocks as legend swatches, not plain squares).

─────────────────────────────────────────
GLOBAL — Subtle elevation pass on all Cards
─────────────────────────────────────────

CHANGE 7 — In Dashboard.tsx, CapacityPlanner.tsx, Availability.tsx, SprintReview.tsx, Daily.tsx:
Replace every instance of:
  className="bg-white shadow-sm"  →  className="bg-white shadow-md border border-gray-100"

This applies to all Card components across all pages. The border-gray-100 adds a crisp 1px outline and shadow-md gives a slightly more elevated, card-like feel without being heavy. Do not change any other class on those Cards.