Apply all of the following changes together — responsive layout fixes AND design changes. Do not change any mock data unless explicitly instructed.

─────────────────────────────────────────
APP.TSX — NAVIGATION RESPONSIVENESS
─────────────────────────────────────────
Change px-8 to px-4 lg:px-8, gap-6 to gap-1 lg:gap-3 in the nav bar.
Each nav Link: px-4 py-2 → px-2 py-2 lg:px-4. Label span: add text-xs lg:text-sm.

─────────────────────────────────────────
AIASSISTANT.TSX — RESPONSIVENESS
─────────────────────────────────────────
Outer div width: w-80 → w-64 lg:w-80. Header padding p-6 → p-4. Input area p-4 → p-3.

─────────────────────────────────────────
DASHBOARD.TSX — DESIGN CHANGES + RESPONSIVENESS
─────────────────────────────────────────
RESPONSIVENESS:
- Page header: px-8 → px-4 lg:px-8, py-6 → py-4 lg:py-6
- Alert banner px-8 → px-4 lg:px-8
- Main content area: p-8 → p-4 lg:p-6
- Main grid: grid-cols-2 → grid-cols-1 lg:grid-cols-2, remove max-w-[1600px]
- Ring gauge SVGs: add viewBox="0 0 128 128", remove fixed w/h from the SVG element, control size via parent div: w-24 h-24 lg:w-32 lg:h-32
- Sprint Timeline ScrollArea: h-[400px] → h-[300px] lg:h-[400px]

DESIGN CHANGE 1 — Active Filter Chips below the page header and above the alert banner:
Add a flex row with gap-2 px-4 lg:px-8 py-3 bg-white border-b border-gray-100.
Two filter chip buttons, styled as rounded-full border border-[#2649B2] text-[#2649B2] bg-white hover:bg-blue-50 text-sm px-4 py-1.5 font-medium with a small ChevronDown icon (w-3 h-3 ml-1):
  Button 1: "Sprint #24 ▾"
  Button 2: "All Assignment Groups ▾"
These are visual/static — no dropdown logic needed, just the button appearance.

DESIGN CHANGE 2 — "Actions" button on each incident row in the "Incidents & Defects" card:
In the Critical Items list, each incident row currently ends after the status text. Add a Button at the end of each row's second line (the flex row with assignment group and status):
  Button: variant="outline" size="sm" className="ml-auto text-xs h-7 px-3 border-gray-300 text-gray-600 hover:border-[#2649B2] hover:text-[#2649B2]"
  Label: "Actions"
The row second line should be flex items-center gap-4 with the "Actions" button pushed to the right via ml-auto.

─────────────────────────────────────────
CAPACITYPLANNER.TSX — DESIGN CHANGES + RESPONSIVENESS
─────────────────────────────────────────
RESPONSIVENESS:
- Page header: px-8 → px-4 lg:px-8, py-6 → py-4 lg:py-6
- Main content area: p-8 → p-4 lg:p-6
- Individual Team Capacity ScrollArea: h-[400px] → h-[280px] lg:h-[400px]
- Sprint Content table: wrap in overflow-x-auto div, ScrollArea h-[500px] → h-[320px] lg:h-[500px]
- Capacity Distribution grid: grid-cols-2 → grid-cols-1 lg:grid-cols-2
- Capacity Distribution donut SVG: add viewBox="0 0 256 256", control size via parent: w-48 h-48 lg:w-64 lg:h-64
- Capacity Distribution ScrollArea: h-[400px] → h-[280px] lg:h-[400px]

DESIGN CHANGE 1 — Sprint Selector bar:
The current selector bar has a left side with Calendar icon + text "Sprint #24 — 15/04 → 29/04" and a right side with a Select dropdown.
REMOVE the left-side Calendar icon and text entirely.
Keep only the Select dropdown button, and move it to be centered or left-aligned in the card. The card (white rounded-lg border p-4 mb-6) should simply contain: a label "Select Sprint:" (text-sm text-gray-600 mr-3) followed directly by the Select component.

DESIGN CHANGE 2 — Minus button on Individual Team Capacity:
The current minus Button uses variant="ghost". Change it to:
  variant="outline"
  className="h-8 w-8 border-red-300 text-red-600 hover:bg-red-50 hover:border-red-500 hover:text-red-700 flex-shrink-0 rounded-md"
This makes it a clearly bordered red outlined square button, more visible and defined.

DESIGN CHANGE 3 — Rename "Project" to "Epic" in Sprint Content table:
- Change the column header from "Project" to "Epic"
- Change the story data field display accordingly (same values, just the column label and any reference to "project" in that column context changes to "epic")

─────────────────────────────────────────
AVAILABILITY.TSX — DESIGN CHANGES + RESPONSIVENESS
─────────────────────────────────────────
RESPONSIVENESS:
- Page header: px-8 → px-4 lg:px-8, py-6 → py-4 lg:py-6
- Main content area: p-8 → p-4 lg:p-6
- Calendar overflow-auto div: max-h-[400px] lg:max-h-[600px]
- Filter bar: flex-wrap gap-3

DESIGN CHANGE 1 — REMOVE the "Sprint Stories Overview" card entirely (the card below the calendar).

DESIGN CHANGE 2 — Redesign the filter bar above the calendar:
Replace the current filter bar with this layout (white rounded-lg border card p-4 mb-6):

Row 1 — Assignment Group selector (full width, mb-3):
  Label: "Assignment Group" (text-sm font-medium text-gray-700 mb-2 block)
  A single Select component: options "All Groups", "Backend", "Frontend", "Data Engineering", "QA". Default: "All Groups".
  Style the Select trigger as w-full or w-64.

Row 2 — Members selector (below the group selector):
  Label: "Members" (text-sm font-medium text-gray-700 mb-2 block)
  Instead of a dropdown Select, show a flex flex-wrap gap-2 of toggle button chips, one per developer:
    "MD" · "JM" · "SB" · "PL" · "LP" · "ER" · "TD" · "LM"
  Each chip shows initials + full name: e.g. a rounded-full Button showing avatar initials (small circle bg-[#2649B2] text-white text-xs w-6 h-6 inline-flex items-center justify-center rounded-full mr-1) + name text (text-sm).
  Default state: all chips appear "active" — bg-blue-50 border border-[#2649B2] text-[#2649B2] rounded-full px-3 py-1 text-sm.
  These are visual toggle chips — no logic needed, just show them in the active style.
  Full names: Marie Dupont, Jean Martin, Sophie Bernard, Pierre Leroy, Lucas Petit, Emma Rousseau, Thomas Dubois, Léa Moreau.

Row 3 — A ghost "Reset filters" button (RotateCcw icon + "Reset filters", text-xs text-gray-500) aligned right.

─────────────────────────────────────────
SPRINTREVIEW.TSX — DESIGN CHANGES + RESPONSIVENESS
─────────────────────────────────────────
RESPONSIVENESS:
- Page header: px-8 → px-4 lg:px-8, py-6 → py-4 lg:py-6
- Main content area: p-8 → p-4 lg:p-6
- 2-column grid: grid-cols-2 → grid-cols-1 lg:grid-cols-2
- Story section ScrollAreas: max-h-[180px] → max-h-[150px] lg:max-h-[180px]
- Developments Included ScrollArea: max-h-[260px] → max-h-[200px] lg:max-h-[260px]

DESIGN CHANGE — Sprint Recap: keep exactly 3 story status sections, in this order:
  1. ✓ Completed — green badge header (keep as-is)
  2. ⏭ Deferred to Next Sprint — orange badge header (rename from "Pushed to Next Sprint" to "Deferred")
  3. ✕ Cancelled — gray badge header (keep as-is)
Remove the KPI summary chips row (the "14 Planned / 9 Completed / 3 Deferred" inline boxes) — just keep the Select dropdown and go straight to the 3 sections.

─────────────────────────────────────────
DAILY.TSX — DESIGN OVERHAUL + RESPONSIVENESS
─────────────────────────────────────────
RESPONSIVENESS:
- Page header: px-8 → px-4 lg:px-8, py-6 → py-4 lg:py-6
- Main content area: p-8 → p-4 lg:p-6
- Timer text: text-6xl → text-4xl lg:text-6xl, my-4 → my-2 lg:my-4

DESIGN OVERHAUL — Developer story cards:
The current 2-column grid of wide cards makes each story row hard to read because titles are truncated and rows are too spacious. Replace the grid of large cards with a more compact focused design:

Change the developer grid to: grid-cols-2 md:grid-cols-3 lg:grid-cols-4
This gives narrower cards (4 across on large screens, 3 on medium, 2 on small) so each developer card is compact and readable.

Inside each developer card:
- Reduce card padding: CardContent p-4 → p-3
- Story rows: make them more vertical and stacked, not horizontal:
  Each story is its own mini-block (div with border-b border-gray-100 py-2 space-y-1):
    Line 1: story ID (font-mono text-[11px] text-gray-400) + status Badge on the same line (flex items-center justify-between)
    Line 2: title (text-[13px] text-gray-800 leading-snug, allow wrapping to 2 lines, NO truncation — remove the truncate class and max-w constraint entirely)
    Line 3: "Est: X d · Elapsed: Y d" (text-[11px] text-gray-500)
    Line 4 (only if DELAYED): flex items-center gap-1: red "Delayed" badge (text-[11px]) + MessageSquare Button (ghost, h-5 w-5, icon w-3 h-3)
  If DELAYED: the entire story block has bg-red-50 rounded-md px-2 -mx-2

- Card header: reduce to py-2, show avatar (w-7 h-7, text-[11px]) + name (text-sm font-medium) + story count badge (text-xs)

The status legend row above the grid: make it flex-wrap gap-1 with smaller badges (text-[11px]).

─────────────────────────────────────────
GLOBAL SIZING RULE
─────────────────────────────────────────
Wherever py-6 appears in page section headers → py-4 lg:py-6
Wherever px-8 appears in page-level containers → px-4 lg:px-8
Wherever p-8 appears in main content areas → p-4 lg:p-6
All major page-level grid-cols-2 → grid-cols-1 lg:grid-cols-2
Do not change any colors, component logic, mock data, or visual design beyond what is explicitly described above.
