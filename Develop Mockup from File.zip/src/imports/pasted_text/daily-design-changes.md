Apply all of the following design changes. Do not change mock data or routing logic.

─────────────────────────────────────────
DAILY.TSX — DESIGN CHANGES
─────────────────────────────────────────
CHANGE 1 — Compact timer:
Replace the current large timer card with a slim horizontal banner (not a full Card, just a div):
  div className="bg-white border border-gray-200 rounded-lg px-6 py-3 mb-4 flex items-center justify-between"
  Left side: Clock icon (w-4 h-4 text-[#2649B2] mr-2) + label "Standup Timer" (text-sm text-gray-600)
  Center: countdown display "15:00" in text-2xl font-bold text-[#2649B2] (NOT text-4xl or text-6xl)
  Right side: three compact buttons in a flex gap-2 row:
    Button bg-[#2649B2] text-white size="sm" h-8: Play icon (w-3 h-3) + "Start"
    Button variant="outline" size="sm" h-8: Pause icon (w-3 h-3) + "Pause"
    Button variant="ghost" size="sm" h-8: RotateCcw icon (w-3 h-3) + "Reset"
  Below this banner a Progress bar (h-1, value=0, full width) with no label
Remove the old large timer Card entirely.

CHANGE 2 — Remove the status legend:
Delete the entire status legend row (the flex-wrap strip showing Draft, Ready, Work in progress, Ready for testing, Testing, Complete, Cancelled badges) that appears above the developer cards grid. Remove it completely.

CHANGE 3 — Clearer message buttons on delayed stories:
For each story row marked as DELAYED, replace the small ghost icon-only MessageSquare button with a visible labeled button:
  Button variant="outline" size="sm" className="h-7 px-3 text-[11px] border-red-300 text-red-600 hover:bg-red-50 hover:border-red-500 mt-1"
  Content: MessageSquare icon (w-3 h-3 mr-1) + "Notify"
  Next to it, a second Button with the same style:
  Content: MessageSquare icon (w-3 h-3 mr-1) + "Notify DPO"
  These two buttons appear on line 4 of delayed story blocks, side by side in a flex gap-1 row.

─────────────────────────────────────────
SPRINTREVIEW.TSX — LAYOUT FIX
─────────────────────────────────────────
The overlap between sections (Deferred label overlapping Completed stories, Benefits overlapping Developments) is caused by missing spacing and ScrollArea constraints. Fix as follows:

LEFT COLUMN — Sprint Recap card:
Wrap the entire CardContent in a flex flex-col gap-4.
Each of the 3 sections (Completed, Deferred, Cancelled) must be its own div with space-y-2 and a clearly defined max height:
  - Completed ScrollArea: max-h-[160px] (hard cap, no overflow bleed)
  - Deferred ScrollArea: max-h-[140px]
  - Cancelled ScrollArea: max-h-[120px]
Each section header (the Badge line) must have mb-2 and a border-t border-gray-100 pt-3 on sections 2 and 3 to visually separate them.
Add overflow-hidden to the CardContent wrapper.

RIGHT COLUMN — Release Notes card:
Wrap CardContent in flex flex-col gap-4 with overflow-hidden.
"Developments Included" section: ScrollArea max-h-[220px] (hard cap).
"Benefits" section: place it inside its own div with border-t border-gray-100 pt-4 mt-2 and a ScrollArea max-h-[140px] wrapping the ul — so if benefits overflow they scroll instead of pushing layout.
The "Export Release Note" button must be outside the ScrollArea at the very bottom of the CardContent, with mt-auto to push it to the bottom.

─────────────────────────────────────────
CAPACITYPLANNER.TSX — DESIGN CHANGES
─────────────────────────────────────────
CHANGE 1 — Individual Team Capacity: split into left/right layout:
Replace the current full-width layout of the "Individual Team Capacity" card with a 2-column internal grid (grid-cols-2 gap-6) inside CardContent:

LEFT SIDE — Compact member list:
A ScrollArea (h-[280px] lg:h-[320px]) containing a space-y-2 list.
Each member row is smaller and more compact than before — a single flex items-center justify-between line (no tall card box):
  div className="flex items-center justify-between py-2 border-b border-gray-100"
  Left: Avatar (w-7 h-7, initials text-[11px]) + member name (text-sm text-gray-800 ml-2)
  Right: three small inline stat pills in a flex gap-3:
    "Total: 20 MD" (text-xs text-gray-500)
    "Alloc: X MD" (text-xs text-gray-600 font-medium)
    A small Progress bar (w-16 h-1.5 inline-block) showing allocated/capacity ratio, color: blue if under 100%, red if over
  The minus Button (outline, red bordered, h-6 w-6, Minus icon w-3 h-3) at the far right

RIGHT SIDE — Frontend vs Backend breakdown:
A div with a title "Capacity by Profile" (text-sm font-semibold text-gray-700 mb-4).
Show two horizontal bar sections:

Frontend developers (Thomas Dubois, Lucas Petit, Marie Dupont, Léa Moreau — 4 people):
  Label row: flex justify-between: "Frontend" (text-sm font-medium text-gray-800) + "76 MD allocated / 80 MD total" (text-xs text-gray-500)
  A Progress bar: value=95 className="h-3 mb-1" (blue fill)
  Sub-label: "4 developers · 95% allocated" text-xs text-gray-500 mb-4

Backend / Data developers (Jean Martin, Sophie Bernard, Pierre Leroy, Emma Rousseau — 4 people):
  Label row: flex justify-between: "Backend / Data" (text-sm font-medium text-gray-800) + "65 MD allocated / 80 MD total" (text-xs text-gray-500)
  A Progress bar: value=81 className="h-3 mb-1" (blue fill)
  Sub-label: "4 developers · 81% allocated" text-xs text-gray-500 mb-6

Below the two bars, a small summary card (bg-blue-50 border border-blue-100 rounded-lg p-3):
  "Team total: 141 MD allocated out of 160 MD capacity (88%)"
  text-sm text-gray-700, with "88%" in font-semibold text-[#2649B2]

Also add an "Add developer" Button (bg-[#2649B2] text-white size="sm", Plus icon) at the top-right of the CardHeader (keep it there as before).

CHANGE 2 — Capacity Distribution by Project: replace donut with bar chart:
In the "Capacity Distribution by Project/Initiative" card, REMOVE the SVG donut chart and its legend entirely.
Replace the left side (currently the donut + legend) with a vertical bar chart built with plain divs (no recharts needed):

Title above the bars: "Allocation by Project" (text-sm font-medium text-gray-700 mb-4)

A flex items-end gap-3 h-[180px] container (the bar chart area):
For each project, a flex flex-col items-center gap-1:
  The bar: a div with width w-12 lg:w-16, background bg-[#2649B2], border-radius rounded-t-md, height calculated as a percentage of the tallest bar (OneFinancePortal=100%, PO Creator=83%, Sustainable Finance=67%, Headcount=50%, Value Creation=33%)
  Use inline style for height: style={{ height: `${percentage}%` }}
  Below the bar: project percentage text-xs font-semibold text-gray-700
  Below that: project name abbreviated text-[10px] text-gray-500 text-center (e.g. "OneFinance", "PO Creator", "Sustain. Fin.", "Headcount", "Value")

The right side (the summary table with ScrollArea) stays exactly as it is.

─────────────────────────────────────────
DASHBOARD.TSX — UNIFORM CONTAINER HEIGHTS
─────────────────────────────────────────
All 4 widget Cards in the dashboard grid must have the same fixed height so the layout is perfectly homogeneous. Apply a fixed height to every Card in the grid:
  className on every Card: "bg-white shadow-sm h-[520px] flex flex-col"

Each Card's CardContent must be: className="flex-1 overflow-hidden flex flex-col"
Inside each CardContent, the scrollable content area must be wrapped in a ScrollArea with className="flex-1" (takes remaining space) so that if the content is taller than the fixed card height it scrolls internally.

Apply this to all 4 cards:
1. "Planned vs Consumed Capacity" — wrap the existing content in a ScrollArea className="flex-1"
2. "Incidents & Defects" — wrap the space-y-4 content div in a ScrollArea className="flex-1"
3. "Current Sprint Timeline" — the ScrollArea already exists, just ensure it has className="flex-1" instead of a fixed h-[300px]
4. "Project Priority Weighting" — wrap the space-y-3 projects list in a ScrollArea className="flex-1"

The CardHeader of each card must have className="flex-shrink-0" so it does not participate in the flex stretching.
This ensures all 4 cards are exactly the same height (520px), with internal scrolling for any overflow content.