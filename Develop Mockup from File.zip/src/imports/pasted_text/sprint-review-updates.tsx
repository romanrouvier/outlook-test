Apply all of the following changes together across SprintReview.tsx, CapacityPlanner.tsx, and Dashboard.tsx.

─────────────────────────────────────────
SPRINTREVIEW.TSX — CHANGE 1: Fix Sprint Recap alignment
─────────────────────────────────────────
The 3 sections inside the Sprint Recap card are bleeding into each other (the "Deferred" badge overlaps the last Completed story row). Replace the CardContent entirely with this structure:

<CardContent className="p-0 flex flex-col overflow-hidden">

  {/* Sprint Selector — top bar */}
  <div className="px-4 pt-4 pb-3 border-b border-gray-100 flex items-center gap-3 flex-shrink-0">
    <span className="text-sm text-gray-700">Sprint</span>
    [existing Select component unchanged]
  </div>

  {/* Section 1 — Completed */}
  <div className="flex-shrink-0">
    <div className="bg-gray-50 border-b border-gray-100 px-4 py-2 flex items-center gap-2">
      <Badge className="bg-green-600 text-white hover:bg-green-600">✓ Completed (9)</Badge>
    </div>
    <ScrollArea className="h-[200px]">
      <div className="divide-y divide-gray-100">
        {completed stories — same mock data, each row:}
        <div className="flex items-center gap-3 px-4 py-2">
          <span className="font-mono text-xs text-gray-400 w-[100px] flex-shrink-0">{story.id}</span>
          <span className="text-sm text-gray-900 flex-1">{story.title}</span>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Avatar w-6 h-6 with initials>
            <span className="text-xs text-gray-600">{story.assignee}</span>
          </div>
          <Badge className="bg-green-600 text-white text-xs flex-shrink-0">Complete</Badge>
        </div>
      </div>
    </ScrollArea>
  </div>

  {/* Section 2 — Deferred */}
  <div className="flex-shrink-0 border-t border-gray-100">
    <div className="bg-gray-50 border-b border-gray-100 px-4 py-2 flex items-center gap-2">
      <Badge className="bg-orange-500 text-white hover:bg-orange-500">⏭ Deferred to Next Sprint (3)</Badge>
    </div>
    <ScrollArea className="h-[152px]">
      <div className="divide-y divide-gray-100">
        {deferred stories — same mock data, each row:}
        <div className="flex items-center gap-3 px-4 py-2">
          <span className="font-mono text-xs text-gray-400 w-[100px] flex-shrink-0">{story.id}</span>
          <span className="text-sm text-gray-900 flex-1">{story.title}</span>
          <Badge variant="outline" className="text-xs text-orange-600 border-orange-400 flex-shrink-0">Reason: {story.reason}</Badge>
          <Badge className="bg-orange-500 text-white text-xs flex-shrink-0">Deferred</Badge>
        </div>
      </div>
    </ScrollArea>
  </div>

  {/* Section 3 — Cancelled */}
  <div className="flex-shrink-0 border-t border-gray-100">
    <div className="bg-gray-50 border-b border-gray-100 px-4 py-2 flex items-center gap-2">
      <Badge variant="outline" className="border-gray-500 text-gray-600">✕ Cancelled (2)</Badge>
    </div>
    <ScrollArea className="h-[120px]">
      <div className="divide-y divide-gray-100">
        {cancelled stories — same mock data, each row:}
        <div className="flex items-center gap-3 px-4 py-2">
          <span className="font-mono text-xs text-gray-400 w-[100px] flex-shrink-0">{story.id}</span>
          <span className="text-sm line-through text-gray-400 flex-1">{story.title}</span>
          <Badge variant="outline" className="border-gray-400 text-gray-500 text-xs flex-shrink-0">Cancelled</Badge>
        </div>
      </div>
    </ScrollArea>
  </div>

</CardContent>

Keep the exact same mock data arrays already in the file. Keep the Release Notes card (right column) completely unchanged.

─────────────────────────────────────────
SPRINTREVIEW.TSX — CHANGE 2: Add Sprint Note card (full width below the grid)
─────────────────────────────────────────
After the closing </div> of the grid grid-cols-1 lg:grid-cols-2 gap-6, add a new full-width Card:

<Card className="bg-white shadow-sm mt-6">
  <CardHeader>
    <CardTitle className="text-lg">Sprint Note</CardTitle>
  </CardHeader>
  <CardContent className="space-y-4">

    {/* Row 1 — Sprint selector */}
    <div className="flex items-center gap-3">
      <span className="text-sm text-gray-700">Sprint</span>
      <Select defaultValue="sprint23">
        <SelectTrigger className="w-[220px]"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="sprint22">Sprint 22 — 18/03 → 01/04</SelectItem>
          <SelectItem value="sprint23">Sprint 23 — 01/04 → 14/04</SelectItem>
          <SelectItem value="sprint24">Sprint 24 — 15/04 → 29/04</SelectItem>
        </SelectContent>
      </Select>
    </div>

    {/* Row 2 — Summary strip */}
    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
      <Badge className="bg-[#2649B2] text-white hover:bg-[#2649B2]">Sprint 23</Badge>
      <span className="text-sm text-gray-700">01/04 → 14/04</span>
      <Badge variant="outline">9/14 completed</Badge>
      <Badge variant="outline" className="border-orange-400 text-orange-600">3 deferred</Badge>
      <Badge variant="outline" className="border-gray-400 text-gray-500">2 cancelled</Badge>
    </div>

    {/* Row 3 — Two text columns */}
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">

      {/* LEFT — What was delivered */}
      <div>
        <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-3">✅ What was delivered</h3>
        <p className="text-sm text-gray-700 mb-2">
          During Sprint 23, the team successfully delivered 9 stories out of 14 planned, achieving a 64% completion rate.
        </p>
        <ul className="space-y-1.5">
          {[
            "Database migration phase 1 deployed to production — no regression detected",
            "New dashboard layout validated and released to all users",
            "API performance improvements reduced average response time by 40%",
            "User profile enhancements shipped with positive feedback from pilot group",
            "Cache optimization improved system throughput under peak load",
          ].map((item, idx) => (
            <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
              <CheckCircle className="w-3.5 h-3.5 text-green-500 flex-shrink-0 mt-0.5" />
              {item}
            </li>
          ))}
        </ul>
      </div>

      {/* RIGHT — What was not delivered */}
      <div>
        <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-3">⏭ What was not delivered</h3>

        <p className="text-xs font-semibold text-orange-600 uppercase mb-1.5">Deferred to Sprint 24</p>
        <ul className="space-y-1.5 mb-4">
          {[
            "Data warehouse migration phase 2 — blocked by external team dependency, re-planned for Sprint 25",
            "Advanced filtering UI — scope re-evaluated and reprioritized by product team",
            "Real-time notifications — third-party API integration not ready in time",
          ].map((item, idx) => (
            <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
              <ChevronRight className="w-3.5 h-3.5 text-orange-400 flex-shrink-0 mt-0.5" />
              {item}
            </li>
          ))}
        </ul>

        <p className="text-xs font-semibold text-gray-400 uppercase mb-1.5">Cancelled</p>
        <ul className="space-y-1.5">
          {[
            "Legacy IE11 compatibility fixes — browser support officially discontinued",
            "Manual CSV export endpoint — replaced by automated reporting solution",
          ].map((item, idx) => (
            <li key={idx} className="flex items-start gap-2 text-sm text-gray-500">
              <X className="w-3.5 h-3.5 text-gray-400 flex-shrink-0 mt-0.5" />
              {item}
            </li>
          ))}
        </ul>
      </div>

    </div>
  </CardContent>
</Card>

Add to imports: ChevronRight, X from lucide-react (CheckCircle is already imported).

─────────────────────────────────────────
CAPACITYPLANNER.TSX — CHANGE 3: Replace Frontend/Backend bars with 2 donut charts
─────────────────────────────────────────
In the "Individual Team Capacity" card, RIGHT SIDE ("Capacity by Profile" div), remove the two Progress bar blocks entirely and replace with:

<div className="flex items-center justify-around mb-6">

  {/* Frontend Donut */}
  <div className="flex flex-col items-center gap-2">
    <div className="relative w-28 h-28">
      <svg viewBox="0 0 128 128" className="w-full h-full transform -rotate-90">
        <circle cx="64" cy="64" r="52" fill="none" stroke="#e5e7eb" strokeWidth="10" />
        <circle cx="64" cy="64" r="52" fill="none" stroke="#2649B2" strokeWidth="10"
          strokeDasharray={`${2 * Math.PI * 52 * 0.95} ${2 * Math.PI * 52}`}
          strokeLinecap="round" />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-xl font-bold text-gray-900">95%</span>
      </div>
    </div>
    <p className="text-sm font-medium text-gray-800">Frontend</p>
    <p className="text-xs text-gray-500">76 / 80 MD</p>
    <p className="text-xs text-gray-400">4 developers</p>
  </div>

  {/* Backend / Data Donut */}
  <div className="flex flex-col items-center gap-2">
    <div className="relative w-28 h-28">
      <svg viewBox="0 0 128 128" className="w-full h-full transform -rotate-90">
        <circle cx="64" cy="64" r="52" fill="none" stroke="#e5e7eb" strokeWidth="10" />
        <circle cx="64" cy="64" r="52" fill="none" stroke="#4A5568" strokeWidth="10"
          strokeDasharray={`${2 * Math.PI * 52 * 0.81} ${2 * Math.PI * 52}`}
          strokeLinecap="round" />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-xl font-bold text-gray-900">81%</span>
      </div>
    </div>
    <p className="text-sm font-medium text-gray-800">Backend / Data</p>
    <p className="text-xs text-gray-500">65 / 80 MD</p>
    <p className="text-xs text-gray-400">4 developers</p>
  </div>

</div>

Keep the bg-blue-50 team total summary card below unchanged. Keep the "Capacity by Profile" h3 title unchanged.

─────────────────────────────────────────
CAPACITYPLANNER.TSX — CHANGE 4: Capacity Distribution — remove left bar chart
─────────────────────────────────────────
In the "Capacity Distribution by Project/Initiative" card:

REMOVE entirely the left column div containing:
  - The h3 "Allocation by Project" title
  - The flex items-end gap-3 h-[180px] bar chart with all project bars, percentages, and abbreviated names

Change the CardContent inner wrapper from grid grid-cols-1 lg:grid-cols-2 gap-6 to no grid at all — just render the right-side ScrollArea directly as the sole child of CardContent. The project cards (name, percentage badge, "Allocated capacity" label, MD value, Progress bar) now take the full card width.

─────────────────────────────────────────
DASHBOARD.TSX — CHANGE 5: Fix all 4 widget card overflow/scrolling
─────────────────────────────────────────
The Incidents & Defects card (and potentially others) overflow their fixed h-[520px] height. Apply this fix consistently to ALL 4 dashboard widget Cards:

For each of the 4 Cards (Planned vs Consumed Capacity, Incidents & Defects, Current Sprint Timeline, Project Priority Weighting):

  Card: className="bg-white shadow-sm h-[520px] flex flex-col" — unchanged

  CardHeader: className="flex-shrink-0 border-b border-gray-100" — add the border-b

  CardContent: change to className="p-0 flex-1 min-h-0"

  ScrollArea: change to className="h-full" (not flex-1)

  Wrap all existing inner content in: <div className="p-4 space-y-4"> ... </div>
  (use space-y-6 for Planned vs Consumed Capacity to keep its existing spacing)

This ensures the ScrollArea fills exactly the remaining card height and scrolls internally instead of expanding the card boundary.

Do not change any mock data, colors, component logic, or any other file.