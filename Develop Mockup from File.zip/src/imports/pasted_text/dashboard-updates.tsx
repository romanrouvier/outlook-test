Apply all of the following changes. This is a large set of targeted modifications — apply every item precisely.

─────────────────────────────────────────
GLOBAL — Reduce all component sizes by ~10%
─────────────────────────────────────────
In App.tsx, on the outer AppContent wrapper div (className="flex h-screen overflow-hidden"), add style={{ fontSize: '90%' }} to cascade a 10% size reduction across all text. This alone handles most text scaling.

Additionally make these targeted reductions across ALL components:
- Every page header h1 text-2xl → text-xl
- Every CardTitle text-lg → text-base
- Every py-4 lg:py-6 in page headers → py-3 lg:py-4
- Every px-4 lg:px-8 in page headers → px-3 lg:px-6
- Every p-4 lg:p-6 in main content areas → p-3 lg:p-5
- Every gap-6 between major sections → gap-4
- Dashboard card height h-[520px] → h-[468px]
- AI sidebar w-64 lg:w-80 → w-56 lg:w-72
- Every CardContent p-4 inner div → p-3
- Every Avatar w-7 h-7 → w-6 h-6, w-8 h-8 → w-7 h-7

─────────────────────────────────────────
DASHBOARD.TSX — Multiple changes
─────────────────────────────────────────

CHANGE 1 — Real dropdowns for Sprint and Assignment Group filter chips:
Replace the two plain <button> chips with proper Select components from shadcn/ui:

<div className="flex gap-2 px-3 lg:px-6 py-2 bg-white border-b border-gray-100">
  <Select defaultValue="sprint24">
    <SelectTrigger className="h-8 rounded-full border-[#2649B2] text-[#2649B2] text-sm font-medium w-auto px-4 bg-white">
      <SelectValue />
    </SelectTrigger>
    <SelectContent>
      <SelectItem value="sprint22">Sprint 22 — 18/03 → 01/04</SelectItem>
      <SelectItem value="sprint23">Sprint 23 — 01/04 → 14/04</SelectItem>
      <SelectItem value="sprint24">Sprint 24 — 15/04 → 29/04</SelectItem>
      <SelectItem value="sprint25">Sprint 25 — 30/04 → 13/05</SelectItem>
    </SelectContent>
  </Select>

  <Select defaultValue="all">
    <SelectTrigger className="h-8 rounded-full border-[#2649B2] text-[#2649B2] text-sm font-medium w-auto px-4 bg-white">
      <SelectValue />
    </SelectTrigger>
    <SelectContent>
      <SelectItem value="all">All Assignment Groups</SelectItem>
      <SelectItem value="backend">Backend</SelectItem>
      <SelectItem value="frontend">Frontend</SelectItem>
      <SelectItem value="data">Data Engineering</SelectItem>
      <SelectItem value="qa">QA</SelectItem>
    </SelectContent>
  </Select>
</div>

Add Select imports from "./ui/select".

CHANGE 2 — Swap the alert banner and velocity message positions + add Notify popup:

Step A — REMOVE the blue alert banner div (the bg-blue-50 div between the filter chips and the main grid that contains the AlertCircle + sprint risk text + Notify Sprint Team button). Delete it entirely from that position.

Step B — In the "Planned vs Consumed Capacity" card, REMOVE the existing blue info box:
  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-start gap-2">
    <AlertCircle ... />
    <p>Velocity slightly ahead: 20 MD consumed ahead of elapsed time.</p>
  </div>

Replace it with this new block that combines the sprint risk alert + notify button:
  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 space-y-2">
    <div className="flex items-start gap-2">
      <AlertCircle className="w-4 h-4 text-[#2649B2] mt-0.5 flex-shrink-0" />
      <p className="text-sm text-gray-800">
        Sprint is <span className="font-semibold text-[#2649B2]">80%</span> complete — only <span className="font-semibold text-[#2649B2]">65%</span> of stories delivered so far. <span className="font-semibold text-[#2649B2]">6 stories</span> are at risk of missing the sprint deadline.
      </p>
    </div>
    <div className="flex items-center justify-between pt-1">
      <p className="text-xs text-gray-500">Velocity slightly ahead: 20 MD consumed ahead of elapsed time.</p>
      <Button
        size="sm"
        className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white h-7 text-xs ml-3 flex-shrink-0"
        onClick={() => setNotifyOpen(true)}
      >
        <Bell className="w-3 h-3 mr-1" />
        Notify Sprint Team
      </Button>
    </div>
  </div>

Step C — Add state and Dialog for the Notify popup.
At the top of the Dashboard component add:
  const [notifyOpen, setNotifyOpen] = useState(false);
Add import { useState } from "react" and import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog" and import { Textarea } from "./ui/textarea" and import { Send, Bell } from "lucide-react".

At the end of the Dashboard JSX (before the final closing </div>) add:
  <Dialog open={notifyOpen} onOpenChange={setNotifyOpen}>
    <DialogContent className="sm:max-w-[480px]">
      <DialogHeader>
        <DialogTitle className="text-base font-semibold">Notify Sprint Team</DialogTitle>
      </DialogHeader>
      <div className="space-y-4 mt-2">
        <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-white rounded-lg p-3 shadow-sm border border-gray-100 flex-1">
              <Textarea
                className="border-0 p-0 text-sm text-gray-700 resize-none focus-visible:ring-0 min-h-[100px] bg-transparent"
                defaultValue={"Hi team,\n\nAs of today, Sprint #24 is 80% complete in terms of time elapsed but only 65% of stories have been delivered. We currently have 6 stories at risk of not being completed before the sprint deadline on 29/04.\n\nPlease review your remaining stories and flag any blockers as soon as possible.\n\nThanks!"}
              />
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => setNotifyOpen(false)}>Cancel</Button>
          <Button className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white" onClick={() => setNotifyOpen(false)}>
            <Send className="w-4 h-4 mr-2" />
            Send
          </Button>
        </div>
      </div>
    </DialogContent>
  </Dialog>

Import Bot from lucide-react.

─────────────────────────────────────────
CAPACITYPLANNER.TSX — Multiple changes
─────────────────────────────────────────

CHANGE 3 — Fix Sprint Content table text overlap:
The title column text wraps awkwardly and overlaps other columns. Fix the table layout:

Add className="table-fixed w-full" to the <table> element.
Set explicit column widths using <colgroup> immediately inside the table before <thead>:
  <colgroup>
    <col className="w-[120px]" />   {/* ID */}
    <col className="w-[280px]" />   {/* Title */}
    <col className="w-[150px]" />   {/* Priority */}
    <col className="w-[60px]" />    {/* Points */}
    <col className="w-[170px]" />   {/* Status */}
    <col className="w-[170px]" />   {/* Assigned to */}
    <col className="w-[140px]" />   {/* Epic */}
  </colgroup>

On the Title <td>: add className="py-3 text-sm text-gray-900 pr-2" and wrap the title text in a <span className="block truncate" title={story.title}> so it truncates gracefully with a tooltip on hover.

CHANGE 4 — Add Send button next to Filter in Sprint Content card header:
In the Sprint Content CardHeader, the current header row has:
  <CardTitle>Sprint Content</CardTitle>
  <Button variant="outline" size="sm"><Filter />Filter</Button>

Change to:
  <CardTitle>Sprint Content</CardTitle>
  <div className="flex items-center gap-2">
    <Button variant="outline" size="sm">
      <Filter className="w-4 h-4 mr-2" />
      Filter
    </Button>
    <Button size="sm" className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white">
      <Send className="w-4 h-4 mr-2" />
      Send
    </Button>
  </div>

Import Send from lucide-react if not already imported.

─────────────────────────────────────────
AVAILABILITY.TSX — Multiple changes
─────────────────────────────────────────

CHANGE 5 — Remove Total MD/day row:
Delete the entire <tr> block for the "Total MD/day" total row at the bottom of the <tbody>. Remove it completely.

CHANGE 6 — Make cells clickable to cycle availability:
Convert the component to use state for tracking per-developer per-day availability.
Replace the getAvailability function logic with a useState-based approach:

Add at the top of the Availability component:
  const [availabilityOverrides, setAvailabilityOverrides] = useState<Record<string, number>>({});

  const getAvailability = (developerIndex: number, dayIndex: number): number => {
    const day = calendar[dayIndex];
    if (day.isWeekend) return 0;
    const key = `${developerIndex}-${dayIndex}`;
    if (key in availabilityOverrides) return availabilityOverrides[key];
    const seed = developerIndex * 100 + dayIndex;
    if (seed % 13 === 0) return 0;
    if (seed % 7 === 0) return 0.5;
    return 1;
  };

  const cycleAvailability = (developerIndex: number, dayIndex: number) => {
    const day = calendar[dayIndex];
    if (day.isWeekend) return;
    const current = getAvailability(developerIndex, dayIndex);
    const next = current === 1 ? 0.5 : current === 0.5 ? 0 : 1;
    const key = `${developerIndex}-${dayIndex}`;
    setAvailabilityOverrides(prev => ({ ...prev, [key]: next }));
  };

Add import { useState } from "react".

On each availability <td> cell (non-weekend), add:
  onClick={() => cycleAvailability(devIdx, dayIdx)}
  className={... existing classes ... + " cursor-pointer hover:ring-2 hover:ring-[#2649B2] hover:ring-inset transition-all"}

The inner div should also get cursor-pointer. This lets the user click to cycle: 1 → 0.5 → 0 → 1.

─────────────────────────────────────────
SPRINTREVIEW.TSX — Generate popups
─────────────────────────────────────────

CHANGE 7 — Generate Sprint Recap popup:
Add state at the top of SprintReview:
  const [recapOpen, setRecapOpen] = useState(false);
  const [releaseOpen, setReleaseOpen] = useState(false);
Add import { useState } from "react" and Dialog, DialogContent, DialogHeader, DialogTitle from "./ui/dialog" and ScrollArea from "./ui/scroll-area" if not imported.

Change the "Generate Sprint Recap" Button onClick to: onClick={() => setRecapOpen(true)}

Add this Dialog before the closing </div> of the component:
  <Dialog open={recapOpen} onOpenChange={setRecapOpen}>
    <DialogContent className="sm:max-w-[560px] max-h-[80vh]">
      <DialogHeader>
        <DialogTitle className="text-base font-semibold">Sprint 23 — Generated Recap</DialogTitle>
      </DialogHeader>
      <ScrollArea className="max-h-[60vh] pr-2">
        <div className="space-y-4 text-sm text-gray-700 mt-2">
          <div className="bg-gray-50 rounded-lg p-4 border border-gray-100">
            <p className="font-semibold text-gray-900 mb-2">📋 Sprint 23 — 01/04 → 14/04</p>
            <p>The team completed <span className="font-semibold text-[#2649B2]">9 out of 14</span> planned stories, reaching a <span className="font-semibold text-[#2649B2]">64% completion rate</span>.</p>
          </div>
          <div>
            <p className="font-semibold text-gray-800 mb-2">✅ Completed (9)</p>
            <ul className="space-y-1 ml-2">
              {["Database migration phase 1 — Marie Dupont","New dashboard layout — Jean Martin","API performance improvements — Sophie Bernard","User profile enhancements — Pierre Leroy","Cache optimization — Lucas Petit"].map((item, i) => (
                <li key={i} className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />{item}</li>
              ))}
            </ul>
          </div>
          <div>
            <p className="font-semibold text-gray-800 mb-2">⏭ Deferred to Sprint 24 (3)</p>
            <ul className="space-y-1 ml-2">
              {["Data warehouse migration phase 2","Advanced filtering UI","Real-time notifications"].map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-orange-700"><ChevronRight className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />{item}</li>
              ))}
            </ul>
          </div>
          <div>
            <p className="font-semibold text-gray-800 mb-2">❌ Cancelled (2)</p>
            <ul className="space-y-1 ml-2">
              {["Legacy IE11 compatibility fixes","Manual CSV export endpoint"].map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-gray-500 line-through"><X className="w-3.5 h-3.5 mt-0.5 flex-shrink-0 no-underline" style={{textDecoration:'none'}} />{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </ScrollArea>
      <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
        <Button variant="outline" onClick={() => setRecapOpen(false)}>Close</Button>
        <Button className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white"><Download className="w-4 h-4 mr-2" />Export</Button>
      </div>
    </DialogContent>
  </Dialog>

CHANGE 8 — Generate Release Note popup:
Change the "Generate Release Note" Button onClick to: onClick={() => setReleaseOpen(true)}

Add this Dialog also before the closing </div>:
  <Dialog open={releaseOpen} onOpenChange={setReleaseOpen}>
    <DialogContent className="sm:max-w-[560px] max-h-[80vh]">
      <DialogHeader>
        <DialogTitle className="text-base font-semibold">Release 2.4.0 — Generated Note</DialogTitle>
      </DialogHeader>
      <ScrollArea className="max-h-[60vh] pr-2">
        <div className="space-y-4 text-sm text-gray-700 mt-2">
          <div className="bg-gray-50 rounded-lg p-4 border border-gray-100 flex items-center gap-3">
            <Badge className="bg-[#2649B2] text-white">v2.4.0</Badge>
            <span className="text-gray-700">29 April 2026</span>
            <Badge variant="outline">Production</Badge>
          </div>
          <div>
            <p className="font-semibold text-gray-800 mb-2">🚀 Developments Included (7)</p>
            <ul className="space-y-1.5 ml-2">
              {[
                { type: "[TECH]", title: "Database migration phase 1", dev: "Marie Dupont" },
                { type: "[FRONT]", title: "New dashboard layout", dev: "Jean Martin" },
                { type: "[TECH]", title: "API performance improvements", dev: "Sophie Bernard" },
                { type: "[FRONT]", title: "User profile enhancements", dev: "Pierre Leroy" },
                { type: "[TECH]", title: "Cache optimization", dev: "Lucas Petit" },
                { type: "[FRONT]", title: "Dedicated URL for iClosing", dev: "Thomas Dubois" },
                { type: "[FRONT]", title: "Fix SGA dashboard colors", dev: "Lucas Petit" },
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-2">
                  <Badge className={`text-xs ${item.type === "[FRONT]" ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-700"}`}>{item.type}</Badge>
                  <span className="flex-1">{item.title}</span>
                  <span className="text-xs text-gray-400">{item.dev}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="font-semibold text-gray-800 mb-2">💡 Business Benefits</p>
            <ul className="space-y-1.5 ml-2">
              {["Resolved SSO authentication failures affecting 200+ daily users","Reduced BigQuery query time by 40% through cache layer optimization","New dedicated URL structure for all iClosing analytics products","Automated P&L line management, saving ~3h/week of manual operations"].map((item, i) => (
                <li key={i} className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </ScrollArea>
      <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
        <Button variant="outline" onClick={() => setReleaseOpen(false)}>Close</Button>
        <Button className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white"><Download className="w-4 h-4 mr-2" />Export</Button>
      </div>
    </DialogContent>
  </Dialog>

Make sure ChevronRight, X, Download, CheckCircle, Sparkles are all imported from lucide-react in SprintReview.tsx.

In SprintReview.tsx, remove the Benefits section from the Release Notes card (right column).

Delete the entire div block that contains:
- The border-t border-gray-100 pt-4 mt-2 wrapper div
- The "BENEFITS" h3 label
- The ScrollArea wrapping the ul with the 4 CheckCircle benefit list items

The CardContent of the Release Notes card should now flow directly from the "Developments Included" ScrollArea to the bottom action button ("Generate Release Note"), with no Benefits section in between.

Also remove the Benefits section from the Generate Release Note popup Dialog:
Delete the entire <div> block inside the Dialog ScrollArea that contains:
- The "💡 Business Benefits" paragraph
- The ul with the 4 CheckCircle benefit list items

The popup should now show only the release summary strip (v2.4.0 | date | Production badge) and the "Developments Included" list, then go straight to the Close / Export buttons.

Do not change anything else.