import { BrowserRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Calendar, CalendarClock, ClipboardList, Timer, User, Settings, LogOut, HelpCircle, Bell, Shield, ChevronDown } from "lucide-react";
import { AIAssistant } from "./components/AIAssistant";
import { Dashboard } from "./components/Dashboard";
import { CapacityPlanner } from "./components/CapacityPlanner";
import { Availability } from "./components/Availability";
import { SprintReview } from "./components/SprintReview";
import { Daily } from "./components/Daily";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "./components/ui/dropdown-menu";

function Navigation() {
  const location = useLocation();

  const navItems = [
    { path: "/", label: "Product Lead Portal", icon: LayoutDashboard },
    { path: "/daily", label: "Daily", icon: Timer },
    { path: "/sprint-review", label: "Sprint Review", icon: ClipboardList },
    { path: "/capacity-planner", label: "Capacity Planner", icon: Calendar },
    { path: "/availability", label: "Availability", icon: CalendarClock },
  ];

  return (
    <nav className="bg-white border-b border-gray-200 px-4 lg:px-8 py-4">
      <div className="flex items-center justify-between gap-1 lg:gap-3">
        <div className="flex gap-1 lg:gap-3">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-2 px-2 py-2 lg:px-4 rounded-lg transition-colors ${
                isActive
                  ? "bg-[#2649B2] text-white"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-xs lg:text-sm font-medium">{item.label}</span>
            </Link>
          );
        })}
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-gray-100 transition-colors outline-none">
              <div className="w-8 h-8 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
                <span className="text-white text-xs font-semibold">AL</span>
              </div>
              <div className="text-left hidden lg:block">
                <p className="text-xs font-semibold text-gray-900 leading-tight">Alex Laurent</p>
                <p className="text-[10px] text-gray-500 leading-tight">Product Lead</p>
              </div>
              <ChevronDown className="w-3 h-3 text-gray-400 hidden lg:block" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>
              <div className="flex items-center gap-3 py-1">
                <div className="w-10 h-10 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-sm font-semibold">AL</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-900">Alex Laurent</p>
                  <p className="text-xs text-gray-500">alex.laurent@loreal.com</p>
                  <p className="text-[10px] text-[#2649B2] font-medium">Product Lead · BTDP</p>
                </div>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="gap-2 cursor-pointer">
              <User className="w-4 h-4 text-gray-500" />
              <span>My Profile</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="gap-2 cursor-pointer">
              <Settings className="w-4 h-4 text-gray-500" />
              <span>Settings</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="gap-2 cursor-pointer">
              <Bell className="w-4 h-4 text-gray-500" />
              <span>Notifications</span>
              <span className="ml-auto bg-[#2649B2] text-white text-[10px] rounded-full px-1.5 py-0.5">3</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="gap-2 cursor-pointer">
              <Shield className="w-4 h-4 text-gray-500" />
              <span>Permissions</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="gap-2 cursor-pointer">
              <HelpCircle className="w-4 h-4 text-gray-500" />
              <span>Help & Support</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="gap-2 cursor-pointer text-red-600 focus:text-red-600 focus:bg-red-50">
              <LogOut className="w-4 h-4" />
              <span>Disconnect</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </nav>
  );
}

function AppContent() {
  return (
    <div className="flex h-screen overflow-hidden" style={{ fontSize: '90%' }}>
      <AIAssistant />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navigation />
        <div className="flex-1 overflow-auto">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/capacity-planner" element={<CapacityPlanner />} />
            <Route path="/availability" element={<Availability />} />
            <Route path="/sprint-review" element={<SprintReview />} />
            <Route path="/daily" element={<Daily />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}