import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { ScrollArea } from "./ui/scroll-area";
import { RotateCcw, Pencil, Lock, Send, AlertCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { useState } from "react";

export function Availability() {
  const [availabilityOverrides, setAvailabilityOverrides] = useState<Record<string, number>>({});
  const [isEditing, setIsEditing] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const developers = [
    { name: "Marie Dupont", avatar: "MD", type: "Data Eng.", group: "DATA - Finance - BTDP L3" },
    { name: "Jean Martin", avatar: "JM", type: "Data Eng.", group: "DATA - Finance - BTDP L3" },
    { name: "Sophie Bernard", avatar: "SB", type: "Backend", group: "DATA - Finance - BTDP L3" },
    { name: "Pierre Leroy", avatar: "PL", type: "Backend", group: "Supply" },
    { name: "Lucas Petit", avatar: "LP", type: "Frontend", group: "Supply" },
    { name: "Emma Rousseau", avatar: "ER", type: "Frontend", group: "Sourcing" },
    { name: "Thomas Dubois", avatar: "TD", type: "QA", group: "Sourcing" },
    { name: "Léa Moreau", avatar: "LM", type: "Product", group: "Product" },
  ];

  const generateCalendar = () => {
    const days = [];
    // Sprint 24: April 15 - May 5 (21 days)
    for (let day = 15; day <= 30; day++) {
      const date = new Date(2026, 3, day);
      const dayOfWeek = date.getDay();
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      days.push({
        date: day,
        month: "April",
        sprint: "Sprint 24",
        isWeekend,
        fullDate: `2026-04-${String(day).padStart(2, "0")}`,
      });
    }
    for (let day = 1; day <= 5; day++) {
      const date = new Date(2026, 4, day);
      const dayOfWeek = date.getDay();
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      days.push({
        date: day,
        month: "May",
        sprint: "Sprint 24",
        isWeekend,
        fullDate: `2026-05-${String(day).padStart(2, "0")}`,
      });
    }
    // Sprint 25: May 6 - May 26 (21 days)
    for (let day = 6; day <= 26; day++) {
      const date = new Date(2026, 4, day);
      const dayOfWeek = date.getDay();
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      days.push({
        date: day,
        month: "May",
        sprint: "Sprint 25",
        isWeekend,
        fullDate: `2026-05-${String(day).padStart(2, "0")}`,
      });
    }
    return days;
  };

  const calendar = generateCalendar();

  const getAvailability = (developerIndex: number, dayIndex: number): number => {
    const day = calendar[dayIndex];
    if (day.isWeekend) return 0;
    const key = `${developerIndex}-${dayIndex}`;
    if (key in availabilityOverrides) return availabilityOverrides[key];
    const seed = developerIndex * 100 + dayIndex;
    if (seed % 13 === 0) return 0;
    if (seed % 7 === 0) return 0.5;
    return 1;
  };

  const cycleAvailability = (developerIndex: number, dayIndex: number) => {
    const day = calendar[dayIndex];
    if (day.isWeekend) return;
    const current = getAvailability(developerIndex, dayIndex);
    const next = current === 1 ? 0.5 : current === 0.5 ? 0 : 1;
    const key = `${developerIndex}-${dayIndex}`;
    setAvailabilityOverrides(prev => ({ ...prev, [key]: next }));
  };

  const groupedDays = calendar.reduce((acc, day) => {
    const existing = acc.find((g) => g.sprint === day.sprint && g.month === day.month);
    if (existing) {
      existing.days.push(day);
    } else {
      acc.push({ sprint: day.sprint, month: day.month, days: [day] });
    }
    return acc;
  }, [] as Array<{ sprint: string; month: string; days: typeof calendar }>);

  const getRowBorderClass = (devIdx: number) => {
    const values = calendar
      .filter((d) => !d.isWeekend)
      .map((_, i) => {
        const calIdx = calendar.indexOf(calendar.filter((d) => !d.isWeekend)[i]);
        return getAvailability(devIdx, calIdx);
      });
    if (values.some((v) => v === 0)) return "border-l-2 border-l-red-300";
    if (values.some((v) => v === 0.5)) return "border-l-2 border-l-amber-300";
    return "border-l-2 border-l-green-300";
  };

  return (
    <div className="flex-1 bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-3 lg:px-6 py-3 lg:py-4">
        <h1 className="text-xl font-semibold text-gray-900">Availability</h1>
        <p className="text-sm text-gray-600 mt-2">Team availability per day (in MD)</p>
      </div>

      {/* Main Content */}
      <div className="p-3 lg:p-5">
        {/* Filter Bar */}
        <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
          <div className="mb-3">
            <label className="text-sm font-medium text-gray-700 mb-2 block">Assignment Group</label>
            <Select defaultValue="all">
              <SelectTrigger className="w-full lg:w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Groups</SelectItem>
                <SelectItem value="data-finance">DATA - Finance L3 BTDP</SelectItem>
                <SelectItem value="data-sourcing">DATA - Sourcing L3 BTDP</SelectItem>
                <SelectItem value="supply">Supply</SelectItem>
                <SelectItem value="sourcing">Sourcing</SelectItem>
                <SelectItem value="product">Product</SelectItem>
                <SelectItem value="marketing">Marketing</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="mb-3">
            <label className="text-sm font-medium text-gray-700 mb-2 block">Members</label>
            <div className="flex flex-wrap gap-2">
              {developers.map((dev) => (
                <button
                  key={dev.avatar}
                  className="bg-blue-50 border border-[#2649B2] text-[#2649B2] rounded-full px-3 py-1 text-sm flex items-center gap-1 hover:bg-blue-100 transition-colors"
                >
                  <div className="w-6 h-6 rounded-full bg-[#2649B2] text-white text-xs inline-flex items-center justify-center">
                    {dev.avatar}
                  </div>
                  <span>{dev.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end">
            <Button variant="ghost" className="text-xs text-gray-500">
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset filters
            </Button>
          </div>
        </div>

        <Card className="bg-white shadow-md border border-gray-100">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CardTitle className="text-base">Availability Calendar</CardTitle>
                {!isEditing && (
                  <span className="flex items-center gap-1 text-xs text-gray-400">
                    <Lock className="w-3 h-3" />
                    Read-only
                  </span>
                )}
                {isEditing && (
                  <span className="flex items-center gap-1 text-xs text-amber-600 font-medium">
                    <Pencil className="w-3 h-3" />
                    Editing
                  </span>
                )}
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-4 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-lg bg-[#EEF2FF] border border-[#C7D2FE] flex items-center justify-center">
                    <span className="text-[9px] font-semibold text-[#2649B2]">1</span>
                  </div>
                  <span className="text-gray-600">Available (1 MD)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center">
                    <span className="text-[9px] font-semibold text-amber-600">½</span>
                  </div>
                  <span className="text-gray-600">Partial (0.5 MD)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-lg bg-red-50 border border-red-100 flex items-center justify-center">
                    <span className="text-[9px] text-red-300">—</span>
                  </div>
                  <span className="text-gray-600">Unavailable</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-lg bg-gray-100 flex items-center justify-center">
                    <span className="text-[9px] text-gray-300">·</span>
                  </div>
                  <span className="text-gray-600">Weekend</span>
                </div>
                </div>
                <div className="flex items-center gap-2 ml-2">
                  {!isEditing ? (
                    <Button
                      size="sm"
                      className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white h-8"
                      onClick={() => setIsEditing(true)}
                    >
                      <Pencil className="w-3.5 h-3.5 mr-1.5" />
                      Edit
                    </Button>
                  ) : (
                    <>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8"
                        onClick={() => setIsEditing(false)}
                      >
                        Cancel
                      </Button>
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700 text-white h-8"
                        onClick={() => setConfirmOpen(true)}
                      >
                        <Send className="w-3.5 h-3.5 mr-1.5" />
                        Confirm
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="relative">
              <div className="overflow-auto max-h-[400px] lg:max-h-[600px]">
                <table className="w-full border-collapse">
                  <thead className="sticky top-0 z-20 bg-white">
                    {/* Sprint Row */}
                    <tr className="border-b border-gray-200">
                      <th className="sticky left-0 z-30 bg-white border-r border-gray-200 p-3 text-left">
                        <span className="text-xs font-medium text-gray-600 uppercase">Sprint</span>
                      </th>
                      <th className="sticky left-[200px] z-30 bg-white border-r border-gray-200"></th>
                      {groupedDays.map((group, idx) => (
                        <th
                          key={idx}
                          colSpan={group.days.length}
                          className="border-r border-gray-200 p-2 text-center bg-gray-50"
                        >
                          <div className="bg-[#2649B2] text-white text-xs font-medium px-3 py-1 rounded-full inline-block">
                            {group.sprint}
                          </div>
                        </th>
                      ))}
                    </tr>

                    {/* Month Row */}
                    <tr className="border-b border-gray-200">
                      <th className="sticky left-0 z-30 bg-white border-r border-gray-200 p-3 text-left">
                        <span className="text-xs font-medium text-gray-600 uppercase">Month</span>
                      </th>
                      <th className="sticky left-[200px] z-30 bg-white border-r border-gray-200"></th>
                      {groupedDays.map((group, idx) => (
                        <th
                          key={idx}
                          colSpan={group.days.length}
                          className="border-r border-gray-200 p-2 text-center bg-gray-50"
                        >
                          <span className="text-xs font-medium text-gray-700">{group.month}</span>
                        </th>
                      ))}
                    </tr>

                    {/* Day Numbers Row */}
                    <tr className="border-b-2 border-gray-300">
                      <th className="sticky left-0 z-30 bg-white border-r border-gray-200 p-3 text-left">
                        <span className="text-xs font-medium text-gray-600 uppercase">Person</span>
                      </th>
                      <th className="sticky left-[200px] z-30 bg-white border-r border-gray-200 p-2 text-left min-w-[80px]">
                        <span className="text-xs font-medium text-gray-600 uppercase">Type</span>
                      </th>
                      {calendar.map((day, idx) => (
                        <th
                          key={idx}
                          className={`p-2 text-center min-w-[48px] border-r border-gray-200 ${
                            day.isWeekend ? "bg-gray-50" : "bg-white"
                          }`}
                        >
                          <div className="flex flex-col items-center gap-0.5">
                            <span className="text-xs font-semibold text-gray-700">{day.date}</span>
                            <span className="text-[9px] text-gray-400 uppercase">
                              {new Date(day.fullDate).toLocaleDateString("en-US", { weekday: "short" }).slice(0, 1)}
                            </span>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>

                  <tbody>
                    {developers.map((dev, devIdx) => (
                      <tr key={devIdx} className={`border-b border-gray-200 hover:bg-gray-50 ${getRowBorderClass(devIdx)}`}>
                        {/* Person Name - Sticky */}
                        <td className="sticky left-0 z-10 bg-white border-r border-gray-200 p-3">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
                              <span className="text-xs font-medium text-white">{dev.avatar}</span>
                            </div>
                            <span className="text-sm font-medium text-gray-900 whitespace-nowrap">
                              {dev.name}
                            </span>
                          </div>
                        </td>

                        {/* Type - Sticky */}
                        <td className="sticky left-[200px] z-10 bg-white border-r border-gray-200 p-2">
                          <Badge variant="outline" className="text-[10px] whitespace-nowrap">
                            {dev.type}
                          </Badge>
                        </td>

                        {/* Availability Cells */}
                        {calendar.map((day, dayIdx) => {
                          const availability = getAvailability(devIdx, dayIdx);
                          if (day.isWeekend) {
                            return (
                              <td key={dayIdx} className="p-1 border-r border-gray-100 bg-gray-50">
                                <div className="flex flex-col items-center justify-center rounded-lg bg-gray-100 h-9 w-full">
                                  <span className="text-[11px] text-gray-300">·</span>
                                </div>
                              </td>
                            );
                          }
                          const editProps = isEditing
                            ? { className: "p-1 border-r border-gray-100 cursor-pointer hover:ring-2 hover:ring-[#2649B2] hover:ring-inset transition-all", onClick: () => cycleAvailability(devIdx, dayIdx) }
                            : { className: "p-1 border-r border-gray-100" };
                          if (availability === 1) {
                            return (
                              <td key={dayIdx} {...editProps}>
                                <div className="flex flex-col items-center justify-center rounded-lg bg-[#EEF2FF] border border-[#C7D2FE] h-9 w-full">
                                  <span className="text-[11px] font-semibold text-[#2649B2]">1</span>
                                </div>
                              </td>
                            );
                          }
                          if (availability === 0.5) {
                            return (
                              <td key={dayIdx} {...editProps}>
                                <div className="flex flex-col items-center justify-center rounded-lg bg-amber-50 border border-amber-200 h-9 w-full">
                                  <span className="text-[11px] font-semibold text-amber-600">½</span>
                                </div>
                              </td>
                            );
                          }
                          return (
                            <td key={dayIdx} {...editProps}>
                              <div className="flex flex-col items-center justify-center rounded-lg bg-red-50 border border-red-100 h-9 w-full">
                                <span className="text-[11px] text-red-300">—</span>
                              </div>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Confirm Submit Dialog */}
      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">Submit Availability</DialogTitle>
            <DialogDescription className="sr-only">Confirm submitting availability data to ServiceNow</DialogDescription>
          </DialogHeader>
          <div className="py-3 space-y-3">
            <div className="flex items-start gap-3 bg-blue-50 border border-blue-100 rounded-lg p-3">
              <AlertCircle className="w-5 h-5 text-[#2649B2] flex-shrink-0 mt-0.5" />
              <p className="text-sm text-gray-700">
                You are about to submit availability data for <span className="font-semibold text-[#2649B2]">8 team members</span> covering <span className="font-semibold text-[#2649B2]">Sprint 24 &amp; Sprint 25</span>. This will update capacity planning in ServiceNow and notify the Product Lead.
              </p>
            </div>
            <p className="text-xs text-gray-500">Once submitted, changes will be visible to all stakeholders. You can always come back and re-submit if your availability changes.</p>
          </div>
          <div className="flex justify-end gap-2 border-t border-gray-100 pt-3">
            <Button variant="outline" onClick={() => setConfirmOpen(false)}>Cancel</Button>
            <Button
              className="bg-green-600 hover:bg-green-700 text-white"
              onClick={() => { setConfirmOpen(false); setIsEditing(false); }}
            >
              <Send className="w-4 h-4 mr-2" />
              Submit availability
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
