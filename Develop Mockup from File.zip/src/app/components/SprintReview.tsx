import { CheckCircle, Sparkles, ChevronRight, X, Download } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";
import { Avatar, AvatarFallback } from "./ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { useState } from "react";

export function SprintReview() {
  const [recapOpen, setRecapOpen] = useState(false);
  const [releaseOpen, setReleaseOpen] = useState(false);
  return (
    <div className="flex-1 bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-3 lg:px-6 py-3 lg:py-4">
        <h1 className="text-xl font-semibold text-gray-900">Sprint Review</h1>
      </div>

      {/* Main Content */}
      <div className="p-3 lg:p-5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* LEFT COLUMN - Sprint Recap */}
          <Card className="bg-white shadow-md border border-gray-100">
            <CardHeader>
              <CardTitle className="text-base">Sprint Recap</CardTitle>
            </CardHeader>
            <CardContent className="p-0 flex flex-col overflow-hidden">
              {/* Selectors — top bar */}
              <div className="px-4 pt-4 pb-3 border-b border-gray-100 flex flex-wrap items-center gap-3 flex-shrink-0">

                {/* Group first */}
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-700">Group</span>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Groups</SelectItem>
                      <SelectItem value="data-finance">DATA - Finance L3 BTDP</SelectItem>
                      <SelectItem value="data-sourcing">DATA - Sourcing L3 BTDP</SelectItem>
                      <SelectItem value="supply">Supply</SelectItem>
                      <SelectItem value="sourcing">Sourcing</SelectItem>
                      <SelectItem value="product">Product</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Sprint second */}
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-700">Sprint</span>
                  <Select defaultValue="sprint23">
                    <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sprint22">Sprint 22 — 18/03 → 01/04</SelectItem>
                      <SelectItem value="sprint23">Sprint 23 — 01/04 → 14/04</SelectItem>
                      <SelectItem value="sprint24">Sprint 24 — 15/04 → 05/05</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

              </div>

              {/* Section 1 — Completed */}
              <div className="flex-shrink-0">
                <div className="bg-gray-50 border-b border-gray-100 px-4 py-2 flex items-center gap-2">
                  <Badge className="bg-green-600 text-white hover:bg-green-600">✓ Completed (9)</Badge>
                </div>
                <ScrollArea className="h-[200px]">
                  <div className="divide-y divide-gray-100">
                    {[
                      { id: "STRY0723145", title: "[TECH] Database migration phase 1", assignee: "Marie Dupont", avatar: "MD" },
                      { id: "STRY0723146", title: "[FRONT] New dashboard layout", assignee: "Jean Martin", avatar: "JM" },
                      { id: "STRY0723147", title: "[TECH] API performance improvements", assignee: "Sophie Bernard", avatar: "SB" },
                      { id: "STRY0723148", title: "[FRONT] User profile enhancements", assignee: "Pierre Leroy", avatar: "PL" },
                      { id: "STRY0723149", title: "[TECH] Cache optimization", assignee: "Lucas Petit", avatar: "LP" },
                    ].map((story, idx) => (
                      <div key={idx} className="flex items-center gap-3 px-4 py-2">
                        <span className="font-mono text-xs text-gray-400 w-[100px] flex-shrink-0">{story.id}</span>
                        <span className="text-sm text-gray-900 flex-1">{story.title}</span>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <Avatar className="w-6 h-6">
                            <AvatarFallback className="bg-[#2649B2] text-white text-[10px]">
                              {story.avatar}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-gray-600">{story.assignee}</span>
                        </div>
                        <Badge className="bg-green-600 text-white text-xs flex-shrink-0">Complete</Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>

              {/* Section 2 — Deferred */}
              <div className="flex-shrink-0 border-t border-gray-100">
                <div className="bg-gray-50 border-b border-gray-100 px-4 py-2 flex items-center gap-2">
                  <Badge className="bg-orange-500 text-white hover:bg-orange-500">⏭ Deferred to Next Sprint (3)</Badge>
                </div>
                <ScrollArea className="h-[152px]">
                  <div className="divide-y divide-gray-100">
                    {[
                      { id: "STRY0723150", title: "[TECH] Data warehouse migration phase 2" },
                      { id: "STRY0723151", title: "[FRONT] Advanced filtering UI" },
                      { id: "STRY0723152", title: "[TECH] Real-time notifications" },
                    ].map((story, idx) => (
                      <div key={idx} className="flex items-center gap-3 px-4 py-2">
                        <span className="font-mono text-xs text-gray-400 w-[100px] flex-shrink-0">{story.id}</span>
                        <span className="text-sm text-gray-900 flex-1">{story.title}</span>
                        <Badge className="bg-orange-500 text-white text-xs flex-shrink-0">Deferred</Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>

              {/* Section 3 — Cancelled */}
              <div className="flex-shrink-0 border-t border-gray-100">
                <div className="bg-gray-50 border-b border-gray-100 px-4 py-2 flex items-center gap-2">
                  <Badge variant="outline" className="border-gray-500 text-gray-600">✕ Cancelled (2)</Badge>
                </div>
                <ScrollArea className="h-[120px]">
                  <div className="divide-y divide-gray-100">
                    {[
                      { id: "STRY0723153", title: "[FRONT] Legacy IE11 compatibility fixes" },
                      { id: "STRY0723154", title: "[TECH] Manual CSV export endpoint" },
                    ].map((story, idx) => (
                      <div key={idx} className="flex items-center gap-3 px-4 py-2">
                        <span className="font-mono text-xs text-gray-400 w-[100px] flex-shrink-0">{story.id}</span>
                        <span className="text-sm line-through text-gray-400 flex-1">{story.title}</span>
                        <Badge variant="outline" className="border-gray-400 text-gray-500 text-xs flex-shrink-0">Cancelled</Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>

              {/* Generate Sprint Recap button */}
              <div className="border-t border-gray-100 px-4 py-3 flex-shrink-0">
                <Button className="w-full bg-[#2649B2] hover:bg-[#1d3a8f] text-white" onClick={() => setRecapOpen(true)}>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Sprint Recap
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* RIGHT COLUMN - Release Notes */}
          <Card className="bg-white shadow-md border border-gray-100">
            <CardHeader>
              <CardTitle className="text-base">Release Notes</CardTitle>
            </CardHeader>
            <CardContent className="p-0 flex flex-col h-full overflow-hidden">
              {/* Selector row */}
              <div className="px-4 pt-4 pb-3 border-b border-gray-100 flex flex-wrap items-center gap-3 flex-shrink-0">

                {/* Group first */}
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-700">Group</span>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Groups</SelectItem>
                      <SelectItem value="data-finance">DATA - Finance L3 BTDP</SelectItem>
                      <SelectItem value="data-sourcing">DATA - Sourcing L3 BTDP</SelectItem>
                      <SelectItem value="supply">Supply</SelectItem>
                      <SelectItem value="sourcing">Sourcing</SelectItem>
                      <SelectItem value="product">Product</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Release second */}
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-700">Release</span>
                  <Select defaultValue="release240">
                    <SelectTrigger className="w-[220px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="release235">Release 2.3.5 — 14/04 (Prod)</SelectItem>
                      <SelectItem value="release240">Release 2.4.0 — 29/04 (Prod)</SelectItem>
                      <SelectItem value="release241">Release 2.4.1 — 06/05 (Staging)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

              </div>

              {/* Summary strip */}
              <div className="px-4 py-3 flex items-center gap-3 bg-gray-50 border-b border-gray-100 flex-shrink-0">
                <Badge className="bg-[#2649B2] text-white hover:bg-[#2649B2]">v2.4.0</Badge>
                <span className="text-sm text-gray-900">29 April 2026</span>
                <Badge variant="outline">Production</Badge>
              </div>

              {/* Developments Included — flexible scrollable */}
              <div className="flex-1 min-h-0 flex flex-col">
                <div className="px-4 py-2 bg-gray-50 border-b border-gray-100 border-t border-t-gray-100 flex-shrink-0">
                  <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide">Developments Included</h3>
                </div>
                <ScrollArea className="flex-1">
                  <div className="divide-y divide-gray-100 px-4">
                    {[
                      { id: "STRY0723145", type: "[TECH]", title: "Database migration phase 1", dev: "Marie Dupont", avatar: "MD" },
                      { id: "STRY0723146", type: "[FRONT]", title: "New dashboard layout", dev: "Jean Martin", avatar: "JM" },
                      { id: "STRY0723147", type: "[TECH]", title: "API performance improvements", dev: "Sophie Bernard", avatar: "SB" },
                      { id: "STRY0723148", type: "[FRONT]", title: "User profile enhancements", dev: "Pierre Leroy", avatar: "PL" },
                      { id: "STRY0723149", type: "[TECH]", title: "Cache optimization", dev: "Lucas Petit", avatar: "LP" },
                      { id: "STRY0735868", type: "[FRONT]", title: "Dedicated URL for iClosing", dev: "Thomas Dubois", avatar: "TD" },
                      { id: "STRY0758160", type: "[FRONT]", title: "Fix SGA dashboard colors", dev: "Lucas Petit", avatar: "LP" },
                    ].map((story, idx) => (
                      <div key={idx} className="flex items-center gap-2 py-2 border-b border-gray-100">
                        <span className="text-xs font-mono text-gray-500">{story.id}</span>
                        <Badge
                          className={`text-xs ${
                            story.type === "[FRONT]"
                              ? "bg-blue-100 text-blue-700 hover:bg-blue-100"
                              : "bg-gray-100 text-gray-700 hover:bg-gray-100"
                          }`}
                        >
                          {story.type}
                        </Badge>
                        <span className="text-sm text-gray-900 flex-1">{story.title}</span>
                        <div className="flex items-center gap-1">
                          <Avatar className="w-5 h-5">
                            <AvatarFallback className="bg-[#2649B2] text-white text-[9px]">
                              {story.avatar}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-gray-600">{story.dev}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>

              {/* Single action button at the bottom */}
              <div className="flex-shrink-0 border-t border-gray-100 px-4 py-3">
                <Button className="w-full bg-[#2649B2] hover:bg-[#1d3a8f] text-white" onClick={() => setReleaseOpen(true)}>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Release Note
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Generate Sprint Recap Dialog */}
      <Dialog open={recapOpen} onOpenChange={setRecapOpen}>
        <DialogContent className="sm:max-w-[560px] max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">Sprint 23 — Generated Recap</DialogTitle>
            <DialogDescription className="sr-only">AI-generated sprint recap with completed, deferred, and cancelled stories</DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[60vh] pr-2">
            <div className="space-y-4 text-sm text-gray-700 mt-2">
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-100">
                <p className="font-semibold text-gray-900 mb-2">📋 Sprint 23 — 01/04 → 14/04</p>
                <p>The team completed <span className="font-semibold text-[#2649B2]">9 out of 14</span> planned stories, reaching a <span className="font-semibold text-[#2649B2]">64% completion rate</span>.</p>
              </div>
              <div>
                <p className="font-semibold text-gray-800 mb-2">✅ Completed (9)</p>
                <ul className="space-y-1 ml-2">
                  {["Database migration phase 1 — Marie Dupont","New dashboard layout — Jean Martin","API performance improvements — Sophie Bernard","User profile enhancements — Pierre Leroy","Cache optimization — Lucas Petit"].map((item, i) => (
                    <li key={i} className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />{item}</li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="font-semibold text-gray-800 mb-2">⏭ Deferred to Sprint 24 (3)</p>
                <ul className="space-y-1 ml-2">
                  {["Data warehouse migration phase 2","Advanced filtering UI","Real-time notifications"].map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-orange-700"><ChevronRight className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />{item}</li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="font-semibold text-gray-800 mb-2">❌ Cancelled (2)</p>
                <ul className="space-y-1 ml-2">
                  {["Legacy IE11 compatibility fixes","Manual CSV export endpoint"].map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-gray-500 line-through"><X className="w-3.5 h-3.5 mt-0.5 flex-shrink-0 no-underline" style={{textDecoration:'none'}} />{item}</li>
                  ))}
                </ul>
              </div>
              <div className="border-t border-gray-100 pt-3">
                <p className="font-semibold text-gray-800 mb-3">📊 Sprint Analysis</p>
                <div className="space-y-3">
                  <div className="bg-green-50 border border-green-100 rounded-lg p-3">
                    <p className="text-xs font-semibold text-green-700 uppercase tracking-wide mb-1.5">✅ What went well</p>
                    <ul className="space-y-1 text-sm text-gray-700">
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />9 stories delivered on time with no regression in production</li>
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />API performance improvements exceeded targets — 40% response time reduction</li>
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />Zero P1 incidents opened during the sprint cycle</li>
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />Team collaboration improved — daily standup attendance at 100%</li>
                    </ul>
                  </div>
                  <div className="bg-orange-50 border border-orange-100 rounded-lg p-3">
                    <p className="text-xs font-semibold text-orange-700 uppercase tracking-wide mb-1.5">⚠️ What needs improvement</p>
                    <ul className="space-y-1 text-sm text-gray-700">
                      <li className="flex items-start gap-2"><ChevronRight className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />3 stories deferred — external blockers not flagged early enough in the sprint</li>
                      <li className="flex items-start gap-2"><ChevronRight className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />Story estimation accuracy below target: 2 stories consumed over 150% of estimated time</li>
                      <li className="flex items-start gap-2"><ChevronRight className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />Frontend capacity under-utilized in week 1 due to late design validation</li>
                    </ul>
                  </div>
                  <div className="bg-blue-50 border border-blue-100 rounded-lg p-3">
                    <p className="text-xs font-semibold text-[#2649B2] uppercase tracking-wide mb-1.5">💡 Recommendations</p>
                    <ul className="space-y-1 text-sm text-gray-700">
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Run a pre-sprint dependency check with external teams before sprint start</li>
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Flag blockers within 24h of detection — escalate to Product Lead immediately</li>
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Calibrate estimation using velocity data from the last 3 sprints</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </ScrollArea>
          <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
            <Button variant="outline" onClick={() => setRecapOpen(false)}>Close</Button>
            <Button className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white"><Download className="w-4 h-4 mr-2" />Export</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Generate Release Note Dialog */}
      <Dialog open={releaseOpen} onOpenChange={setReleaseOpen}>
        <DialogContent className="sm:max-w-[560px] max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">Release 2.4.0 — Generated Note</DialogTitle>
            <DialogDescription className="sr-only">AI-generated release notes with developments included</DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[60vh] pr-2">
            <div className="space-y-4 text-sm text-gray-700 mt-2">
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-100 flex items-center gap-3">
                <Badge className="bg-[#2649B2] text-white">v2.4.0</Badge>
                <span className="text-gray-700">29 April 2026</span>
                <Badge variant="outline">Production</Badge>
              </div>
              <div>
                <p className="font-semibold text-gray-800 mb-2">🚀 Developments Included (7)</p>
                <ul className="space-y-1.5 ml-2">
                  {[
                    { type: "[TECH]", title: "Database migration phase 1", dev: "Marie Dupont" },
                    { type: "[FRONT]", title: "New dashboard layout", dev: "Jean Martin" },
                    { type: "[TECH]", title: "API performance improvements", dev: "Sophie Bernard" },
                    { type: "[FRONT]", title: "User profile enhancements", dev: "Pierre Leroy" },
                    { type: "[TECH]", title: "Cache optimization", dev: "Lucas Petit" },
                    { type: "[FRONT]", title: "Dedicated URL for iClosing", dev: "Thomas Dubois" },
                    { type: "[FRONT]", title: "Fix SGA dashboard colors", dev: "Lucas Petit" },
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <Badge className={`text-xs ${item.type === "[FRONT]" ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-700"}`}>{item.type}</Badge>
                      <span className="flex-1">{item.title}</span>
                      <span className="text-xs text-gray-400">{item.dev}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="border-t border-gray-100 pt-3">
                <p className="font-semibold text-gray-800 mb-3">📊 Release Analysis</p>
                <div className="space-y-3">
                  <div className="bg-green-50 border border-green-100 rounded-lg p-3">
                    <p className="text-xs font-semibold text-green-700 uppercase tracking-wide mb-1.5">✅ What went well</p>
                    <ul className="space-y-1 text-sm text-gray-700">
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />Release deployed to production with zero rollback — full stability</li>
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />All 7 developments validated in staging before go-live</li>
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 flex-shrink-0" />SSO fix resolved a recurring issue affecting 200+ daily active users</li>
                    </ul>
                  </div>
                  <div className="bg-orange-50 border border-orange-100 rounded-lg p-3">
                    <p className="text-xs font-semibold text-orange-700 uppercase tracking-wide mb-1.5">⚠️ Points of attention</p>
                    <ul className="space-y-1 text-sm text-gray-700">
                      <li className="flex items-start gap-2"><ChevronRight className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />BQ cache changes require monitoring for the next 48h — watch query latency</li>
                      <li className="flex items-start gap-2"><ChevronRight className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />iClosing URL migration may require user communication to update bookmarks</li>
                    </ul>
                  </div>
                  <div className="bg-blue-50 border border-blue-100 rounded-lg p-3">
                    <p className="text-xs font-semibold text-[#2649B2] uppercase tracking-wide mb-1.5">💡 Next steps</p>
                    <ul className="space-y-1 text-sm text-gray-700">
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Monitor production dashboards for 72h post-release</li>
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Send user communication for iClosing URL change to all impacted teams</li>
                      <li className="flex items-start gap-2"><CheckCircle className="w-3.5 h-3.5 text-[#2649B2] mt-0.5 flex-shrink-0" />Schedule Release 2.4.1 patch window if BQ anomalies are detected</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </ScrollArea>
          <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
            <Button variant="outline" onClick={() => setReleaseOpen(false)}>Close</Button>
            <Button className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white"><Download className="w-4 h-4 mr-2" />Export</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
