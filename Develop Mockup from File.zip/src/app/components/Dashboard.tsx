import { AlertCircle, TrendingDown, TrendingUp, Clock, Users, AlertTriangle, Bell, ChevronDown, Send, Bot, MessageSquare, ClipboardList, CheckCircle, Play } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { ScrollArea } from "./ui/scroll-area";
import { Button } from "./ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Textarea } from "./ui/textarea";
import { useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from "recharts";

export function Dashboard() {
  const [notifyOpen, setNotifyOpen] = useState(false);
  const [actionsOpen, setActionsOpen] = useState(false);
  const [actionsIncident, setActionsIncident] = useState("");
  return (
    <div className="flex-1 bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-3 lg:px-6 py-3 lg:py-4">
        <h1 className="text-xl font-semibold text-gray-900">Product Lead Portal</h1>
      </div>

      {/* Active Filter Chips */}
      <div className="flex gap-2 px-3 lg:px-6 py-2 bg-white border-b border-gray-100">
        <div className="inline-flex">
          <Select defaultValue="sprint24">
            <SelectTrigger className="h-8 rounded-full border-[#2649B2] text-[#2649B2] text-sm font-medium px-4 bg-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sprint22">Sprint 22 — 18/03 → 01/04</SelectItem>
              <SelectItem value="sprint23">Sprint 23 — 01/04 → 14/04</SelectItem>
              <SelectItem value="sprint24">Sprint 24 — 15/04 → 29/04</SelectItem>
              <SelectItem value="sprint25">Sprint 25 — 30/04 → 13/05</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="inline-flex">
          <Select defaultValue="all">
            <SelectTrigger className="h-8 rounded-full border-[#2649B2] text-[#2649B2] text-sm font-medium px-4 bg-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Assignment Groups</SelectItem>
              <SelectItem value="data-finance">DATA - Finance L3 BTDP</SelectItem>
              <SelectItem value="data-sourcing">DATA - Sourcing L3 BTDP</SelectItem>
              <SelectItem value="supply">Supply</SelectItem>
              <SelectItem value="sourcing">Sourcing</SelectItem>
              <SelectItem value="product">Product</SelectItem>
              <SelectItem value="marketing">Marketing</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-3 lg:p-5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Widget: Planned vs Consumed Capacity */}
          <Card className="bg-white shadow-md border border-gray-100 h-[468px] flex flex-col">
            <CardHeader className="flex-shrink-0 border-b border-gray-100 flex flex-row items-center justify-between py-3">
              <CardTitle className="text-base">Planned vs Consumed Capacity</CardTitle>
              <Button
                size="sm"
                className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white h-7 text-xs"
                onClick={() => setNotifyOpen(true)}
              >
                <Bell className="w-3 h-3 mr-1" />
                Notify Sprint Team
              </Button>
            </CardHeader>
            <CardContent className="p-0 flex-1 min-h-0">
              <ScrollArea className="h-full">
                <div className="p-3 space-y-6">
              <div className="grid grid-cols-2 gap-8">
                {/* Capacity Consumed */}
                <div className="space-y-3">
                  <span className="text-sm text-gray-600 block text-center">Consumed Capacity</span>
                  <div className="relative w-24 h-24 lg:w-32 lg:h-32 mx-auto">
                    <svg viewBox="0 0 128 128" className="w-full h-full transform -rotate-90">
                      <circle
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        stroke="#e5e7eb"
                        strokeWidth="8"
                      />
                      <circle
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        stroke="#2649B2"
                        strokeWidth="8"
                        strokeDasharray={`${2 * Math.PI * 56 * 0.8} ${2 * Math.PI * 56}`}
                        strokeLinecap="round"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-2xl font-semibold text-gray-900">80%</span>
                    </div>
                  </div>
                  <p className="text-xs text-center text-gray-600">80/100 MD</p>
                </div>

                {/* Time Progress */}
                <div className="space-y-3">
                  <span className="text-sm text-gray-600 block text-center">Time Progress</span>
                  <div className="relative w-24 h-24 lg:w-32 lg:h-32 mx-auto">
                    <svg viewBox="0 0 128 128" className="w-full h-full transform -rotate-90">
                      <circle
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        stroke="#e5e7eb"
                        strokeWidth="8"
                      />
                      <circle
                        cx="64"
                        cy="64"
                        r="56"
                        fill="none"
                        stroke="#6b7280"
                        strokeWidth="8"
                        strokeDasharray={`${2 * Math.PI * 56 * 0.6} ${2 * Math.PI * 56}`}
                        strokeLinecap="round"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-2xl font-semibold text-gray-900">60%</span>
                    </div>
                  </div>
                  <p className="text-xs text-center text-gray-600">4 days remaining</p>
                </div>
              </div>

              {/* Sprint Risk Alert */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 space-y-2">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-[#2649B2] mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-gray-800">
                    Sprint is <span className="font-semibold text-[#2649B2]">80%</span> complete — only <span className="font-semibold text-[#2649B2]">65%</span> of stories delivered so far. <span className="font-semibold text-[#2649B2]">6 stories</span> are at risk of missing the sprint deadline.
                  </p>
                </div>
                <p className="text-xs text-gray-500">Velocity slightly ahead: 20 MD consumed ahead of elapsed time.</p>
              </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Widget: Incidents & Defects */}
          <Card className="bg-white shadow-md border border-gray-100 h-[468px] flex flex-col">
            <CardHeader className="flex-shrink-0 border-b border-gray-100">
              <CardTitle className="text-base">Incidents & Defects</CardTitle>
            </CardHeader>
            <CardContent className="p-0 flex-1 min-h-0">
              <ScrollArea className="h-full">
                <div className="p-3 space-y-4">
              {/* Key Numbers */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600 mb-1">Open Incidents</p>
                  <p className="text-2xl font-semibold text-gray-900">12</p>
                  <p className="text-sm text-[#2649B2] font-medium">3 Critical</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600 mb-1">Open Defects</p>
                  <p className="text-2xl font-semibold text-gray-900">8</p>
                  <p className="text-sm text-[#2649B2] font-medium">2 Blocking</p>
                </div>
              </div>

              {/* Trend */}
              <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-lg p-2">
                <TrendingDown className="w-4 h-4 text-green-600" />
                <span className="text-sm text-gray-700">-2 critical incidents in the last 24h</span>
              </div>

              {/* Critical Items List */}
              <div className="space-y-2">
                <p className="text-xs font-medium text-gray-600 uppercase">Critical Items</p>
                <div className="space-y-2">
                  <div className="border border-gray-200 rounded-lg p-3 space-y-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="destructive" className="text-xs">1 - Critical</Badge>
                      <Badge variant="outline" className="text-xs font-mono">INC0001</Badge>
                      <span className="text-sm font-medium text-gray-900">SSO connection issue</span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-600 mt-1">
                      <span>Assignment group to be defined</span>
                      <div className="flex-1 flex justify-center">
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-xs h-7 px-3 border-gray-300 text-gray-600 hover:border-[#2649B2] hover:text-[#2649B2]"
                          onClick={() => { setActionsIncident("INC0001"); setActionsOpen(true); }}
                        >
                          Actions
                        </Button>
                      </div>
                      <span className="text-orange-600 font-medium">Open</span>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-3 space-y-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="destructive" className="text-xs">1 - Critical</Badge>
                      <Badge variant="outline" className="text-xs font-mono">DEF0045</Badge>
                      <span className="text-sm font-medium text-gray-900">Shopping cart bug</span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-600 mt-1">
                      <span>Assignment group to be defined</span>
                      <div className="flex-1 flex justify-center">
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-xs h-7 px-3 border-gray-300 text-gray-600 hover:border-[#2649B2] hover:text-[#2649B2]"
                          onClick={() => { setActionsIncident("DEF0045"); setActionsOpen(true); }}
                        >
                          Actions
                        </Button>
                      </div>
                      <span className="text-blue-600 font-medium">In Progress</span>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-3 space-y-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="destructive" className="text-xs">1 - Critical</Badge>
                      <Badge variant="outline" className="text-xs font-mono">INC0002</Badge>
                      <span className="text-sm font-medium text-gray-900">500 error payment API</span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-600 mt-1">
                      <span>Assignment group to be defined</span>
                      <div className="flex-1 flex justify-center">
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-xs h-7 px-3 border-gray-300 text-gray-600 hover:border-[#2649B2] hover:text-[#2649B2]"
                          onClick={() => { setActionsIncident("INC0002"); setActionsOpen(true); }}
                        >
                          Actions
                        </Button>
                      </div>
                      <span className="text-blue-600 font-medium">In Progress</span>
                    </div>
                  </div>
                </div>
              </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Widget: Current Sprint Timeline */}
          <Card className="bg-white shadow-md border border-gray-100 h-[468px] flex flex-col">
            <CardHeader className="flex-shrink-0 border-b border-gray-100">
              <CardTitle className="text-base">Current Sprint Timeline</CardTitle>
            </CardHeader>
            <CardContent className="p-0 flex-1 min-h-0">
              <ScrollArea className="h-full">
                <div className="p-3 space-y-4">
                <div className="space-y-3">
                <div className="flex items-start gap-3 pb-3 border-b border-gray-200">
                  <div className="w-2 h-2 rounded-full bg-[#2649B2] mt-2 flex-shrink-0" />
                  <div className="flex-1 space-y-1">
                    <p className="text-sm text-gray-600">15 min ago</p>
                    <p className="text-sm font-medium text-gray-900">
                      <span className="font-mono">STRY0758160</span> - <span className="text-[#2649B2]">"[FRONT] Fix colors in SGA dashboard in PLP – related to INC10226026"</span> moved to <span className="text-[#2649B2] font-semibold">Completed</span>
                    </p>
                    <p className="text-xs text-gray-500">by Marie Dupont</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pb-3 border-b border-gray-200">
                  <div className="w-2 h-2 rounded-full bg-gray-400 mt-2 flex-shrink-0" />
                  <div className="flex-1 space-y-1">
                    <p className="text-sm text-gray-600">1h ago</p>
                    <p className="text-sm font-medium text-gray-900">
                      <span className="font-mono">STRY0744438</span> - "[TECH] Tree SQL & Python optimization" moved to <span className="font-semibold">In Review</span>
                    </p>
                    <p className="text-xs text-gray-500">by Jean Martin</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pb-3 border-b border-gray-200">
                  <div className="w-2 h-2 rounded-full bg-orange-500 mt-2 flex-shrink-0" />
                  <div className="flex-1 space-y-1">
                    <p className="text-sm text-gray-600">2h ago</p>
                    <p className="text-sm font-medium text-gray-900">
                      <span className="font-mono">STRY0744463</span> - "[TECH] Step 1 – BQ decommissioning test: create secured views used by front & tree" moved to <span className="text-orange-600 font-semibold flex items-center gap-1 inline-flex">
                        <AlertTriangle className="w-3 h-3" /> Blocked
                      </span>
                    </p>
                    <p className="text-xs text-gray-500">by Sophie Bernard</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pb-3 border-b border-gray-200">
                  <div className="w-2 h-2 rounded-full bg-[#2649B2] mt-2 flex-shrink-0" />
                  <div className="flex-1 space-y-1">
                    <p className="text-sm text-gray-600">3h ago</p>
                    <p className="text-sm font-medium text-gray-900">
                      <span className="font-mono">STRY0735868</span> - <span className="text-[#2649B2]">"[FRONT][Integration] Add a dedicated URL for each analytics product under the iClosing URL"</span> moved to <span className="text-[#2649B2] font-semibold">In Production</span>
                    </p>
                    <p className="text-xs text-gray-500">by Pierre Leroy</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-gray-400 mt-2 flex-shrink-0" />
                  <div className="flex-1 space-y-1">
                    <p className="text-sm text-gray-600">4h ago</p>
                    <p className="text-sm font-medium text-gray-900">
                      <span className="font-mono">STRY0744431</span> - "[TECH] Increase cache expiring time for BQ caller (all users tables)" moved to <span className="font-semibold">In Progress</span>
                    </p>
                    <p className="text-xs text-gray-500">by Lucas Petit</p>
                  </div>
                </div>
                </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Widget: Project Priority Weighting */}
          <Card className="bg-white shadow-md border border-gray-100 h-[468px] flex flex-col">
            <CardHeader className="flex-shrink-0 border-b border-gray-100">
              <CardTitle className="text-base">Project Priority Weighting</CardTitle>
              <p className="text-sm text-gray-600 mt-2">Sprint-level priority analysis by project</p>
            </CardHeader>
            <CardContent className="p-0 flex-1 min-h-0">
              <ScrollArea className="h-full">
                <div className="p-3 space-y-4">
              <div className="space-y-3">
                {/* Project: OneFinancePortal */}
                <div className="border-2 border-[#2649B2] rounded-lg p-4 bg-blue-50">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">OneFinancePortal</h4>
                      <p className="text-xs text-gray-600 mt-1">Most critical project in sprint</p>
                    </div>
                    <Badge className="bg-[#2649B2] text-white hover:bg-[#2649B2]">Priority Score: 95</Badge>
                  </div>
                  <div className="grid grid-cols-4 gap-3 text-sm">
                    <div className="bg-white rounded p-2">
                      <p className="text-xs text-gray-600">Stories</p>
                      <p className="font-semibold text-gray-900">5</p>
                    </div>
                    <div className="bg-white rounded p-2">
                      <p className="text-xs text-gray-600">Critical</p>
                      <p className="font-semibold text-red-700">2</p>
                    </div>
                    <div className="bg-white rounded p-2">
                      <p className="text-xs text-gray-600">High</p>
                      <p className="font-semibold text-red-700">1</p>
                    </div>
                    <div className="bg-white rounded p-2">
                      <p className="text-xs text-gray-600">Moderate/Low</p>
                      <p className="font-semibold text-gray-700">2</p>
                    </div>
                  </div>
                </div>

                {/* Project: PO Creator */}
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">PO Creator</h4>
                    </div>
                    <Badge variant="outline" className="border-gray-600 text-gray-700">Priority Score: 72</Badge>
                  </div>
                  <div className="grid grid-cols-4 gap-3 text-sm">
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">Stories</p>
                      <p className="font-semibold text-gray-900">3</p>
                    </div>
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">Critical</p>
                      <p className="font-semibold text-red-700">1</p>
                    </div>
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">High</p>
                      <p className="font-semibold text-red-700">1</p>
                    </div>
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">Moderate/Low</p>
                      <p className="font-semibold text-gray-700">1</p>
                    </div>
                  </div>
                </div>

                {/* Project: Sustainable Finance Cockpit */}
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">Sustainable Finance Cockpit</h4>
                    </div>
                    <Badge variant="outline" className="border-gray-600 text-gray-700">Priority Score: 58</Badge>
                  </div>
                  <div className="grid grid-cols-4 gap-3 text-sm">
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">Stories</p>
                      <p className="font-semibold text-gray-900">4</p>
                    </div>
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">Critical</p>
                      <p className="font-semibold text-red-700">0</p>
                    </div>
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">High</p>
                      <p className="font-semibold text-red-700">2</p>
                    </div>
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">Moderate/Low</p>
                      <p className="font-semibold text-gray-700">2</p>
                    </div>
                  </div>
                </div>

                {/* Project: Headcount Tracker */}
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">Headcount Tracker</h4>
                    </div>
                    <Badge variant="outline" className="border-gray-600 text-gray-700">Priority Score: 35</Badge>
                  </div>
                  <div className="grid grid-cols-4 gap-3 text-sm">
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">Stories</p>
                      <p className="font-semibold text-gray-900">2</p>
                    </div>
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">Critical</p>
                      <p className="font-semibold text-red-700">0</p>
                    </div>
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">High</p>
                      <p className="font-semibold text-red-700">0</p>
                    </div>
                    <div className="bg-gray-50 rounded p-2">
                      <p className="text-xs text-gray-600">Moderate/Low</p>
                      <p className="font-semibold text-gray-700">2</p>
                    </div>
                  </div>
                </div>
              </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* Sprint Burndown Chart */}
        <Card className="bg-white shadow-md border border-gray-100 mt-4">
          <CardHeader className="flex-shrink-0 border-b border-gray-100 flex flex-row items-center justify-between py-3">
            <div>
              <CardTitle className="text-base">Sprint Burndown — Sprint #24</CardTitle>
              <p className="text-xs text-gray-500 mt-0.5">15/04 → 05/05 · Remaining story points over time</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1.5">
                <div className="w-6 h-0.5 bg-gray-300 rounded" style={{borderTop: '2px dashed #9ca3af'}}></div>
                <span className="text-gray-500">Ideal</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-6 h-0.5 bg-[#2649B2] rounded"></div>
                <span className="text-gray-500">Actual</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-6 h-0.5 bg-orange-400 rounded" style={{borderTop: '2px dashed #fb923c'}}></div>
                <span className="text-gray-500">Forecast</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-3 pt-4">
            <ResponsiveContainer width="100%" height={220}>
              <LineChart
                data={[
                  { day: "D1", ideal: 141, actual: 141 },
                  { day: "D2", ideal: 134, actual: 138 },
                  { day: "D3", ideal: 127, actual: 132 },
                  { day: "D4", ideal: 120, actual: 126 },
                  { day: "D5", ideal: 113, actual: 118 },
                  { day: "D6", ideal: 106, actual: 118 },
                  { day: "D7", ideal: 99, actual: 118 },
                  { day: "D8", ideal: 92, actual: 110 },
                  { day: "D9", ideal: 85, actual: 102 },
                  { day: "D10", ideal: 78, actual: 96 },
                  { day: "D11", ideal: 71, actual: 88 },
                  { day: "D12", ideal: 64, actual: 82 },
                  { day: "D13", ideal: 57, actual: 57, forecast: 57 },
                  { day: "D14", ideal: 50, forecast: 50 },
                  { day: "D15", ideal: 43, forecast: 43 },
                  { day: "D16", ideal: 36, forecast: 36 },
                  { day: "D17", ideal: 29, forecast: 29 },
                  { day: "D18", ideal: 22, forecast: 22 },
                  { day: "D19", ideal: 15, forecast: 15 },
                  { day: "D20", ideal: 8, forecast: 8 },
                  { day: "D21", ideal: 0, forecast: 0 },
                ]}
                margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
              >
                <CartesianGrid key="grid" strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis key="xaxis" dataKey="day" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <YAxis key="yaxis" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} width={35} unit=" pts" />
                <Tooltip
                  key="tooltip"
                  contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e5e7eb', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  formatter={(value: number, name: string) => [
                    `${value} pts remaining`,
                    name === 'ideal' ? 'Ideal' : name === 'actual' ? 'Actual' : 'Forecast'
                  ]}
                />
                <ReferenceLine key="refline" x="D13" stroke="#e5e7eb" strokeDasharray="4 4" label={{ value: 'Today', fontSize: 10, fill: '#9ca3af' }} />
                <Line key="ideal-line" type="monotone" dataKey="ideal" stroke="#d1d5db" strokeDasharray="5 5" strokeWidth={1.5} dot={false} name="ideal" />
                <Line key="actual-line" type="monotone" dataKey="actual" stroke="#2649B2" strokeWidth={2} dot={{ r: 3, fill: '#2649B2' }} connectNulls={false} name="actual" />
                <Line key="forecast-line" type="monotone" dataKey="forecast" stroke="#fb923c" strokeDasharray="4 4" strokeWidth={1.5} dot={false} connectNulls={false} name="forecast" />
              </LineChart>
            </ResponsiveContainer>
            <div className="flex items-center justify-between px-2 mt-1">
              <div className="flex items-center gap-4 text-xs text-gray-500">
                <span>Start: <span className="font-semibold text-gray-700">141 pts</span></span>
                <span>Remaining: <span className="font-semibold text-[#2649B2]">57 pts</span></span>
                <span>Delivered: <span className="font-semibold text-green-600">84 pts</span></span>
              </div>
              <span className="text-xs text-orange-500 font-medium">⚠ Forecast shows 8 pts at risk</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notify Dialog */}
      <Dialog open={notifyOpen} onOpenChange={setNotifyOpen}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">Notify Sprint Team</DialogTitle>
            <DialogDescription className="sr-only">Send notification to sprint team about at-risk stories</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="bg-white rounded-lg p-3 shadow-sm border border-gray-100 flex-1">
                  <Textarea
                    className="border-0 p-0 text-sm text-gray-700 resize-none focus-visible:ring-0 min-h-[100px] bg-transparent"
                    defaultValue={"Hi team,\n\nAs of today, Sprint #24 is 80% complete in terms of time elapsed but only 65% of stories have been delivered. We currently have 6 stories at risk of not being completed before the sprint deadline on 29/04.\n\nPlease review your remaining stories and flag any blockers as soon as possible.\n\nThanks!"}
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setNotifyOpen(false)}>Cancel</Button>
              <Button className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white" onClick={() => setNotifyOpen(false)}>
                <Send className="w-4 h-4 mr-2" />
                Send
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Actions Dialog */}
      <Dialog open={actionsOpen} onOpenChange={setActionsOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">Actions — {actionsIncident}</DialogTitle>
            <DialogDescription className="sr-only">Select an action for this incident</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 py-2">
            {[
              { label: "Link to stories", icon: ClipboardList, description: "Associate this incident with a sprint story" },
              { label: "Resume incident", icon: Play, description: "Re-open and assign this incident for active resolution" },
              { label: "Create War Room", icon: Users, description: "Escalate and open a dedicated war room channel for this incident" },
            ].map((action, idx) => (
              <button
                key={idx}
                className="w-full flex items-start gap-3 p-3 rounded-lg border border-gray-200 hover:border-[#2649B2] hover:bg-blue-50 transition-colors text-left group"
                onClick={() => setActionsOpen(false)}
              >
                <action.icon className="w-4 h-4 text-gray-400 group-hover:text-[#2649B2] mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-gray-900 group-hover:text-[#2649B2]">{action.label}</p>
                  <p className="text-xs text-gray-500">{action.description}</p>
                </div>
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
