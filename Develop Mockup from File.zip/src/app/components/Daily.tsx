import { useState, useRef, useEffect } from "react";
import { Play, Pause, RotateCcw, MessageSquare, Clock, Bot, Send } from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Textarea } from "./ui/textarea";

export function Daily() {
  const [notifyModal, setNotifyModal] = useState<{
    open: boolean;
    devName: string;
    storyTitle: string;
    estimated: number;
    elapsed: number;
  }>({ open: false, devName: "", storyTitle: "", estimated: 0, elapsed: 0 });

  const [timeLeft, setTimeLeft] = useState(15 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startTimer = () => {
    if (isRunning || timeLeft === 0) return;
    setIsRunning(true);
    intervalRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(intervalRef.current!);
          setIsRunning(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const pauseTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setIsRunning(false);
  };

  const resetTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setIsRunning(false);
    setTimeLeft(15 * 60);
  };

  useEffect(() => {
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  const formatTime = (s: number) => `${Math.floor(s/60).toString().padStart(2,'0')}:${(s%60).toString().padStart(2,'0')}`;

  const developers = [
    {
      name: "Marie Dupont",
      avatar: "MD",
      stories: [
        {
          id: "STRY0744431",
          title: "[TECH] Increase cache expiring time for BQ caller",
          status: "Work in progress",
          estimated: 3,
          elapsed: 2,
          delayed: false,
        },
        {
          id: "STRY0740621",
          title: "[TECH] Add missing P&L line in PLP",
          status: "Ready for testing",
          estimated: 4,
          elapsed: 6,
          delayed: true,
        },
      ],
    },
    {
      name: "Jean Martin",
      avatar: "JM",
      stories: [
        {
          id: "STRY0740619",
          title: "[TECH] Delete P&L lines automation",
          status: "Complete",
          estimated: 5,
          elapsed: 5,
          delayed: false,
        },
      ],
    },
    {
      name: "Sophie Bernard",
      avatar: "SB",
      stories: [
        {
          id: "STRY0744463",
          title: "[TECH] BQ decommissioning step 1",
          status: "Work in progress",
          estimated: 3,
          elapsed: 5,
          delayed: true,
        },
      ],
    },
    {
      name: "Pierre Leroy",
      avatar: "PL",
      stories: [
        {
          id: "STRY0744438",
          title: "[TECH] Tree SQL & Python optimization",
          status: "Ready",
          estimated: 8,
          elapsed: 2,
          delayed: false,
        },
      ],
    },
    {
      name: "Lucas Petit",
      avatar: "LP",
      stories: [
        {
          id: "STRY0758160",
          title: "[FRONT] Fix SGA dashboard colors",
          status: "Testing",
          estimated: 2,
          elapsed: 3,
          delayed: true,
        },
      ],
    },
    {
      name: "Emma Rousseau",
      avatar: "ER",
      stories: [
        {
          id: "STRY0744446",
          title: "[TECH] BQ decommissioning step 2",
          status: "Complete",
          estimated: 3,
          elapsed: 3,
          delayed: false,
        },
      ],
    },
    {
      name: "Thomas Dubois",
      avatar: "TD",
      stories: [
        {
          id: "STRY0735868",
          title: "[FRONT] Dedicated URL for iClosing",
          status: "Work in progress",
          estimated: 5,
          elapsed: 4,
          delayed: false,
        },
      ],
    },
    {
      name: "Léa Moreau",
      avatar: "LM",
      stories: [
        {
          id: "STRY0765001",
          title: "[FRONT] Employee dashboard redesign",
          status: "Draft",
          estimated: 6,
          elapsed: 1,
          delayed: false,
        },
      ],
    },
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Draft":
        return <Badge variant="outline" className="border-gray-600 text-gray-600 text-[11px]">{status}</Badge>;
      case "Ready":
        return <Badge variant="outline" className="border-[#2649B2] text-[#2649B2] text-[11px]">{status}</Badge>;
      case "Work in progress":
        return <Badge className="bg-[#2649B2] text-white hover:bg-[#2649B2] text-[11px]">{status}</Badge>;
      case "Ready for testing":
        return <Badge variant="outline" className="border-purple-600 text-purple-600 text-[11px]">{status}</Badge>;
      case "Testing":
        return <Badge className="bg-purple-600 text-white hover:bg-purple-600 text-[11px]">{status}</Badge>;
      case "Complete":
        return <Badge className="bg-green-600 text-white hover:bg-green-600 text-[11px]">{status}</Badge>;
      case "Cancelled":
        return <Badge className="bg-gray-600 text-white hover:bg-gray-600 text-[11px]">{status}</Badge>;
      default:
        return <Badge variant="outline" className="text-[11px]">{status}</Badge>;
    }
  };

  return (
    <div className="flex-1 bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-3 lg:px-6 py-3 lg:py-4">
        <h1 className="text-xl font-semibold text-gray-900">Daily Standup</h1>
        <p className="text-sm text-gray-600 mt-1">06/05/2026 · Sprint #24 — 15/04 → 29/04</p>
      </div>

      {/* Main Content */}
      <div className="p-3 lg:p-5 bg-gray-50">
        {/* Compact Timer Banner */}
        <div className="bg-white border border-gray-200 rounded-lg px-6 py-3 mb-4 flex items-center justify-between">
          <div className="flex items-center">
            <Clock className="w-4 h-4 text-[#2649B2] mr-2" />
            <span className="text-sm text-gray-600">Standup Timer</span>
          </div>
          <p className={`text-2xl font-bold ${timeLeft <= 60 ? 'text-red-600' : timeLeft <= 3*60 ? 'text-orange-500' : 'text-[#2649B2]'}`}>
            {formatTime(timeLeft)}
          </p>
          <div className="flex gap-2">
            <Button
              size="sm"
              className="bg-[#2649B2] text-white hover:bg-[#1d3a8f] h-8"
              onClick={() => startTimer()}
              disabled={isRunning || timeLeft === 0}
            >
              <Play className="w-3 h-3 mr-1" />
              Start
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-8"
              onClick={() => pauseTimer()}
              disabled={!isRunning}
            >
              <Pause className="w-3 h-3 mr-1" />
              Pause
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-8"
              onClick={() => resetTimer()}
            >
              <RotateCcw className="w-3 h-3 mr-1" />
              Reset
            </Button>
          </div>
        </div>

        <Progress value={((15*60 - timeLeft) / (15*60)) * 100} className="h-1 mb-6" />

        <div className="mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Team Stories — Current Sprint</h2>
        </div>

        {/* Developer Cards Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {developers.map((dev, devIdx) => (
            <Card key={devIdx} className="bg-white shadow-md border border-gray-100">
              <CardHeader className="py-2">
                <div className="flex items-center gap-2">
                  <Avatar className="w-6 h-6">
                    <AvatarFallback className="bg-[#2649B2] text-white text-[11px]">
                      {dev.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium text-gray-900">{dev.name}</span>
                  <Badge variant="outline" className="ml-auto text-xs">
                    {dev.stories.length}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-3">
                <div className="space-y-0">
                  {dev.stories.map((story, storyIdx) => (
                    <div
                      key={storyIdx}
                      className={story.delayed ? "border border-red-300 rounded-lg p-2 bg-red-50 space-y-1 mb-2" : "border border-gray-200 rounded-lg p-2 bg-white space-y-1 mb-2"}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[11px] text-gray-400">{story.id}</span>
                        {getStatusBadge(story.status)}
                      </div>
                      <p className="text-[13px] text-gray-800 leading-snug">{story.title}</p>
                      <p className="text-[11px] text-gray-500">
                        Est: {story.estimated} d · Elapsed: {story.elapsed} d
                      </p>
                      {story.delayed && (
                        <div className="flex items-center gap-1 mt-1">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7 px-3 text-[11px] border-red-300 text-red-600 hover:bg-red-50 hover:border-red-500 mt-1"
                            onClick={() =>
                              setNotifyModal({
                                open: true,
                                devName: dev.name,
                                storyTitle: story.title,
                                estimated: story.estimated,
                                elapsed: story.elapsed,
                              })
                            }
                          >
                            <MessageSquare className="w-3 h-3 mr-1" />
                            Notify
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <Dialog open={notifyModal.open} onOpenChange={(open) => setNotifyModal((prev) => ({ ...prev, open }))}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">Send notification — {notifyModal.storyTitle}</DialogTitle>
            <DialogDescription className="sr-only">Send notification to developer and DPO about delayed story</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 mt-2">

            {/* Frame 1 — Developer */}
            <div className="space-y-2">
              <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-[#2649B2] inline-block"></span>
                Developer — {notifyModal.devName}
              </p>
              <div className="bg-gray-50 rounded-xl p-3 border border-gray-200">
                <div className="flex items-start gap-2">
                  <div className="w-7 h-7 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
                    <Bot className="w-3.5 h-3.5 text-white" />
                  </div>
                  <div className="bg-white rounded-lg p-2.5 shadow-sm border border-gray-100 flex-1">
                    <Textarea
                      className="border-0 p-0 text-xs text-gray-700 resize-none focus-visible:ring-0 min-h-[90px] bg-transparent"
                      defaultValue={`Hi ${notifyModal.devName},\n\nYour story "${notifyModal.storyTitle}" is delayed — estimated at ${notifyModal.estimated} days but ${notifyModal.elapsed} days have elapsed.\n\nCould you share a quick update and flag any blockers? Thanks!`}
                    />
                  </div>
                </div>
              </div>
              <Button size="sm" className="w-full bg-[#2649B2] hover:bg-[#1d3a8f] text-white h-7 text-xs" onClick={() => setNotifyModal(prev => ({ ...prev, open: false }))}>
                <Send className="w-3 h-3 mr-1" /> Send to Developer
              </Button>
            </div>

            {/* Frame 2 — DPO */}
            <div className="space-y-2">
              <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-orange-500 inline-block"></span>
                Data Product Owner (DPO)
              </p>
              <div className="bg-gray-50 rounded-xl p-3 border border-gray-200">
                <div className="flex items-start gap-2">
                  <div className="w-7 h-7 rounded-full bg-orange-500 flex items-center justify-center flex-shrink-0">
                    <Bot className="w-3.5 h-3.5 text-white" />
                  </div>
                  <div className="bg-white rounded-lg p-2.5 shadow-sm border border-gray-100 flex-1">
                    <Textarea
                      className="border-0 p-0 text-xs text-gray-700 resize-none focus-visible:ring-0 min-h-[90px] bg-transparent"
                      defaultValue={`Hi DPO,\n\nThis is an alert regarding "${notifyModal.storyTitle}" assigned to ${notifyModal.devName}. The story is delayed — estimated at ${notifyModal.estimated} days but ${notifyModal.elapsed} days have elapsed.\n\nYour attention may be required. Please review and advise. Thanks!`}
                    />
                  </div>
                </div>
              </div>
              <Button size="sm" variant="outline" className="w-full border-orange-300 text-orange-600 hover:bg-orange-50 h-7 text-xs" onClick={() => setNotifyModal(prev => ({ ...prev, open: false }))}>
                <Send className="w-3 h-3 mr-1" /> Send to DPO
              </Button>
            </div>

          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
