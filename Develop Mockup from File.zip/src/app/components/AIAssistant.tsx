import { Bot, Send } from "lucide-react";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";

export function AIAssistant() {
  const mockMessages = [
    { type: "user", text: "What is the current sprint status?" },
    { type: "assistant", text: "The sprint is 60% complete with 80% of capacity consumed. You are slightly ahead of schedule." },
    { type: "user", text: "What are the critical incidents?" },
    { type: "assistant", text: "There are 2 P1 incidents open: SSO issue and shopping cart bug." },
  ];

  return (
    <div className="w-56 lg:w-72 h-full bg-white border-r border-gray-200 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#2649B2] flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <h2 className="text-lg font-semibold text-gray-900">AI Assistant</h2>
        </div>
      </div>

      {/* Chat Messages */}
      <ScrollArea className="flex-1 p-6">
        <div className="space-y-4">
          {mockMessages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[80%] rounded-lg px-4 py-2 ${
                  msg.type === "user"
                    ? "bg-[#2649B2] text-white"
                    : "bg-gray-100 text-gray-900"
                }`}
              >
                <p className="text-sm">{msg.text}</p>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="p-3 border-t border-gray-200">
        <div className="flex gap-2">
          <Input
            placeholder="Ask your question..."
            className="flex-1"
          />
          <Button size="icon" className="bg-[#2649B2] hover:bg-[#1d3a8f]">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
