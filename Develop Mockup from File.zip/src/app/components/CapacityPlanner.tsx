import { Calendar, Play, StopCircle, Filter, Plus, Minus, Send, AlertCircle, CheckCircle, ChevronDown } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { ScrollArea } from "./ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { useState } from "react";

export function CapacityPlanner() {
  const [sendConfirmOpen, setSendConfirmOpen] = useState(false);
  const [devPickerOpen, setDevPickerOpen] = useState(false);
  const [selectedDevs, setSelectedDevs] = useState<string[]>([]);
  const [selectedStories, setSelectedStories] = useState<string[]>([]);
  const [storyPoints, setStoryPoints] = useState<Record<string, number>>({});
  const teamMembers = [
    { name: "Marie Dupont", capacity: 20, allocated: 15, availability: 18, avatar: "MD" },
    { name: "Jean Martin", capacity: 20, allocated: 20, availability: 20, avatar: "JM" },
    { name: "Sophie Bernard", capacity: 20, allocated: 18, availability: 19, avatar: "SB" },
    { name: "Pierre Leroy", capacity: 20, allocated: 20, availability: 17, avatar: "PL" },
    { name: "Lucas Petit", capacity: 20, allocated: 12, availability: 20, avatar: "LP" },
    { name: "Emma Rousseau", capacity: 20, allocated: 20, availability: 20, avatar: "ER" },
    { name: "Thomas Dubois", capacity: 20, allocated: 20, availability: 18, avatar: "TD" },
    { name: "Léa Moreau", capacity: 20, allocated: 16, availability: 20, avatar: "LM" },
  ];

  const projects = [
    { name: "OneFinancePortal", capacity: 45, percentage: 30 },
    { name: "PO Creator", capacity: 37, percentage: 25 },
    { name: "Sustainable Finance Cockpit", capacity: 30, percentage: 20 },
    { name: "Headcount Tracker", capacity: 23, percentage: 15 },
    { name: "Value Creation Engine", capacity: 15, percentage: 10 },
  ];

  const stories = [
    { id: "STRY0744438", title: "[TECH] Tree SQL & Python optimization", priority: "1 - Critical", points: 13, status: "Work in progress", assignee: "Pierre Leroy", project: "OneFinancePortal", avatar: "PL" },
    { id: "STRY0744431", title: "[TECH] Increase cache expiring time for BQ caller (all users tables)", priority: "1 - Critical", points: 8, status: "Work in progress", assignee: "Marie Dupont", project: "PO Creator", avatar: "MD" },
    { id: "STRY0740619", title: "[TECH] Delete this list of P&L lines in PLP and PLC modules – automation", priority: "2 - High", points: 13, status: "Complete", assignee: "Sophie Bernard", project: "Sustainable Finance Cockpit", avatar: "SB" },
    { id: "STRY0740621", title: "[TECH] Add missing P&L line in PLP – automation", priority: "3 - Moderate", points: 8, status: "Work in progress", assignee: "Jean Martin", project: "Headcount Tracker", avatar: "JM" },
    { id: "STRY0744463", title: "[TECH] Step 1 – BQ decommissioning test: create secured views used by front & tree", priority: "4 - Low", points: 5, status: "Ready", assignee: "Léa Moreau", project: "Value Creation Engine", avatar: "LM" },
    { id: "STRY0744446", title: "[TECH] Step 2 – BQ decommissioning test: modify Tree code to read from secured views", priority: "3 - Moderate", points: 5, status: "Complete", assignee: "Emma Rousseau", project: "SDDS", avatar: "ER" },
    { id: "STRY0758160", title: "[FRONT] Fix colors in SGA dashboard in PLP – related to INC10226026", priority: "4 - Low", points: 3, status: "Testing", assignee: "Lucas Petit", project: "iClosing for Accounting", avatar: "LP" },
    { id: "STRY0735868", title: "[FRONT][Integration] Add a dedicated URL for each analytics product under the iClosing URL", priority: "2 - High", points: 8, status: "Ready for testing", assignee: "Thomas Dubois", project: "Launches Tracker", avatar: "TD" },
  ];

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "Draft":
        return "border-gray-600 text-gray-600";
      case "Ready":
        return "border-[#2649B2] text-[#2649B2]";
      case "Work in progress":
        return "bg-[#2649B2] text-white border-[#2649B2]";
      case "Ready for testing":
        return "border-purple-600 text-purple-600";
      case "Testing":
        return "bg-purple-600 text-white border-purple-600";
      case "Complete":
        return "bg-green-600 text-white border-green-600";
      case "Cancelled":
        return "bg-gray-600 text-white border-gray-600";
      default:
        return "border-gray-600 text-gray-600";
    }
  };

  const totalCapacity = 160;
  const totalAllocated = 141;
  const totalAvailable = 19;

  return (
    <div className="flex-1 bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-3 lg:px-6 py-3 lg:py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-gray-900">Capacity Planner</h1>
          </div>
          <div className="flex gap-3">
            <Button className="bg-[#2649B2] hover:bg-[#1d3a8f]">
              <Play className="w-4 h-4 mr-2" />
              Start new Sprint
            </Button>
            <Button variant="outline">
              <StopCircle className="w-4 h-4 mr-2" />
              Close Sprint
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-3 lg:p-5">
        <div>
          {/* Sprint Selector Bar */}
          <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
            <div className="flex items-center gap-3">
              <span className="text-sm text-gray-600">Select Sprint:</span>
              <Select defaultValue="sprint24">
                <SelectTrigger className="w-[280px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sprint22">Sprint 22 — 18/03 → 01/04</SelectItem>
                  <SelectItem value="sprint23">Sprint 23 — 01/04 → 14/04</SelectItem>
                  <SelectItem value="sprint24">Sprint 24 — 15/04 → 29/04</SelectItem>
                  <SelectItem value="sprint25">Sprint 25 — 30/04 → 13/05</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-4">
            {/* Widget: Individual Team Capacity */}
            <Card className="bg-white shadow-md border border-gray-100">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">Individual Team Capacity</CardTitle>
                    <p className="text-sm text-gray-600 mt-2">
                      Total capacity: {totalCapacity} MD • Allocated: {totalAllocated} MD • Available: {totalAvailable} MD
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-6">
                  {/* LEFT SIDE - Compact Member List */}
                  <div>
                    <ScrollArea className="h-[280px] lg:h-[320px]">
                      <div className="space-y-2">
                        {teamMembers.map((member, idx) => {
                          const allocPercentage = Math.round((member.allocated / member.capacity) * 100);
                          const isOverloaded = allocPercentage >= 100;
                          const isWarning = allocPercentage >= 80 && allocPercentage < 100;
                          const colorBar = isOverloaded ? "[&>div]:bg-red-500" : isWarning ? "[&>div]:bg-orange-400" : "[&>div]:bg-green-500";
                          const colorBadge = isOverloaded
                            ? "bg-red-100 text-red-700 border border-red-200"
                            : isWarning
                            ? "bg-orange-100 text-orange-700 border border-orange-200"
                            : "bg-green-100 text-green-700 border border-green-200";
                          return (
                            <div key={idx} className="flex items-center gap-3 py-2 border-b border-gray-100">
                              {/* Left: avatar + name */}
                              <div className="flex items-center gap-2 flex-shrink-0 w-36">
                                <Avatar className="w-6 h-6 flex-shrink-0">
                                  <AvatarFallback className="bg-[#2649B2] text-white text-[11px]">{member.avatar}</AvatarFallback>
                                </Avatar>
                                <span className="text-sm text-gray-800 truncate">{member.name}</span>
                              </div>

                              {/* Center: progress + stats */}
                              <div className="flex items-center gap-3 flex-1 min-w-0">
                                <Progress value={Math.min(allocPercentage, 100)} className={`w-20 h-1.5 bg-gray-200 ${colorBar}`} />
                                <span className={`text-xs font-semibold px-1.5 py-0.5 rounded-full whitespace-nowrap ${colorBadge}`}>
                                  {allocPercentage}%
                                </span>
                                <span className="text-xs text-gray-500 whitespace-nowrap">Total: {member.capacity} MD</span>
                                <span className="text-xs text-gray-600 font-medium whitespace-nowrap">Alloc: {member.allocated} MD</span>
                              </div>

                              {/* Far right: minus button */}
                              <Button variant="outline" size="icon" className="h-6 w-6 border-red-300 text-red-600 hover:bg-red-50 hover:border-red-500 flex-shrink-0 rounded-md ml-auto">
                                <Minus className="w-3 h-3" />
                              </Button>
                            </div>
                          );
                        })}
                      </div>
                    </ScrollArea>
                  </div>

                  {/* RIGHT SIDE - Frontend vs Backend Breakdown */}
                  <div>
                    <h3 className="text-sm font-semibold text-gray-700 mb-4">Capacity by Profile</h3>

                    <div className="flex items-center justify-around mb-6">
                      {/* Frontend Donut */}
                      <div className="flex flex-col items-center gap-2">
                        <div className="relative w-28 h-28">
                          <svg viewBox="0 0 128 128" className="w-full h-full transform -rotate-90">
                            <circle cx="64" cy="64" r="52" fill="none" stroke="#e5e7eb" strokeWidth="10" />
                            <circle cx="64" cy="64" r="52" fill="none" stroke="#2649B2" strokeWidth="10"
                              strokeDasharray={`${2 * Math.PI * 52 * 0.95} ${2 * Math.PI * 52}`}
                              strokeLinecap="round" />
                          </svg>
                          <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-xl font-bold text-gray-900">95%</span>
                          </div>
                        </div>
                        <p className="text-sm font-medium text-gray-800">Frontend</p>
                        <p className="text-xs text-gray-500">76 / 80 MD</p>
                        <p className="text-xs text-gray-400">4 developers</p>
                      </div>

                      {/* Backend / Data Donut */}
                      <div className="flex flex-col items-center gap-2">
                        <div className="relative w-28 h-28">
                          <svg viewBox="0 0 128 128" className="w-full h-full transform -rotate-90">
                            <circle cx="64" cy="64" r="52" fill="none" stroke="#e5e7eb" strokeWidth="10" />
                            <circle cx="64" cy="64" r="52" fill="none" stroke="#4A5568" strokeWidth="10"
                              strokeDasharray={`${2 * Math.PI * 52 * 0.81} ${2 * Math.PI * 52}`}
                              strokeLinecap="round" />
                          </svg>
                          <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-xl font-bold text-gray-900">81%</span>
                          </div>
                        </div>
                        <p className="text-sm font-medium text-gray-800">Backend / Data</p>
                        <p className="text-xs text-gray-500">65 / 80 MD</p>
                        <p className="text-xs text-gray-400">4 developers</p>
                      </div>
                    </div>

                    {/* Team Total Summary */}
                    <div className="bg-blue-50 border border-blue-100 rounded-lg p-3">
                      <p className="text-sm text-gray-700">
                        Team total: 141 MD allocated out of 160 MD capacity (<span className="font-semibold text-[#2649B2]">88%</span>)
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Widget: Sprint Content */}
            <Card className="bg-white shadow-md border border-gray-100">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">Sprint Content</CardTitle>
                  <div className="flex items-center gap-2">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button size="sm" className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white h-8">
                          Actions
                          <ChevronDown className="w-3 h-3 ml-1" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>Refresh</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setSendConfirmOpen(true)}>Update current Sprint</DropdownMenuItem>
                        <DropdownMenuItem>Move to</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <ScrollArea className="h-[320px] lg:h-[500px]">
                    <table className="table-fixed w-full">
                      <colgroup>
                        <col className="w-[40px]" />
                        <col className="w-[120px]" />
                        <col className="w-[280px]" />
                        <col className="w-[150px]" />
                        <col className="w-[60px]" />
                        <col className="w-[170px]" />
                        <col className="w-[170px]" />
                        <col className="w-[140px]" />
                      </colgroup>
                      <thead className="border-b border-gray-200">
                        <tr className="text-left">
                          <th className="pb-3 text-xs font-medium text-gray-600 uppercase"></th>
                          <th className="pb-3 text-xs font-medium text-gray-600 uppercase">ID</th>
                          <th className="pb-3 text-xs font-medium text-gray-600 uppercase">Title</th>
                          <th className="pb-3 text-xs font-medium text-gray-600 uppercase">Priority</th>
                          <th className="pb-3 text-xs font-medium text-gray-600 uppercase">Points</th>
                          <th className="pb-3 text-xs font-medium text-gray-600 uppercase">Status</th>
                          <th className="pb-3 text-xs font-medium text-gray-600 uppercase">Assigned to</th>
                          <th className="pb-3 text-xs font-medium text-gray-600 uppercase">Epic</th>
                        </tr>
                      </thead>
                    <tbody className="divide-y divide-gray-200">
                      {stories.map((story, idx) => (
                        <tr key={idx} className={`hover:bg-gray-50 ${story.priority === "4 - Low" ? "bg-gray-100" : ""}`}>
                          <td className="py-3">
                            <input
                              type="checkbox"
                              className="w-4 h-4 rounded border-gray-300 text-[#2649B2] focus:ring-[#2649B2]"
                              checked={selectedStories.includes(story.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedStories(prev => [...prev, story.id]);
                                } else {
                                  setSelectedStories(prev => prev.filter(id => id !== story.id));
                                }
                              }}
                            />
                          </td>
                          <td className="py-3 text-sm text-gray-900 font-mono">{story.id}</td>
                          <td className="py-3 text-sm text-gray-900 pr-2">
                            <span className="block truncate" title={story.title}>{story.title}</span>
                          </td>
                          <td className="py-3">
                            <Select defaultValue={story.priority}>
                              <SelectTrigger className="w-[140px] h-8">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="1 - Critical">1 - Critical</SelectItem>
                                <SelectItem value="2 - High">2 - High</SelectItem>
                                <SelectItem value="3 - Moderate">3 - Moderate</SelectItem>
                                <SelectItem value="4 - Low">4 - Low</SelectItem>
                              </SelectContent>
                            </Select>
                          </td>
                          <td className="py-3">
                            <input
                              type="number"
                              className="w-12 h-8 text-sm text-gray-900 font-semibold border border-gray-200 rounded px-2 focus:outline-none focus:border-[#2649B2] focus:ring-1 focus:ring-[#2649B2] [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                              value={storyPoints[story.id] ?? story.points}
                              onChange={(e) => setStoryPoints(prev => ({ ...prev, [story.id]: parseInt(e.target.value) || 0 }))}
                            />
                          </td>
                          <td className="py-3">
                            <Select defaultValue={story.status}>
                              <SelectTrigger className="w-[160px] h-8">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Draft">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-gray-600" />
                                    <span>Draft</span>
                                  </div>
                                </SelectItem>
                                <SelectItem value="Ready">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full border-2 border-[#2649B2]" />
                                    <span>Ready</span>
                                  </div>
                                </SelectItem>
                                <SelectItem value="Work in progress">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-[#2649B2]" />
                                    <span>Work in progress</span>
                                  </div>
                                </SelectItem>
                                <SelectItem value="Ready for testing">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full border-2 border-purple-600" />
                                    <span>Ready for testing</span>
                                  </div>
                                </SelectItem>
                                <SelectItem value="Testing">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-purple-600" />
                                    <span>Testing</span>
                                  </div>
                                </SelectItem>
                                <SelectItem value="Complete">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-green-600" />
                                    <span>Complete</span>
                                  </div>
                                </SelectItem>
                                <SelectItem value="Cancelled">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-gray-600" />
                                    <span className="line-through">Cancelled</span>
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </td>
                          <td className="py-3">
                            <Select defaultValue={story.assignee}>
                              <SelectTrigger className="w-[160px] h-8">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Marie Dupont">Marie Dupont</SelectItem>
                                <SelectItem value="Jean Martin">Jean Martin</SelectItem>
                                <SelectItem value="Sophie Bernard">Sophie Bernard</SelectItem>
                                <SelectItem value="Pierre Leroy">Pierre Leroy</SelectItem>
                                <SelectItem value="Lucas Petit">Lucas Petit</SelectItem>
                                <SelectItem value="Emma Rousseau">Emma Rousseau</SelectItem>
                                <SelectItem value="Thomas Dubois">Thomas Dubois</SelectItem>
                                <SelectItem value="Léa Moreau">Léa Moreau</SelectItem>
                              </SelectContent>
                            </Select>
                          </td>
                          <td className="py-3 text-sm text-gray-600">{story.project}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  </ScrollArea>
                </div>
              </CardContent>
            </Card>

            {/* Widget: Capacity Distribution by Project */}
            <Card className="bg-white shadow-md border border-gray-100">
              <CardHeader>
                <CardTitle className="text-base">Capacity Distribution by Project/Initiative</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[280px] lg:h-[400px]">
                      <div className="space-y-2">
                        {projects.map((project, idx) => (
                          <div key={idx} className="border border-gray-200 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-medium text-gray-900">{project.name}</span>
                              <Badge className="bg-[#2649B2] hover:bg-[#2649B2]">
                                {project.percentage}%
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between text-xs text-gray-600">
                              <span>Allocated capacity</span>
                              <span className="font-semibold text-gray-900">{project.capacity} MD</span>
                            </div>
                            <Progress value={project.percentage} className="h-2 mt-2" />
                          </div>
                        ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Send Confirmation Dialog */}
      <Dialog open={sendConfirmOpen} onOpenChange={setSendConfirmOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">Confirm Send</DialogTitle>
            <DialogDescription className="sr-only">Confirm sending sprint content to team members</DialogDescription>
          </DialogHeader>
          <div className="py-3 space-y-3">
            <div className="flex items-start gap-3 bg-blue-50 border border-blue-100 rounded-lg p-3">
              <AlertCircle className="w-5 h-5 text-[#2649B2] flex-shrink-0 mt-0.5" />
              <p className="text-sm text-gray-700">Are you sure you want to send all the stories to ServiceNow? This will push <span className="font-semibold text-[#2649B2]">8 stories</span> from <span className="font-semibold text-[#2649B2]">Sprint #24</span> to ServiceNow and update their status, assignees, and priorities accordingly.</p>
            </div>
          </div>
          <div className="flex justify-end gap-2 border-t border-gray-100 pt-3">
            <Button variant="outline" onClick={() => setSendConfirmOpen(false)}>Cancel</Button>
            <Button className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white" onClick={() => setSendConfirmOpen(false)}>
              <Send className="w-4 h-4 mr-2" />
              Yes, send
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Developer Picker Dialog */}
      <Dialog open={devPickerOpen} onOpenChange={setDevPickerOpen}>
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">Select Developers to Add</DialogTitle>
            <DialogDescription className="sr-only">Select developers to add to sprint</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <p className="text-xs text-gray-500 mb-3">Select one or more developers to include in this sprint.</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { name: "Alexandre Martin", avatar: "AM", type: "Backend" },
                { name: "Claire Fontaine", avatar: "CF", type: "Frontend" },
                { name: "David Renard", avatar: "DR", type: "Data Eng." },
                { name: "Isabelle Caron", avatar: "IC", type: "QA" },
                { name: "Nicolas Lefebvre", avatar: "NL", type: "Backend" },
                { name: "Pauline Mercier", avatar: "PM", type: "Frontend" },
              ].map((dev) => {
                const isSelected = selectedDevs.includes(dev.name);
                return (
                  <button
                    key={dev.name}
                    className={`flex items-center gap-2 p-3 rounded-lg border transition-colors text-left ${isSelected ? "border-[#2649B2] bg-blue-50" : "border-gray-200 hover:border-gray-300 bg-white"}`}
                    onClick={() => setSelectedDevs(prev => isSelected ? prev.filter(d => d !== dev.name) : [...prev, dev.name])}
                  >
                    <div className="w-7 h-7 rounded-full bg-[#2649B2] flex items-center justify-center flex-shrink-0">
                      <span className="text-white text-[10px] font-medium">{dev.avatar}</span>
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-900 leading-tight">{dev.name}</p>
                      <p className="text-[10px] text-gray-400">{dev.type}</p>
                    </div>
                    {isSelected && <CheckCircle className="w-4 h-4 text-[#2649B2] ml-auto flex-shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
          <div className="flex justify-end gap-2 border-t border-gray-100 pt-3">
            <Button variant="outline" onClick={() => setDevPickerOpen(false)}>Cancel</Button>
            <Button className="bg-[#2649B2] hover:bg-[#1d3a8f] text-white" onClick={() => setDevPickerOpen(false)}>
              Add {selectedDevs.length > 0 ? `(${selectedDevs.length})` : ""} to Sprint
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
