
  # Develop Mockup from File

  This is a code bundle for Develop Mockup from File. The original project is available at https://www.figma.com/design/fjuSvzIAsNKvHIQSZL7G88/Develop-Mockup-from-File.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  